/**
 * Function App entry point.
 *
 * Every function module must be imported here so the Functions host
 * registers it. Add one line per new route file.
 */

// --- HTTP routes -----------------------------------------------------------
import './functions/http/auth';
import './functions/http/me';
import './functions/http/letters';
import './functions/http/workflow';
import './functions/http/team';
import './functions/http/metrics';
import './functions/http/managers';
import './functions/http/inbox';
import './functions/http/users';
import './functions/http/settings';
import './functions/http/integrations';
import './functions/http/demo';

// --- Queue workers ---------------------------------------------------------
import './functions/queue/classifyLetter';
import './functions/queue/processLetter';

// --- Timer jobs ------------------------------------------------------------
import './functions/timer/oooSync';
// import './functions/timer/pollMailbox';  // email intake — on hold
