/**
 * Authentication for Microsoft Graph (application permissions).
 *
 * Two supported modes, mirroring shared/ai/credential.ts:
 *   1. Client secret (GRAPH_CLIENT_SECRET) — local development and simple prod.
 *      A confidential client is required because Mail.Send and
 *      MailboxSettings.Read are application permissions.
 *   2. Managed Identity (no secret) — production. The Function App's identity
 *      must be granted the Graph app roles.
 *
 * The secret never touches the database; it comes from local.settings.json
 * (gitignored) or Key Vault, exactly like the Oracle password and the AI keys.
 */

import { ClientSecretCredential, DefaultAzureCredential, type TokenCredential } from '@azure/identity';
import { config } from '../config';

const GRAPH_SCOPE = 'https://graph.microsoft.com/.default';

let credential: TokenCredential | undefined;
let cached: { token: string; expiresOn: number } | undefined;

function buildCredential(): TokenCredential {
  const { tenantId, clientId, clientSecret } = config.graph;
  if (clientSecret) {
    if (!tenantId || !clientId) {
      throw new Error(
        'GRAPH_TENANT_ID and GRAPH_CLIENT_ID are required when GRAPH_CLIENT_SECRET is set'
      );
    }
    return new ClientSecretCredential(tenantId, clientId, clientSecret);
  }
  // No secret → rely on the Function App's Managed Identity, which must hold the
  // Graph application permissions (Mail.Send, MailboxSettings.Read).
  return new DefaultAzureCredential();
}

/**
 * A bearer token for Microsoft Graph. Cached until ~5 minutes before expiry, so
 * a burst of calls (a Team Workload refresh) shares one token.
 */
export async function getGraphToken(): Promise<string> {
  const now = Date.now();
  if (cached && cached.expiresOn - 5 * 60_000 > now) {
    return cached.token;
  }

  credential ??= buildCredential();
  const result = await credential.getToken(GRAPH_SCOPE);
  if (!result) {
    throw new Error('Failed to acquire a Microsoft Graph token');
  }

  cached = { token: result.token, expiresOn: result.expiresOnTimestamp };
  return cached.token;
}
