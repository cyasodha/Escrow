/**
 * Microsoft Graph REST client — Out-of-Office lookups only.
 *
 *   getOutOnDate → GET /users/{email}/mailboxSettings/automaticRepliesSetting
 *                                                        (MailboxSettings.Read)
 *
 * Used by the nightly OOO sync to answer "is this admin out of office on the next
 * working day?". Auth is graph/credential.ts (client secret or Managed Identity).
 * Sending mail does NOT go through Graph — see shared/notifications/.
 *
 * Local testing without a tenant: set GRAPH_OOO_STUB_OUT to a comma-separated list
 * of emails to treat as out (dev only; never set in production).
 */

import { config } from '../config';
import { getGraphToken } from './credential';
import type { Logger } from '../logger';

const GRAPH_BASE = 'https://graph.microsoft.com/v1.0';

/** True when Graph is switched on. Individual calls still degrade on failure. */
export function graphConfigured(): boolean {
  return config.graph.enabled;
}

interface AutomaticRepliesSetting {
  status?: 'disabled' | 'alwaysEnabled' | 'scheduled';
  scheduledStartDateTime?: { dateTime: string; timeZone: string };
  scheduledEndDateTime?: { dateTime: string; timeZone: string };
}

/** Graph mailbox-settings dateTimes are UTC; normalise to an ISO instant string. */
function parseGraphDate(d?: { dateTime: string; timeZone: string }): string | null {
  if (!d?.dateTime) return null;
  const iso = d.dateTime.endsWith('Z') ? d.dateTime : `${d.dateTime}Z`;
  const ms = Date.parse(iso);
  return Number.isNaN(ms) ? null : new Date(ms).toISOString();
}

/** Calendar date ('YYYY-MM-DD') of an ISO instant in the given timezone. */
function localDateOf(iso: string | null, timezone: string, fallback: string): string {
  if (!iso) return fallback;
  const ms = Date.parse(iso);
  if (Number.isNaN(ms)) return fallback;
  const p = Object.fromEntries(
    new Intl.DateTimeFormat('en-CA', {
      timeZone: timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    })
      .formatToParts(new Date(ms))
      .map((x) => [x.type, x.value])
  );
  return `${p['year']}-${p['month']}-${p['day']}`;
}

/** Is the mailbox out of office on `targetDate` ('YYYY-MM-DD', in `timezone`)? */
function isOutOnDate(s: AutomaticRepliesSetting, targetDate: string, timezone: string): boolean {
  if (s.status === 'alwaysEnabled') return true;
  if (s.status === 'scheduled') {
    const start = localDateOf(parseGraphDate(s.scheduledStartDateTime), timezone, '0000-01-01');
    const end = localDateOf(parseGraphDate(s.scheduledEndDateTime), timezone, '9999-12-31');
    return start <= targetDate && targetDate <= end;
  }
  return false; // 'disabled' or missing
}

async function fetchAutoReplies(email: string, token: string): Promise<AutomaticRepliesSetting> {
  const res = await fetch(
    `${GRAPH_BASE}/users/${encodeURIComponent(email)}/mailboxSettings/automaticRepliesSetting`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!res.ok) {
    // 404 = no such mailbox (e.g. a local-only test account); 403 = missing grant.
    throw new Error(`Graph mailboxSettings ${res.status}`);
  }
  return (await res.json()) as AutomaticRepliesSetting;
}

/**
 * For each email, whether the mailbox is out of office on `targetDate`. Keyed by
 * lower-cased email. A mailbox we cannot read is treated as available (false), so
 * a flaky lookup never wrongly excludes someone. THROWS if the token cannot be
 * acquired at all, so the sync can abort rather than clobber everyone.
 */
export async function getOutOnDate(
  emails: Array<string | null | undefined>,
  targetDate: string,
  timezone: string,
  log?: Logger
): Promise<Record<string, boolean>> {
  const uniq = [...new Set(emails.filter((e): e is string => !!e).map((e) => e.toLowerCase()))];
  const out: Record<string, boolean> = {};
  for (const e of uniq) out[e] = false;

  // Dev/test stub — treat listed emails as out, no Graph call.
  const stub = (process.env['GRAPH_OOO_STUB_OUT'] ?? '')
    .split(',')
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  if (stub.length > 0) {
    for (const e of uniq) out[e] = stub.includes(e);
    log?.info('OOO stub in use (GRAPH_OOO_STUB_OUT)', { targetDate, out: Object.keys(out).filter((e) => out[e]) });
    return out;
  }

  const token = await getGraphToken(); // throws → caller aborts the sync
  for (const e of uniq) {
    try {
      out[e] = isOutOnDate(await fetchAutoReplies(e, token), targetDate, timezone);
    } catch (err) {
      log?.debug('OOO lookup failed; treating as available', {
        reason: err instanceof Error ? err.message : String(err),
      });
      out[e] = false;
    }
  }
  return out;
}
