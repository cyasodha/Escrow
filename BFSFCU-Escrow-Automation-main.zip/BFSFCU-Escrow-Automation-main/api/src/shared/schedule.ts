/**
 * Business calendar — working days/hours + holidays, and the "next activity"
 * computation that decides when a received letter should first be worked.
 *
 * Rule (all wall-clock in the configured timezone):
 *   - received during working hours on a working day  → now (today), not deferred
 *   - received before the day starts on a working day  → today at work_start
 *   - received after cutoff / on a weekend / on a holiday → next working day at work_start
 *
 * The chosen DATE becomes the letter's task_date (its next-activity date). Whether
 * it was deferred tells the caller how to stamp first_activity_at (now vs the
 * working-day start instant), which it builds in SQL to stay DST-correct.
 */

import type { PoolClient } from 'pg';
import { query, queryOne } from './db';

export interface BusinessCalendar {
  /** Working days as ISO day-of-week (1=Mon..7=Sun). */
  workDays: number[];
  /** 'HH:MM' wall-clock in `timezone`. */
  workStart: string;
  workCutoff: string;
  /** IANA timezone, e.g. 'America/New_York'. */
  timezone: string;
  /** One-off non-working dates ('YYYY-MM-DD') on top of the weekend. */
  holidays: Set<string>;
  /** Recurring holidays as 'MM-DD' — matched every year. */
  annualHolidays: Set<string>;
  oooSyncEnabled: boolean;
}

interface CalRow {
  work_days: number[];
  work_start: string;
  work_cutoff: string;
  work_timezone: string;
  ooo_sync_enabled: boolean;
}

const SETTINGS_SQL =
  `SELECT work_days, work_start, work_cutoff, work_timezone, ooo_sync_enabled FROM app_settings WHERE id = true`;
const HOLIDAYS_SQL = `SELECT holiday_date, annual FROM holidays`;

const hhmm = (t: string): string => t.slice(0, 5);

interface HolidayRow {
  holiday_date: string;
  annual: boolean;
}

/** Read the business calendar. Pass the transaction client when inside one. */
export async function getCalendar(client?: PoolClient): Promise<BusinessCalendar> {
  let settings: CalRow | undefined;
  let holidays: HolidayRow[];
  if (client) {
    settings = (await client.query<CalRow>(SETTINGS_SQL)).rows[0];
    holidays = (await client.query<HolidayRow>(HOLIDAYS_SQL)).rows;
  } else {
    settings = await queryOne<CalRow>(SETTINGS_SQL);
    holidays = await query<HolidayRow>(HOLIDAYS_SQL);
  }
  if (!settings) throw new Error('app_settings row is missing');

  const oneOff = new Set<string>();
  const annual = new Set<string>();
  for (const h of holidays) {
    if (h.annual) annual.add(h.holiday_date.slice(5)); // 'MM-DD'
    else oneOff.add(h.holiday_date);
  }

  return {
    workDays: settings.work_days,
    workStart: hhmm(settings.work_start),
    workCutoff: hhmm(settings.work_cutoff),
    timezone: settings.work_timezone,
    oooSyncEnabled: settings.ooo_sync_enabled,
    holidays: oneOff,
    annualHolidays: annual,
  };
}

// --- config + holidays CRUD (admin settings) ---------------------------------

/** The business calendar without the holiday set — for the settings screen. */
export interface ScheduleConfig {
  workDays: number[];
  workStart: string;
  workCutoff: string;
  timezone: string;
  oooSyncEnabled: boolean;
}

export async function getScheduleConfig(): Promise<ScheduleConfig> {
  const cal = await getCalendar();
  return {
    workDays: cal.workDays,
    workStart: cal.workStart,
    workCutoff: cal.workCutoff,
    timezone: cal.timezone,
    oooSyncEnabled: cal.oooSyncEnabled,
  };
}

export async function updateScheduleConfig(input: ScheduleConfig): Promise<ScheduleConfig> {
  await query(
    `UPDATE app_settings
        SET work_days        = $1::integer[],
            work_start       = $2::time,
            work_cutoff      = $3::time,
            work_timezone    = $4,
            ooo_sync_enabled = $5
      WHERE id = true`,
    [input.workDays, input.workStart, input.workCutoff, input.timezone, input.oooSyncEnabled]
  );
  return getScheduleConfig();
}

export interface Holiday {
  id: string;
  date: string;
  label: string | null;
  /** When true, recurs every year on this date's month/day. */
  annual: boolean;
}

export async function listHolidays(): Promise<Holiday[]> {
  return query<Holiday>(
    `SELECT id, holiday_date AS date, label, annual FROM holidays
      ORDER BY to_char(holiday_date, 'MM-DD'), holiday_date`
  );
}

/** Add (or update) a holiday. Idempotent on the date. */
export async function addHoliday(
  date: string,
  label: string | null,
  createdBy: string,
  annual: boolean
): Promise<Holiday> {
  const row = await queryOne<Holiday>(
    `INSERT INTO holidays (holiday_date, label, created_by, annual)
     VALUES ($1::date, $2, $3, $4)
     ON CONFLICT (holiday_date) DO UPDATE SET label = EXCLUDED.label, annual = EXCLUDED.annual
     RETURNING id, holiday_date AS date, label, annual`,
    [date, label, createdBy, annual]
  );
  if (!row) throw new Error('Failed to add holiday');
  return row;
}

export async function deleteHoliday(id: string): Promise<void> {
  await query(`DELETE FROM holidays WHERE id = $1`, [id]);
}

// --- date helpers (calendar-date math, timezone-safe via UTC anchors) --------

const toMinutes = (hhmmStr: string): number => {
  const [h, m] = hhmmStr.split(':').map(Number) as [number, number];
  return h * 60 + m;
};

/** ISO day-of-week (1=Mon..7=Sun) for a 'YYYY-MM-DD' string. */
function isoDowOf(date: string): number {
  const [y, m, d] = date.split('-').map(Number) as [number, number, number];
  const dow = new Date(Date.UTC(y, m - 1, d)).getUTCDay(); // 0=Sun..6=Sat
  return dow === 0 ? 7 : dow;
}

/** Add `n` days to a 'YYYY-MM-DD' string, returning 'YYYY-MM-DD'. */
function addDays(date: string, n: number): string {
  const [y, m, d] = date.split('-').map(Number) as [number, number, number];
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}

/** Wall-clock date + minutes-into-day for an instant, in the given timezone. */
function localParts(at: Date, timezone: string): { date: string; minutes: number } {
  const parts = Object.fromEntries(
    new Intl.DateTimeFormat('en-CA', {
      timeZone: timezone,
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      hour12: false,
    })
      .formatToParts(at)
      .map((p) => [p.type, p.value])
  );
  let hour = Number(parts['hour']);
  if (hour === 24) hour = 0; // Intl can report midnight as '24'
  return {
    date: `${parts['year']}-${parts['month']}-${parts['day']}`,
    minutes: hour * 60 + Number(parts['minute']),
  };
}

/** Is `date` ('YYYY-MM-DD') a working day (weekday in workDays, not a holiday)? */
export function isWorkingDay(date: string, cal: BusinessCalendar): boolean {
  return (
    cal.workDays.includes(isoDowOf(date)) &&
    !cal.holidays.has(date) &&
    !cal.annualHolidays.has(date.slice(5))
  );
}

/** The first working day strictly after `fromDate` ('YYYY-MM-DD'). */
export function nextWorkingDay(fromDate: string, cal: BusinessCalendar): string {
  let cur = fromDate;
  for (let i = 0; i < 366; i++) {
    cur = addDays(cur, 1);
    if (isWorkingDay(cur, cal)) return cur;
  }
  return fromDate; // pathological (no working days configured)
}

/** Today's calendar date ('YYYY-MM-DD') in the given timezone. */
export function todayInZone(timezone: string): string {
  return localParts(new Date(), timezone).date;
}

export interface NextActivity {
  /** The working DATE the letter should first be worked ('YYYY-MM-DD'). */
  taskDate: string;
  /** True when pushed to a future working-day start (→ first_activity_at = start, not now). */
  deferred: boolean;
}

/** Decide a received letter's first next-activity date per the business calendar. */
export function nextActivity(receipt: Date, cal: BusinessCalendar): NextActivity {
  const { date, minutes } = localParts(receipt, cal.timezone);
  const startMin = toMinutes(cal.workStart);
  const cutoffMin = toMinutes(cal.workCutoff);

  if (isWorkingDay(date, cal)) {
    // During working hours → start now (today).
    if (minutes >= startMin && minutes < cutoffMin) return { taskDate: date, deferred: false };
    // Before the day opens → today at work_start.
    if (minutes < startMin) return { taskDate: date, deferred: true };
    // else after cutoff → fall through to the next working day.
  }

  // Non-working day, or after cutoff → next working day at work_start.
  return { taskDate: nextWorkingDay(date, cal), deferred: true };
}

// --- OOO sync bookkeeping ----------------------------------------------------

export async function getOooSyncLastRun(): Promise<string | null> {
  const row = await queryOne<{ ooo_sync_last_run: string | null }>(
    `SELECT ooo_sync_last_run FROM app_settings WHERE id = true`
  );
  return row?.ooo_sync_last_run ?? null;
}

export async function setOooSyncLastRun(date: string): Promise<void> {
  await query(`UPDATE app_settings SET ooo_sync_last_run = $1::date WHERE id = true`, [date]);
}

/** Minutes-into-day (work_timezone) for an instant — for the cutoff comparison. */
export function minutesInZone(at: Date, timezone: string): number {
  return localParts(at, timezone).minutes;
}

export { toMinutes };
