/**
 * Oracle loan-lookup layer — public surface.
 *
 * The pipeline and routes depend only on the `OracleConnector` interface and
 * `getOracleConnector()`, never on the `oracledb` driver directly, so the source
 * stays swappable (SOW §6). Swap the implementation here to point at a different
 * system or an in-memory fake for tests.
 */

export type { OracleConnector, LoanRecord, InsuranceOnFile } from './connector';
export { isOracleReady, resolveOracle, closeOraclePool } from './connection';

import type { OracleConnector } from './connector';
import { oracleConnector } from './oracledb';

/** The connector implementation the app uses. */
export function getOracleConnector(): OracleConnector {
  return oracleConnector;
}
