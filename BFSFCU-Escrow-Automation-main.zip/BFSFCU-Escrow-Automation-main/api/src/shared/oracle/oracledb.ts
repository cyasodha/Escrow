/**
 * The `oracledb`-backed OracleConnector.
 *
 * Read-only: every statement here is a SELECT. Dates are pulled as strings via
 * TO_CHAR so there is no timezone drift (a DATE is a calendar date, not an
 * instant). node-oracledb returns OBJECT rows with UPPERCASE column keys.
 */

import oracledb from 'oracledb';
import { getOraclePool } from './connection';
import { AppError } from '../errors';
import { addressesMatch, normalizeId } from '../normalize';
import type { OracleConnector, LoanRecord, InsuranceOnFile } from './connector';

interface LoanRow {
  LOAN_NUMBER: string;
  MEMBER_NAME: string;
  PROPERTY_ADDRESS: string;
  MORTGAGE_STATUS: string;
  ESCROW_BALANCE: number;
}

interface InsuranceRow {
  LOAN_NUMBER: string;
  CARRIER: string;
  POLICY_NUMBER: string;
  POLICY_TYPE: string | null;
  DWELLING_COVERAGE: number | null;
  PREMIUM: number | null;
  PERIOD_START: string | null;
  PERIOD_END: string | null;
}

function toLoan(row: LoanRow): LoanRecord {
  return {
    loanNumber: row.LOAN_NUMBER,
    memberName: row.MEMBER_NAME,
    propertyAddress: row.PROPERTY_ADDRESS,
    mortgageStatus: row.MORTGAGE_STATUS,
    escrowBalance: Number(row.ESCROW_BALANCE ?? 0),
  };
}

/** Run one read against a pooled connection, always releasing it. */
async function read<T>(
  sql: string,
  binds: oracledb.BindParameters
): Promise<T[]> {
  const pool = await getOraclePool();
  let conn: oracledb.Connection | undefined;
  try {
    conn = await pool.getConnection();
    const result = await conn.execute<T>(sql, binds, {
      outFormat: oracledb.OUT_FORMAT_OBJECT,
    });
    return result.rows ?? [];
  } catch (err) {
    throw AppError.upstream(`Oracle query failed: ${(err as Error).message}`);
  } finally {
    if (conn) {
      try {
        await conn.close();
      } catch {
        // best effort
      }
    }
  }
}

export const oracleConnector: OracleConnector = {
  async findLoanByNumber(loanNumber: string): Promise<LoanRecord | null> {
    const rows = await read<LoanRow>(
      `SELECT loan_number, member_name, property_address, mortgage_status, escrow_balance
         FROM loan
        WHERE loan_number = :loanNumber`,
      { loanNumber }
    );
    const row = rows[0];
    return row ? toLoan(row) : null;
  },

  async findLoanByNameAddress(name: string, address: string): Promise<LoanRecord | null> {
    // Match the member name in SQL (case-insensitive), then confirm the address
    // in JS with the same normalization the tier uses (so "Rd" == "Road").
    const rows = await read<LoanRow>(
      `SELECT loan_number, member_name, property_address, mortgage_status, escrow_balance
         FROM loan
        WHERE UPPER(TRIM(member_name)) = UPPER(TRIM(:name))`,
      { name }
    );
    const match = rows
      .map(toLoan)
      .find((loan) => addressesMatch(loan.propertyAddress, address));
    return match ?? null;
  },

  async getInsuranceOnFile(loanNumber: string): Promise<InsuranceOnFile | null> {
    // Most recent policy on file for the loan (there is normally one).
    const rows = await read<InsuranceRow>(
      `SELECT loan_number, carrier, policy_number, policy_type, dwelling_coverage, premium,
              TO_CHAR(period_start, 'YYYY-MM-DD') AS period_start,
              TO_CHAR(period_end,   'YYYY-MM-DD') AS period_end
         FROM insurance_on_file
        WHERE loan_number = :loanNumber
        ORDER BY period_end DESC NULLS LAST
        FETCH FIRST 1 ROWS ONLY`,
      { loanNumber }
    );
    const row = rows[0];
    if (!row) return null;
    return {
      loanNumber: row.LOAN_NUMBER,
      carrier: row.CARRIER,
      policyNumber: row.POLICY_NUMBER,
      policyType: row.POLICY_TYPE,
      dwellingCoverage: row.DWELLING_COVERAGE === null ? null : Number(row.DWELLING_COVERAGE),
      premium: row.PREMIUM === null ? null : Number(row.PREMIUM),
      periodStart: row.PERIOD_START,
      periodEnd: row.PERIOD_END,
    };
  },

  async findInsuranceByPolicyNumber(policyNumber: string): Promise<InsuranceOnFile | null> {
    // Compare on the policy number stripped to alphanumerics on both sides, so
    // "ALS-7729014" == "als 7729014". The normalized value is bound from JS.
    const rows = await read<InsuranceRow>(
      `SELECT loan_number, carrier, policy_number, policy_type, dwelling_coverage, premium,
              TO_CHAR(period_start, 'YYYY-MM-DD') AS period_start,
              TO_CHAR(period_end,   'YYYY-MM-DD') AS period_end
         FROM insurance_on_file
        WHERE REGEXP_REPLACE(UPPER(policy_number), '[^A-Z0-9]', '') = :pol
        ORDER BY period_end DESC NULLS LAST
        FETCH FIRST 1 ROWS ONLY`,
      { pol: normalizeId(policyNumber) }
    );
    const row = rows[0];
    if (!row) return null;
    return {
      loanNumber: row.LOAN_NUMBER,
      carrier: row.CARRIER,
      policyNumber: row.POLICY_NUMBER,
      policyType: row.POLICY_TYPE,
      dwellingCoverage: row.DWELLING_COVERAGE === null ? null : Number(row.DWELLING_COVERAGE),
      premium: row.PREMIUM === null ? null : Number(row.PREMIUM),
      periodStart: row.PERIOD_START,
      periodEnd: row.PERIOD_END,
    };
  },

  async ping(): Promise<{ ok: true; loanCount: number }> {
    const rows = await read<{ CNT: number }>(`SELECT COUNT(*) AS cnt FROM loan`, {});
    return { ok: true, loanCount: Number(rows[0]?.CNT ?? 0) };
  },
};
