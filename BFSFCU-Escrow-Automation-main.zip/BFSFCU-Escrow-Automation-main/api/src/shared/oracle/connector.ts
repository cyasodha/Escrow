/**
 * The read-only Oracle loan-lookup contract.
 *
 * Written against an interface so the source is swappable (SOW §6) and the whole
 * pipeline can be tested without a live Oracle. The concrete `oracledb`
 * implementation is in ./oracledb.ts; ./index.ts wires up whichever the config
 * selects.
 *
 * Exactly three read operations, matching the SOW's "small set of operations":
 * find a loan by number, find a loan by member name + property address as a
 * fallback, and read the insurance record on file. Nothing writes to Oracle.
 */

/** A mortgage loan / member escrow account. */
export interface LoanRecord {
  loanNumber: string;
  memberName: string;
  propertyAddress: string;
  /** ACTIVE / PAID_OFF / DELINQUENT / FORECLOSURE. Only ACTIVE is serviceable. */
  mortgageStatus: string;
  escrowBalance: number;
}

/** The hazard-insurance policy currently recorded against a loan's escrow. */
export interface InsuranceOnFile {
  loanNumber: string;
  carrier: string;
  policyNumber: string;
  policyType: string | null;
  dwellingCoverage: number | null;
  premium: number | null;
  /** YYYY-MM-DD. */
  periodStart: string | null;
  /** YYYY-MM-DD. */
  periodEnd: string | null;
}

export interface OracleConnector {
  /**
   * Look up a loan by its number and confirm an active mortgage. Returns null
   * when no such loan exists (the caller then tries the name+address fallback).
   */
  findLoanByNumber(loanNumber: string): Promise<LoanRecord | null>;

  /**
   * Fallback lookup when the loan number is missing or does not resolve: match
   * on insured member name + property address (SOW §6). Returns null when no
   * confident single match is found.
   */
  findLoanByNameAddress(name: string, address: string): Promise<LoanRecord | null>;

  /** The insurance policy on file for a loan, or null if none is recorded. */
  getInsuranceOnFile(loanNumber: string): Promise<InsuranceOnFile | null>;

  /**
   * PRIMARY insurance match: find the on-file policy by its policy number
   * (normalized). Returns null when no insurance record carries that policy
   * number — i.e. the letter's policy is not on file (a new/replacement policy).
   */
  findInsuranceByPolicyNumber(policyNumber: string): Promise<InsuranceOnFile | null>;

  /** Verify connectivity and that the two tables are readable (admin "Test connection"). */
  ping(): Promise<{ ok: true; loanCount: number }>;
}
