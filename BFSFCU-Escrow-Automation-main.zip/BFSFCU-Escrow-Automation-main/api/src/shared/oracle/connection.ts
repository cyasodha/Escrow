/**
 * Oracle connection management.
 *
 * The connection is configured from the admin UI (host / port / service / user /
 * enabled, stored in app_settings) and combined with the password from
 * ORACLE_PASSWORD (Key Vault). A pool is created lazily on first use and rebuilt
 * automatically if the admin changes the connection.
 *
 * node-oracledb runs in **Thin mode** by default (pure JS — no Oracle Instant
 * Client install). Set ORACLE_THIN_MODE=false to use Thick mode against a local
 * client. Mirrors the AP Prologue connector's lazy-pool shape, but reads the
 * connection from the database (like the Entra SSO settings) rather than env.
 */

import oracledb from 'oracledb';
import { config } from '../config';
import { AppError } from '../errors';
import { getOracleConfig, getOraclePassword, type OracleConfig } from '../repository/settings';

let pool: oracledb.Pool | undefined;
/** Identifies the connection a live pool was built for, so a config change rebuilds it. */
let poolKey = '';
let thickInitialised = false;

/** Resolved connection = UI settings (app_settings) + password (Key Vault). */
export interface ResolvedOracle extends OracleConfig {
  password: string;
}

function connectString(cfg: OracleConfig): string {
  return `${cfg.host}:${cfg.port}/${cfg.serviceName}`;
}

/**
 * The effective Oracle password: the one entered in the admin UI (app_settings)
 * if set, otherwise ORACLE_PASSWORD (Key Vault). Read only inside this module.
 */
async function effectivePassword(): Promise<string> {
  return (await getOraclePassword()) ?? config.oracle.password;
}

/** Merge the stored connection with the effective password. */
export async function resolveOracle(): Promise<ResolvedOracle> {
  const cfg = await getOracleConfig();
  return { ...cfg, password: await effectivePassword() };
}

/** True when Oracle lookups are switched on AND fully configured. */
export async function isOracleReady(): Promise<boolean> {
  const cfg = await getOracleConfig();
  const password = await effectivePassword();
  return cfg.enabled && !!cfg.host && !!cfg.serviceName && !!cfg.user && !!password;
}

/**
 * Get (or lazily build) the connection pool. Throws AppError.upstream with a
 * clear reason when Oracle is disabled or not fully configured — the pipeline
 * catches this and degrades gracefully (the letter still tiers, as Low).
 */
export async function getOraclePool(): Promise<oracledb.Pool> {
  const cfg = await getOracleConfig();
  const password = await effectivePassword();

  if (!cfg.enabled) {
    throw AppError.upstream('Oracle lookups are disabled. Enable and configure the connection in Admin → Oracle Connection.');
  }
  const missing: string[] = [];
  if (!cfg.host) missing.push('host');
  if (!cfg.serviceName) missing.push('service name');
  if (!cfg.user) missing.push('user');
  if (!password) missing.push('password (set it here or via ORACLE_PASSWORD)');
  if (missing.length > 0) {
    throw AppError.upstream(`Oracle connection is not fully configured — missing: ${missing.join(', ')}.`);
  }

  // Thick mode (optional): initialise the Oracle Client exactly once.
  if (!config.oracle.thinMode && !thickInitialised) {
    try {
      oracledb.initOracleClient();
      thickInitialised = true;
    } catch (err) {
      throw AppError.upstream(`Oracle: cannot initialise the Oracle Client for Thick mode (${(err as Error).message}).`);
    }
  }

  const key = `${connectString(cfg)}:${cfg.user}`;
  if (pool && poolKey === key) return pool;

  // Connection changed since the pool was built — drop the old one first.
  if (pool && poolKey !== key) {
    await closeOraclePool();
  }

  try {
    pool = await oracledb.createPool({
      user: cfg.user!,
      password,
      connectString: connectString(cfg),
      poolMin: 0,
      poolMax: 4,
      poolTimeout: 60,
    });
    poolKey = key;
    return pool;
  } catch (err) {
    throw AppError.upstream(`Oracle: cannot connect (${(err as Error).message}).`);
  }
}

/** Close the pool (on shutdown, or when the connection config changes). */
export async function closeOraclePool(): Promise<void> {
  if (pool) {
    try {
      await pool.close(5);
    } catch {
      // best effort
    }
    pool = undefined;
    poolKey = '';
  }
}
