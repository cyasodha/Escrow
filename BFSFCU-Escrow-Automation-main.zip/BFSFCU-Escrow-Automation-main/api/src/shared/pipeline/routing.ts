/**
 * Bucket routing — the post-processing decision that puts a letter in one of
 * three work buckets (the reviewer can still move it afterwards):
 *
 *   Review            (status low_confidence) — the letter could not be read
 *                     confidently: a key field (policy #, loan #, insured, carrier,
 *                     address) is missing, it is not an escrow letter, or the
 *                     extraction confidence is low. A temporary holding bucket.
 *   Action Required   (status task) — the letter read fine but something needs a
 *                     human/phone call: a mismatch against the record on file, a
 *                     coverage gap/overlap, a premium change, an address mismatch,
 *                     or a new carrier.
 *   No Action Required(status high_confidence) — everything matches the record on
 *                     file, with no gap and no significant change.
 *
 * Extraction quality is checked FIRST: an unreadable letter is Review regardless
 * of any (unreliable) comparison against Oracle.
 */

import type { NormalizedLetter } from '../ai/openai';
import type { OracleMatch } from './oracleMatch';
import type { CompareResult } from './compare';
import type { TieringResult } from './tiering';

export type RoutedStatus = 'high_confidence' | 'low_confidence' | 'task';

export interface RoutingResult {
  status: RoutedStatus;
  reason: string;
}

/** A missing key field / unreadable document sends the letter to Review. */
const REVIEW_FLAGS = new Set([
  'non_escrow_document',
  'low_ocr_quality',
  'policy_number_missing',
  'loan_number_missing',
  'insured_name_missing',
  'carrier_missing',
  'property_address_missing',
  // The letter type is unknown or the text conflicts with it (renewal vs
  // cancellation) — a human confirms the type before it's actioned.
  'letter_type_uncertain',
]);

/** Below this extraction confidence, hold the letter in Review. */
const REVIEW_CONFIDENCE = 0.5;

const FLAG_LABELS: Record<string, string> = {
  carrier_change: 'new carrier',
  policy_change: 'policy number changed',
  coverage_change: 'coverage amount changed',
  premium_change_gt_5pct: 'premium change over 5%',
  no_matching_insurance: 'no matching policy on file',
  no_insurance_on_file: 'no insurance on file',
  policy_number_missing: 'policy number missing',
  loan_number_missing: 'loan number missing',
  insured_name_missing: 'insured name missing',
  carrier_missing: 'carrier missing',
  property_address_missing: 'property address missing',
  non_escrow_document: 'not an escrow letter',
  low_ocr_quality: 'low scan quality',
  letter_type_uncertain: 'letter type uncertain',
};

function label(flag: string): string {
  return FLAG_LABELS[flag] ?? flag.replace(/_/g, ' ');
}

/**
 * Whole-day delta between the previous coverage end and the new coverage start
 * (newStart - prevEnd). > 1 is a gap, < -1 is an overlap; UTC-parsed so there is
 * no timezone drift. Mirrors web/src/lib/coverageGap.ts.
 */
export function coverageGapDays(
  prevEnd: string | null,
  newStart: string | null
): number | null {
  const toDay = (v: string | null): number | null => {
    if (!v) return null;
    const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(v);
    if (!m) return null;
    return Math.floor(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])) / 86_400_000);
  };
  const a = toDay(prevEnd);
  const b = toDay(newStart);
  if (a === null || b === null) return null;
  return b - a;
}

export function routeLetter(input: {
  letter: NormalizedLetter;
  match: OracleMatch;
  compare: CompareResult;
  tier: TieringResult;
  extractionFlags: string[];
  confidence: number | null;
}): RoutingResult {
  const { letter, match, compare, tier, extractionFlags, confidence } = input;

  // 1. Review — the document could not be read confidently.
  const missing = extractionFlags.filter((f) => REVIEW_FLAGS.has(f));
  const lowConfidence = confidence !== null && confidence < REVIEW_CONFIDENCE;
  if (missing.length > 0 || lowConfidence) {
    const why = missing.length > 0 ? missing.map(label).join(', ') : 'low extraction confidence';
    return {
      status: 'low_confidence',
      reason: `Review — the letter could not be read confidently (${why}).`,
    };
  }

  // 2. Action Required — a discrepancy that needs a human / phone call.
  const reasons: string[] = [];
  if (match.matchStatus === 'no_match') reasons.push('no matching loan on file');
  if (!tier.piiMatch) reasons.push('insured name / property address mismatch');
  if (!tier.accountMatch) reasons.push('loan # / policy # not confirmed on file');
  if (match.loan && match.loan.mortgageStatus !== 'ACTIVE') {
    reasons.push(`mortgage ${match.loan.mortgageStatus.toLowerCase()}`);
  }
  for (const f of compare.flags) reasons.push(label(f));

  // Coverage gap/overlap — modifications only (a cancellation has no new start).
  if (letter.letterType === 'modification' && match.insurance) {
    const delta = coverageGapDays(match.insurance.periodEnd, letter.policyPeriodStart);
    if (delta !== null && delta > 1) reasons.push(`coverage gap of ${delta} days`);
    else if (delta !== null && delta < -1) reasons.push(`coverage overlap of ${-delta} days`);
  }

  if (reasons.length > 0) {
    const unique = [...new Set(reasons)];
    return { status: 'task', reason: `Action required — ${unique.join('; ')}.` };
  }

  // 3. No Action Required — everything matches the record on file.
  return {
    status: 'high_confidence',
    reason: 'No action required — matches the record on file, with no gap or significant change.',
  };
}
