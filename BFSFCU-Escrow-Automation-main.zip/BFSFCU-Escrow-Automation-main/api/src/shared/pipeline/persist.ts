/**
 * Final write for a processed letter.
 *
 * Everything happens in ONE transaction — the letter row and its audit entry
 * commit together or not at all — so a processed letter can never exist without
 * its audit record.
 *
 * The pipeline routes into one of three buckets (see pipeline/routing.ts):
 * No Action Required (high_confidence), Review (low_confidence), or Action
 * Required (task). It never writes 'approved'/'rejected' — those are reviewer
 * actions in repository/workflow.ts.
 */

import { transaction } from '../db';
import { assignAfterProcessing } from '../repository/assignments';
import type { OracleMatch } from './oracleMatch';
import type { CompareResult } from './compare';
import type { TieringResult } from './tiering';
import type { DuplicateResult } from './duplicateCheck';
import type { NormalizedLetter } from '../ai/openai';

export interface PersistInput {
  letterId: string;
  letter: NormalizedLetter;
  /** Due date derived from the policy period start, and how. */
  dueDate: string | null;
  dueDateDefaulted: boolean;
  dueDateDefaultSource: string | null;

  match: OracleMatch;
  compare: CompareResult;
  tier: TieringResult;
  /** Final work-bucket status from pipeline/routing.ts. */
  routedStatus: 'high_confidence' | 'low_confidence' | 'task';
  /** Human explanation of the routing decision (shown to the reviewer). */
  routingReason: string;
  duplicate: DuplicateResult;

  /** Combined stage-2 extraction flags + duplicate flag, for the reviewer. */
  extractionFlags: string[];
  confidence: number | null;
  extractionProvider: string;
  reasoningProvider: string | null;
  extractionRaw: unknown;
  normalizationRaw: unknown;
}

/** Accept only YYYY-MM-DD; anything else becomes null rather than a bad date. */
function safeDate(value: string | null): string | null {
  if (!value) return null;
  return /^\d{4}-\d{2}-\d{2}$/.test(value) ? value : null;
}

export async function saveProcessedLetter(
  input: PersistInput
): Promise<'high_confidence' | 'low_confidence' | 'task'> {
  const status = input.routedStatus;
  const l = input.letter;

  await transaction(async (client) => {
    await client.query(
      `UPDATE letters SET
          letter_type                 = $2::letter_type,
          cancellation_subtype        = $3::cancellation_subtype,
          cancellation_effective_date = $4::date,
          carrier                     = $5,
          policy_number               = $6,
          property_address            = $7,
          insured_name                = $8,
          loan_number                 = $9,
          dwelling_coverage           = $10,
          total_premium               = $11,
          policy_period_start         = $12::date,
          policy_period_end           = $13::date,
          policy_type                 = $14,
          reason                      = $15,
          due_date                    = $16::date,
          due_date_defaulted          = $17,
          due_date_default_source     = $18,
          status                      = $19::letter_status,
          match_status                = $20::match_status,
          matched_loan_number         = $21,
          oracle_match_raw            = $22::jsonb,
          compare_result              = $23::jsonb,
          premium_delta               = $24,
          premium_delta_pct           = $25,
          compare_flags               = $26,
          confidence_tier             = $27::confidence_tier,
          pii_match                   = $28,
          account_match               = $29,
          tier_reason                 = $30,
          confidence_score            = $31,
          extraction_flags            = $32,
          extraction_provider         = $33,
          reasoning_provider          = $34,
          extraction_raw              = $35::jsonb,
          normalization_raw           = $36::jsonb,
          duplicate_of                = $37,
          duplicate_type              = $38,
          processing_error            = NULL
        WHERE id = $1`,
      [
        input.letterId,
        l.letterType,
        l.cancellationSubtype,
        safeDate(l.cancellationEffectiveDate),
        l.carrier,
        l.policyNumber,
        l.propertyAddress,
        l.insuredName,
        l.loanNumber,
        l.dwellingCoverage,
        l.totalPremium,
        safeDate(l.policyPeriodStart),
        safeDate(l.policyPeriodEnd),
        l.policyType,
        l.reason,
        safeDate(input.dueDate),
        input.dueDateDefaulted,
        input.dueDateDefaultSource,
        status,
        input.match.matchStatus,
        input.match.loan?.loanNumber ?? null,
        JSON.stringify({
          matchStatus: input.match.matchStatus,
          oracleAvailable: input.match.oracleAvailable,
          note: input.match.note,
          loan: input.match.loan,
          insuranceOnFile: input.match.insurance,
        }),
        JSON.stringify(input.compare.rows),
        input.compare.premiumDelta,
        input.compare.premiumDeltaPct,
        input.compare.flags,
        input.tier.tier,
        input.tier.piiMatch,
        input.tier.accountMatch,
        input.routingReason,
        input.confidence,
        input.extractionFlags,
        input.extractionProvider,
        input.reasoningProvider,
        JSON.stringify(input.extractionRaw),
        JSON.stringify(input.normalizationRaw),
        input.duplicate.duplicateOf,
        input.duplicate.duplicateType,
      ]
    );

    await client.query(
      `INSERT INTO audit_logs (entity_type, entity_id, action, metadata)
       VALUES ('letter', $1, 'processed', $2::jsonb)`,
      [
        input.letterId,
        JSON.stringify({
          status,
          letterType: l.letterType,
          cancellationSubtype: l.cancellationSubtype,
          matchStatus: input.match.matchStatus,
          oracleAvailable: input.match.oracleAvailable,
          tier: input.tier.tier,
          piiMatch: input.tier.piiMatch,
          accountMatch: input.tier.accountMatch,
          compareFlags: input.compare.flags,
          duplicateOf: input.duplicate.duplicateOf,
        }),
      ]
    );

    // Distribute the letter: readable work is weighted-auto-assigned to an
    // Escrow Admin (unless it was self-assigned at upload); an exception
    // (low_confidence) is routed to a Manager's My Tasks. Same transaction, so a
    // processed letter always has an owner where one is available.
    await assignAfterProcessing(client, input.letterId, status);
  });

  return status;
}
