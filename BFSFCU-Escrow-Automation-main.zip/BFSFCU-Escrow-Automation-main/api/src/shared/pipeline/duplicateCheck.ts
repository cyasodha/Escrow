/**
 * Duplicate detection for letters.
 *
 * Duplicate uploads are allowed (re-scanning a mailed letter is normal), so this
 * only RECOGNISES a duplicate and links it — it does not block or auto-route.
 * Consistent with the locked decisions (auto-tier is High/Low only; the Task
 * queue is a manual reviewer action), a duplicate simply surfaces a flag +
 * `duplicate_of` link so the reviewer can decide.
 *
 * A duplicate is: an earlier letter with the same policy # AND the same loan #
 * (compared after normalization, so "ALS-7729014" == "als 7729014").
 */

import { query } from '../db';
import { idsMatch } from '../normalize';

export interface DuplicateInput {
  letterId: string;
  policyNumber: string | null;
  loanNumber: string | null;
}

export interface DuplicateResult {
  duplicateOf: string | null;
  duplicateType: 'hard' | null;
  message: string | null;
}

const NONE: DuplicateResult = { duplicateOf: null, duplicateType: null, message: null };

interface PriorRow {
  id: string;
  policy_number: string | null;
  loan_number: string | null;
  created_at: string;
}

export async function detectDuplicate(input: DuplicateInput): Promise<DuplicateResult> {
  if (!input.policyNumber || !input.loanNumber) return NONE;

  // Candidates share the same loan #; confirm the policy # matches after
  // normalization. Newest prior copy wins as the link target.
  const priors = await query<PriorRow>(
    `SELECT id, policy_number, loan_number, created_at
       FROM letters
      WHERE id <> $1
        AND loan_number IS NOT NULL
        AND policy_number IS NOT NULL
        AND regexp_replace(upper(loan_number), '[^A-Z0-9]', '', 'g')
            = regexp_replace(upper($2), '[^A-Z0-9]', '', 'g')
      ORDER BY created_at DESC`,
    [input.letterId, input.loanNumber]
  );

  const match = priors.find((p) => idsMatch(p.policy_number, input.policyNumber));
  if (!match) return NONE;

  return {
    duplicateOf: match.id,
    duplicateType: 'hard',
    message: 'A prior letter with the same policy # and loan # is already on file.',
  };
}
