/**
 * Confidence tiering — the High/Low decision.
 *
 * The system auto-assigns ONLY High or Low. There is no automatic Exception; the
 * Task/Exception queue is populated only by a reviewer manually moving an item
 * there. Applies identically to modifications and cancellations.
 *
 *   High = a 100% match on PII (insured name + property address) AND account
 *          (loan # + policy #) between the letter and the Oracle record, after
 *          normalization, with an active mortgage.
 *   Low  = anything less (partial match, or no matching record).
 *
 * Fuzzy matching is used to *find* the Oracle record (see pipeline/oracleMatch);
 * the tier here is based on how EXACTLY the found record equals the letter — so
 * a record located by the name+address fallback whose loan # differs from the
 * letter is Low, not High.
 *
 * Pure and synchronous — no I/O — so the rule is easy to read and unit-test.
 */

import { namesMatch, addressesMatch, idsMatch } from '../normalize';
import type { NormalizedLetter } from '../ai/openai';
import type { OracleMatch } from './oracleMatch';

export interface TieringResult {
  tier: 'high' | 'low';
  /** insured name + property address both equal the Oracle loan record. */
  piiMatch: boolean;
  /** loan # (vs the matched loan) + policy # (vs the on-file policy) both equal. */
  accountMatch: boolean;
  reason: string;
}

export function tierLetter(letter: NormalizedLetter, match: OracleMatch): TieringResult {
  const { loan } = match;

  if (!loan) {
    return {
      tier: 'low',
      piiMatch: false,
      accountMatch: false,
      reason: match.oracleAvailable
        ? 'No matching Oracle loan record found.'
        : 'Oracle lookup unavailable — could not confirm the account.',
    };
  }

  // PII: insured name + property address vs the loan record.
  const nameOk = namesMatch(letter.insuredName, loan.memberName);
  const addressOk = addressesMatch(letter.propertyAddress, loan.propertyAddress);
  const piiMatch = nameOk && addressOk;

  // Account: loan # vs the matched loan, and — PRIMARY — the policy number found
  // on file (insurance_on_file). A letter whose policy is not on file (a new or
  // replacement policy) fails the account match, whatever else lines up.
  const loanOk = idsMatch(letter.loanNumber, loan.loanNumber);
  const policyOk = match.policyFound;
  const accountMatch = loanOk && policyOk;

  const active = loan.mortgageStatus === 'ACTIVE';
  const tier: TieringResult['tier'] = piiMatch && accountMatch && active ? 'high' : 'low';

  // Explain the decision for the reviewer / audit trail.
  let reason: string;
  if (tier === 'high') {
    reason = '100% match on PII (name + address) and account (loan # + policy #).';
  } else {
    const gaps: string[] = [];
    if (!nameOk) gaps.push('insured name');
    if (!addressOk) gaps.push('property address');
    if (!loanOk) gaps.push('loan #');
    if (!policyOk) gaps.push('no matching insurance (policy # not on file)');
    if (!active) gaps.push(`mortgage ${loan.mortgageStatus}`);
    reason = `Not a 100% match — differs on: ${gaps.join(', ')}.`;
  }

  return { tier, piiMatch, accountMatch, reason };
}
