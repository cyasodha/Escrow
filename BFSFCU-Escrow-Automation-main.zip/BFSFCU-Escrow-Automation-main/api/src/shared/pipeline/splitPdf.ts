/**
 * Slice a page range out of a PDF into a new single-letter PDF.
 *
 * Used by the classify-and-split stage: the classifier returns a page range per
 * detected letter, and we copy just those pages into their own document so each
 * letter gets its own blob and runs through the normal per-letter pipeline.
 *
 * pdf-lib is pure JavaScript (no native binaries), so it is safe in the
 * Functions host. Only PDFs are sliced — image uploads are single-page and are
 * never routed through this stage.
 */

import { PDFDocument } from 'pdf-lib';
import { AppError } from '../errors';

/**
 * Copy pages [startPage, endPage] (1-based, inclusive) of `file` into a new PDF.
 * Ranges are clamped to the document's real page count so an over-eager
 * classifier range can't throw.
 */
export async function splitPdf(file: Buffer, startPage: number, endPage: number): Promise<Buffer> {
  let source: PDFDocument;
  try {
    source = await PDFDocument.load(file, { ignoreEncryption: true });
  } catch (err) {
    throw AppError.upstream(
      `Could not read the PDF for splitting: ${err instanceof Error ? err.message : 'unknown error'}`
    );
  }

  const total = source.getPageCount();
  const start = Math.max(1, Math.min(startPage, total));
  const end = Math.max(start, Math.min(endPage, total));

  const out = await PDFDocument.create();
  // pdf-lib is 0-based; our range is 1-based inclusive.
  const indices = Array.from({ length: end - start + 1 }, (_, k) => start - 1 + k);
  const copied = await out.copyPages(source, indices);
  copied.forEach((p) => out.addPage(p));

  const bytes = await out.save();
  return Buffer.from(bytes);
}

/** Page count of a PDF, or null if it can't be read. */
export async function pdfPageCount(file: Buffer): Promise<number | null> {
  try {
    const doc = await PDFDocument.load(file, { ignoreEncryption: true });
    return doc.getPageCount();
  } catch {
    return null;
  }
}
