/**
 * Match a letter to a member escrow account in Oracle.
 *
 * The POLICY NUMBER is the primary insurance match: the letter's policy number
 * is looked up directly in Oracle's insurance_on_file. If no record carries that
 * policy number, the letter's policy is not on file — a new/replacement policy —
 * and `policyFound` is false (the pipeline tags it "No matching insurance found").
 *
 * The loan is matched separately to establish PII/property (SOW §6):
 *   1. loan number -> active mortgage + property address
 *   2. fallback: insured name + property address
 *   3. no match
 *
 * Oracle-down is handled GRACEFULLY, not by failing the letter (SOW §6/§11): if
 * the connector is disabled or unreachable, this returns `no_match` with
 * `oracleAvailable: false` and a note, and the letter still flows through
 * compare + tier (as Low). It never throws.
 */

import {
  getOracleConnector,
  isOracleReady,
  type LoanRecord,
  type InsuranceOnFile,
} from '../oracle';
import type { Logger } from '../logger';

export interface OracleMatchInput {
  loanNumber: string | null;
  policyNumber: string | null;
  insuredName: string | null;
  propertyAddress: string | null;
}

export interface OracleMatch {
  matchStatus: 'matched_by_loan' | 'matched_by_name_address' | 'no_match';
  loan: LoanRecord | null;
  insurance: InsuranceOnFile | null;
  /** PRIMARY: the letter's policy number was found in insurance_on_file. */
  policyFound: boolean;
  /** False when Oracle is disabled or unreachable (letter still processes). */
  oracleAvailable: boolean;
  /** Human-readable note for the audit trail / reviewer. */
  note: string | null;
}

export async function matchToOracle(
  input: OracleMatchInput,
  log?: Logger
): Promise<OracleMatch> {
  if (!(await isOracleReady())) {
    return {
      matchStatus: 'no_match',
      loan: null,
      insurance: null,
      policyFound: false,
      oracleAvailable: false,
      note: 'Oracle lookups are disabled or not configured — letter routed for manual review.',
    };
  }

  const oracle = getOracleConnector();

  try {
    // PRIMARY match: the policy number, looked up in insurance_on_file.
    const policyMatch = input.policyNumber
      ? await oracle.findInsuranceByPolicyNumber(input.policyNumber)
      : null;
    const policyFound = !!policyMatch;

    // Loan match (for PII / property / escrow): loan # then name + address.
    let loan: LoanRecord | null = null;
    let matchStatus: OracleMatch['matchStatus'] = 'no_match';
    if (input.loanNumber) {
      loan = await oracle.findLoanByNumber(input.loanNumber);
      if (loan) matchStatus = 'matched_by_loan';
    }
    if (!loan && input.insuredName && input.propertyAddress) {
      loan = await oracle.findLoanByNameAddress(input.insuredName, input.propertyAddress);
      if (loan) matchStatus = 'matched_by_name_address';
    }

    // Insurance to compare against: the loan's current on-file policy; fall back
    // to the policy-matched record if the loan itself did not resolve.
    const insurance = loan ? await oracle.getInsuranceOnFile(loan.loanNumber) : policyMatch;

    let note: string | null = null;
    if (input.policyNumber && !policyFound) {
      note = `No matching insurance found — policy ${input.policyNumber} is not on file (likely a new or replacement policy).`;
    } else if (!loan) {
      note = 'No matching Oracle loan found by number or by insured name + property address.';
    } else if (loan.mortgageStatus !== 'ACTIVE') {
      note = `Loan found but mortgage status is ${loan.mortgageStatus}, not ACTIVE.`;
    } else if (matchStatus === 'matched_by_name_address') {
      note = 'Matched by insured name + property address (loan number did not resolve).';
    }

    return { matchStatus, loan, insurance, policyFound, oracleAvailable: true, note };
  } catch (err) {
    // Oracle-down: never fail the letter. Log it and route for manual review.
    log?.warn('Oracle lookup failed; routing letter for manual review', {
      reason: err instanceof Error ? err.message : String(err),
    });
    return {
      matchStatus: 'no_match',
      loan: null,
      insurance: null,
      policyFound: false,
      oracleAvailable: false,
      note: 'Oracle was unreachable during lookup — letter routed for manual review.',
    };
  }
}
