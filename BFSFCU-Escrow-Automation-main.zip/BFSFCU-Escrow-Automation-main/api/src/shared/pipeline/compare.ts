/**
 * Compare an extracted letter against the insurance record on file in Oracle.
 *
 * Produces the rows that drive the review screen's Comparison table
 * (Field | On File | New Letter | Result), plus the premium delta and a set of
 * non-routing flags. Per the locked decisions, these flags are shown to help the
 * reviewer decide whether to move an item to Task — they do NOT auto-route.
 */

import { carriersMatch, idsMatch } from '../normalize';
import type { InsuranceOnFile } from '../oracle';
import type { NormalizedLetter } from '../ai/openai';

/** One row of the Comparison table. `onFile` / `letter` are display strings. */
export interface CompareRow {
  field: string;
  onFile: string | null;
  letter: string | null;
  result: 'match' | 'changed' | 'new' | 'missing';
}

export interface CompareResult {
  rows: CompareRow[];
  premiumDelta: number | null;
  premiumDeltaPct: number | null;
  flags: string[];
}

/** Premium change (either direction) beyond this percentage raises a flag. */
const PREMIUM_FLAG_PCT = 5;

function money(n: number | null | undefined): string | null {
  if (n === null || n === undefined) return null;
  return n.toLocaleString('en-US', { style: 'currency', currency: 'USD' });
}

/** Compare two display values; both present + unequal = changed. */
function rowResult(
  onFile: string | null,
  letter: string | null,
  equal: boolean
): CompareRow['result'] {
  if (onFile === null && letter === null) return 'missing';
  if (onFile === null) return 'new'; // nothing on file to compare against
  if (letter === null) return 'missing';
  return equal ? 'match' : 'changed';
}

export function compareToOnFile(
  letter: NormalizedLetter,
  insurance: InsuranceOnFile | null
): CompareResult {
  const flags: string[] = [];
  const rows: CompareRow[] = [];

  if (!insurance) {
    // Nothing on file — every letter field is "new". Still show the letter side
    // so the reviewer sees what would be recorded.
    const push = (field: string, letterVal: string | null) =>
      rows.push({ field, onFile: null, letter: letterVal, result: letterVal === null ? 'missing' : 'new' });
    push('Carrier', letter.carrier);
    push('Policy #', letter.policyNumber);
    push('Policy type', letter.policyType);
    push('Dwelling coverage', money(letter.dwellingCoverage));
    push('Total premium', money(letter.totalPremium));
    push('Period start', letter.policyPeriodStart);
    push('Period end', letter.policyPeriodEnd);
    flags.push('no_insurance_on_file');
    return { rows, premiumDelta: null, premiumDeltaPct: null, flags };
  }

  // Carrier
  {
    const equal = carriersMatch(insurance.carrier, letter.carrier);
    rows.push({
      field: 'Carrier',
      onFile: insurance.carrier ?? null,
      letter: letter.carrier,
      result: rowResult(insurance.carrier ?? null, letter.carrier, equal),
    });
    if (insurance.carrier && letter.carrier && !equal) flags.push('carrier_change');
  }

  // Policy #
  {
    const equal = idsMatch(insurance.policyNumber, letter.policyNumber);
    rows.push({
      field: 'Policy #',
      onFile: insurance.policyNumber ?? null,
      letter: letter.policyNumber,
      result: rowResult(insurance.policyNumber ?? null, letter.policyNumber, equal),
    });
    if (insurance.policyNumber && letter.policyNumber && !equal) flags.push('policy_change');
  }

  // Policy type
  {
    const equal =
      (insurance.policyType ?? '').toUpperCase().replace(/\s/g, '') ===
      (letter.policyType ?? '').toUpperCase().replace(/\s/g, '');
    rows.push({
      field: 'Policy type',
      onFile: insurance.policyType ?? null,
      letter: letter.policyType,
      result: rowResult(insurance.policyType ?? null, letter.policyType, equal),
    });
  }

  // Dwelling coverage
  {
    const equal = insurance.dwellingCoverage === letter.dwellingCoverage;
    rows.push({
      field: 'Dwelling coverage',
      onFile: money(insurance.dwellingCoverage),
      letter: money(letter.dwellingCoverage),
      result: rowResult(money(insurance.dwellingCoverage), money(letter.dwellingCoverage), equal),
    });
    if (
      insurance.dwellingCoverage !== null &&
      letter.dwellingCoverage !== null &&
      insurance.dwellingCoverage !== letter.dwellingCoverage
    ) {
      flags.push('coverage_change');
    }
  }

  // Total premium (+ delta)
  let premiumDelta: number | null = null;
  let premiumDeltaPct: number | null = null;
  {
    const equal = insurance.premium === letter.totalPremium;
    rows.push({
      field: 'Total premium',
      onFile: money(insurance.premium),
      letter: money(letter.totalPremium),
      result: rowResult(money(insurance.premium), money(letter.totalPremium), equal),
    });
    if (insurance.premium !== null && letter.totalPremium !== null) {
      premiumDelta = Math.round((letter.totalPremium - insurance.premium) * 100) / 100;
      if (insurance.premium !== 0) {
        premiumDeltaPct = Math.round((premiumDelta / insurance.premium) * 10000) / 100;
        if (Math.abs(premiumDeltaPct) > PREMIUM_FLAG_PCT) flags.push('premium_change_gt_5pct');
      }
    }
  }

  // Period
  rows.push({
    field: 'Period start',
    onFile: insurance.periodStart,
    letter: letter.policyPeriodStart,
    result: rowResult(insurance.periodStart, letter.policyPeriodStart, insurance.periodStart === letter.policyPeriodStart),
  });
  rows.push({
    field: 'Period end',
    onFile: insurance.periodEnd,
    letter: letter.policyPeriodEnd,
    result: rowResult(insurance.periodEnd, letter.policyPeriodEnd, insurance.periodEnd === letter.policyPeriodEnd),
  });

  return { rows, premiumDelta, premiumDeltaPct, flags };
}
