/**
 * Central configuration. Every setting is read here and nowhere else.
 *
 * Secrets are NOT stored in code or in the database. Managed Identity covers
 * Postgres, Blob, Queue, Document Intelligence and Azure OpenAI; Key Vault
 * references (via App Settings) cover third-party credentials — including the
 * Oracle password (`ORACLE_PASSWORD`).
 *
 * The Oracle *connection* (host / port / service / user / enabled) is configured
 * from the admin UI and stored in `app_settings` — see repository/settings.ts and
 * shared/oracle/. Only the Oracle password lives here, so no secret ever lands in
 * the database, consistent with the AP platform's "no secret in the DB" rule.
 */

function required(name: string): string {
  const v = process.env[name];
  if (!v || v.trim() === '') {
    throw new Error(`Missing required setting: ${name}`);
  }
  return v;
}

function optional(name: string, fallback: string): string {
  const v = process.env[name];
  return v && v.trim() !== '' ? v : fallback;
}

function bool(name: string, fallback: boolean): boolean {
  const v = process.env[name];
  if (v === undefined || v.trim() === '') return fallback;
  return v.toLowerCase() === 'true' || v === '1';
}

function int(name: string, fallback: number): number {
  const v = process.env[name];
  if (!v) return fallback;
  const n = Number.parseInt(v, 10);
  return Number.isNaN(n) ? fallback : n;
}

export const config = {
  auth: {
    /**
     * Secret used to sign and verify session tokens (HS256).
     *
     * Must be a strong random value, set only on the server (never shipped to
     * the browser), and rotated by changing this setting. In production put it
     * in Key Vault. Local development uses a fixed development value if unset.
     */
    get sessionSecret() {
      return optional('SESSION_SECRET', 'dev-only-insecure-session-secret-change-me');
    },
    /** Session lifetime. Accepts values like '8h', '12h', '7d'. */
    get sessionTtl() {
      return optional('SESSION_TTL', '12h');
    },
    /**
     * Whether the session cookie is marked Secure. True in Azure (HTTPS);
     * false locally over plain HTTP so the cookie is accepted.
     */
    get cookieSecure() {
      return !bool('AUTH_COOKIE_INSECURE', false);
    },
  },

  db: {
    get host() {
      return required('PG_HOST');
    },
    get port() {
      return int('PG_PORT', 5432);
    },
    get database() {
      return required('PG_DATABASE');
    },
    get user() {
      return required('PG_USER');
    },
    /** Only used for local development; production uses Managed Identity. */
    get password() {
      return process.env['PG_PASSWORD'] ?? '';
    },
    get ssl() {
      return bool('PG_SSL', true);
    },
    get useManagedIdentity() {
      return bool('PG_USE_MANAGED_IDENTITY', true);
    },
    get maxConnections() {
      return int('PG_MAX_CONNECTIONS', 5);
    },
  },

  storage: {
    get blobAccountUrl() {
      return required('BLOB_ACCOUNT_URL');
    },
    /** Container for scanned escrow letters. */
    get blobContainer() {
      return optional('BLOB_CONTAINER', 'letters');
    },
    get queueAccountUrl() {
      return required('QUEUE_ACCOUNT_URL');
    },
    get queueName() {
      return optional('QUEUE_NAME', 'letter-jobs');
    },
    /** Queue for the classify-and-split stage (multi-letter uploads). */
    get classifyQueueName() {
      return optional('CLASSIFY_QUEUE_NAME', 'classify-jobs');
    },
  },

  ai: {
    get docIntelEndpoint() {
      return required('DOCINTEL_ENDPOINT');
    },
    get docIntelApiVersion() {
      return optional('DOCINTEL_API_VERSION', '2024-11-30');
    },
    /**
     * Optional API key for Document Intelligence.
     *
     * Managed Identity is the production path and needs no key. A key is
     * supported for local development, where setting up RBAC on the AI
     * resource is more friction than it is worth. Keep keys in
     * local.settings.json (gitignored) or Key Vault — never in the database.
     */
    get docIntelKey() {
      return process.env['DOCINTEL_KEY'] ?? '';
    },
    /**
     * Document Intelligence model for letter extraction.
     *
     * `prebuilt-layout` returns full text + key/value pairs for an arbitrary
     * form, which is what these escrow letters are — there is no prebuilt model
     * for a "property insurance modification". Stage 2 (Azure OpenAI) reads that
     * text and pulls the 11 fields. A custom model trained on real letters can be
     * dropped in later by changing this one value (Appendix A of the SOW).
     */
    get docIntelModel() {
      return optional('DOCINTEL_MODEL', 'prebuilt-layout');
    },

    /**
     * Multi-letter classification & auto-split (stage 0).
     *
     * A single uploaded PDF can contain several letters. When enabled, the file
     * is first sent to a trained Document Intelligence custom classifier with
     * `split=auto`, which returns per-letter page ranges; each range is sliced
     * into its own PDF and processed as a separate letter.
     *
     * Off by default: with no classifier id (and no stub) nothing changes and an
     * upload stays one letter. `DOCINTEL_CLASSIFIER_ID` is the trained model id.
     * For local development without a tenant, `CLASSIFY_STUB_SEGMENTS` (e.g.
     * "1-2,3-4") fakes the segment ranges so the split path can be exercised.
     */
    get classifyEnabled() {
      const on = bool('DOCINTEL_CLASSIFY_ENABLED', false);
      const configured =
        (process.env['DOCINTEL_CLASSIFIER_ID'] ?? '').trim() !== '' ||
        (process.env['CLASSIFY_STUB_SEGMENTS'] ?? '').trim() !== '';
      return on && configured;
    },
    /** Trained Document Intelligence custom classifier id. */
    get docIntelClassifierId() {
      return optional('DOCINTEL_CLASSIFIER_ID', '');
    },
    /**
     * Dev-only stub for the classifier: a comma list of page ranges treated as
     * the split segments, e.g. "1-2,3-4". Takes precedence over the real
     * classifier so the split path is testable without a tenant. Never set in
     * production.
     */
    get classifyStubSegments() {
      return optional('CLASSIFY_STUB_SEGMENTS', '');
    },
    /**
     * Optional allow-list of classifier categories (docTypes) that count as a
     * letter. Comma-separated; empty means accept every detected segment.
     */
    get classifyLetterDocTypes() {
      return optional('DOCINTEL_LETTER_DOCTYPES', '');
    },

    /**
     * Per-policy split (stage-2 fan-out).
     *
     * Classification (above) splits an upload into separate DOCUMENTS. A single
     * document can still describe more than one policy (several properties on one
     * notice). When enabled, the extractor lists every distinct policy it sees; if
     * two or more clear the confidence floor, the letter is fanned out into one
     * task per policy — each task pointing at the SAME document blob (the page
     * image is shared; nothing is re-sliced). Off by default, so behaviour is
     * unchanged until a tenant turns it on.
     */
    get policySplitEnabled() {
      return bool('DOCINTEL_POLICY_SPLIT_ENABLED', false);
    },
    /**
     * Minimum per-policy confidence (0–1) for a detected policy to count toward,
     * and take part in, a split. Keeps a faint or misread number from spawning a
     * phantom task. Default 0.7.
     */
    get policySplitMinConfidence() {
      const v = Number.parseFloat(process.env['DOCINTEL_POLICY_SPLIT_MIN_CONFIDENCE'] ?? '');
      return Number.isFinite(v) && v >= 0 && v <= 1 ? v : 0.7;
    },

    get openAiEndpoint() {
      return required('AOAI_ENDPOINT');
    },
    get openAiDeployment() {
      return optional('AOAI_DEPLOYMENT', 'gpt-4o');
    },
    get openAiApiVersion() {
      return optional('AOAI_API_VERSION', '2024-08-01-preview');
    },
    /** Optional API key for Azure OpenAI. See docIntelKey. */
    get openAiKey() {
      return process.env['AOAI_KEY'] ?? '';
    },
    /**
     * Whether the deployment is a reasoning model (gpt-5.x, o-series).
     *
     * Reasoning models reject `max_tokens` — they require
     * `max_completion_tokens` — and accept only the default `temperature`.
     * Set false for gpt-4o-style deployments, which take both.
     */
    get openAiReasoningModel() {
      return bool('AOAI_REASONING_MODEL', true);
    },
  },

  /**
   * Oracle loan-lookup connector (read-only).
   *
   * The application reaches the credit union's Oracle DB through a thin,
   * read-only data-access layer (shared/oracle/) to look up the loan, validate an
   * active mortgage, confirm the property address, and read the insurance record
   * on file. Writing this layer against an interface keeps it swappable and the
   * first release read-only (SOW §6).
   *
   * Connection details (host / port / service / user / enabled) are set from the
   * admin UI and stored in `app_settings`; only the PASSWORD is read here, from
   * `ORACLE_PASSWORD` (Key Vault / Function App settings) — so no secret is ever
   * written to the database. See shared/oracle/connection.ts.
   */
  oracle: {
    /** Keep in Key Vault / Function App settings — never in the repo or the DB. */
    get password() {
      return process.env['ORACLE_PASSWORD'] ?? '';
    },
    /** node-oracledb runs in Thin mode by default (no Oracle Client install). */
    get thinMode() {
      return bool('ORACLE_THIN_MODE', true);
    },
  },

  /**
   * Escalation email notifications.
   *
   * The app does NOT send mail itself and holds no mailbox permission or secret.
   * On escalation it POSTs the composed email as JSON to a Logic App HTTP trigger
   * (LOGIC_APP_URL — a signed URL, kept in Key Vault). The Logic App, owned by the
   * client's IT, sends the mail through a connection they govern (Office 365
   * Outlook connector, SMTP relay, …), so the trust boundary for sending stays in
   * their resource. HTTP (not a queue) is used so the email goes out immediately.
   *
   * Degrades gracefully: with NOTIFICATIONS_ENABLED off (or no URL set), an
   * escalation still commits and simply posts nothing.
   */
  notifications: {
    /** Master switch. Off by default so an unconfigured stack posts nothing. */
    get enabled() {
      return bool('NOTIFICATIONS_ENABLED', false);
    },
    /** The Logic App HTTP trigger URL (includes its SAS signature). Keep in Key Vault. */
    get logicAppUrl() {
      return process.env['LOGIC_APP_URL'] ?? '';
    },
    /**
     * Base URL of the web app, for the "Open the letter" deep link in emails.
     * Defaults to the first configured CORS origin (ALLOWED_ORIGINS) — the web
     * app URL — so it need not be set twice. Set APP_BASE_URL only to override
     * (e.g. a vanity domain that differs from the CORS origin).
     */
    get appBaseUrl() {
      const explicit = optional('APP_BASE_URL', '').replace(/\/$/, '');
      if (explicit) return explicit;
      const firstOrigin = (optional('ALLOWED_ORIGINS', '').split(',')[0] ?? '').trim();
      return firstOrigin.replace(/\/$/, '');
    },
  },

  /**
   * Microsoft Graph — Out-of-Office lookups only.
   *
   * (Sending mail moved to the Logic App queue above; Graph no longer sends.)
   * Reading mailbox settings is an application permission, so a confidential
   * client is required. Two auth modes, mirroring the AI credential:
   *   1. Client secret (GRAPH_CLIENT_SECRET) — local dev and simple production.
   *   2. Managed Identity (no secret) — the Function App identity must hold the
   *      Graph app role MailboxSettings.Read.
   *
   * Degrades gracefully: with GRAPH_ENABLED off (or Graph unreachable) OOO status
   * simply reads "unknown". OOO is deferred — this block is here for that work.
   */
  graph: {
    /** Master switch. Off by default so an unconfigured stack never calls Graph. */
    get enabled() {
      return bool('GRAPH_ENABLED', false);
    },
    get tenantId() {
      return process.env['GRAPH_TENANT_ID'] ?? '';
    },
    get clientId() {
      return process.env['GRAPH_CLIENT_ID'] ?? '';
    },
    /** Confidential-client secret. Key Vault in prod; absent → Managed Identity. */
    get clientSecret() {
      return process.env['GRAPH_CLIENT_SECRET'] ?? '';
    },
    /** How long (ms) a user's Out-of-Office status is cached. Default 5 min. */
    get oooCacheTtlMs() {
      return int('GRAPH_OOO_CACHE_TTL_MS', 5 * 60_000);
    },
  },

  http: {
    get allowedOrigins() {
      return optional('ALLOWED_ORIGINS', '')
        .split(',')
        .map((o) => o.trim())
        .filter(Boolean);
    },
  },

  /**
   * Demo mode. When enabled, the demo-reset endpoint is available so a
   * presenter can wipe transactional data between demos. MUST be left unset
   * (false) in production — the reset endpoint 404s when this is off.
   */
  demo: {
    get enabled() {
      return bool('DEMO_MODE', false);
    },
  },

  logLevel: optional('LOG_LEVEL', 'info'),
  isLocal: process.env['AZURE_FUNCTIONS_ENVIRONMENT'] === 'Development',
} as const;
