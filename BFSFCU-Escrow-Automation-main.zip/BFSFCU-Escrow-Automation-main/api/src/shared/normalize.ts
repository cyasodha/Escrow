/**
 * Field normalization for matching and tiering.
 *
 * Fuzzy matching is used to *find* the Oracle record; the confidence tier is
 * based on how exactly the found record equals the letter. Both need the same
 * normalization so "Rd" == "Road" and "Allstate" == "Allstate Inc." are treated
 * consistently across the connector (which locates the loan) and the tiering
 * (which decides High vs Low).
 *
 * This module is domain-neutral and imports nothing else, so both
 * `shared/oracle/` and `shared/pipeline/` can use it without a cycle.
 */

function squish(value: string): string {
  return value.trim().replace(/\s+/g, ' ');
}

/**
 * A person / insured name. Case- and punctuation-insensitive; collapses runs of
 * whitespace. "O'Brien, Jr." and "OBrien Jr" normalize alike.
 */
export function normalizeName(value: string | null | undefined): string {
  if (!value) return '';
  return squish(value.toUpperCase().replace(/[.,'`-]/g, ' ').replace(/\s+/g, ' '));
}

/** Common US street-type abbreviations, expanded to a canonical full word. */
const STREET_TYPES: Record<string, string> = {
  ST: 'STREET', STR: 'STREET',
  RD: 'ROAD',
  AVE: 'AVENUE', AV: 'AVENUE',
  BLVD: 'BOULEVARD',
  CT: 'COURT',
  CIR: 'CIRCLE',
  DR: 'DRIVE',
  LN: 'LANE',
  PKWY: 'PARKWAY', PKY: 'PARKWAY',
  HWY: 'HIGHWAY',
  PL: 'PLACE',
  TER: 'TERRACE', TERR: 'TERRACE',
  SQ: 'SQUARE',
  TRL: 'TRAIL',
  PT: 'POINT',
  XING: 'CROSSING',
};

const DIRECTIONALS: Record<string, string> = {
  N: 'NORTH', S: 'SOUTH', E: 'EAST', W: 'WEST',
  NE: 'NORTHEAST', NW: 'NORTHWEST', SE: 'SOUTHEAST', SW: 'SOUTHWEST',
};

/**
 * A property / situs address. Upper-cases, drops punctuation, and expands the
 * common street-type and directional abbreviations so that
 * "1560 Perkins Rd, Baton Rouge, LA 70808" and
 * "1560 Perkins Road Baton Rouge LA 70808" normalize identically.
 */
export function normalizeAddress(value: string | null | undefined): string {
  if (!value) return '';
  const words = squish(value.toUpperCase().replace(/[.,#]/g, ' '))
    .split(' ')
    .filter(Boolean)
    .map((w) => STREET_TYPES[w] ?? DIRECTIONALS[w] ?? w);
  return words.join(' ');
}

/**
 * An account identifier — loan #, policy #. Compared exactly with all
 * formatting (dashes, spaces) stripped and letters upper-cased, so
 * "ALS-7729014" == "als 7729014". Leading zeros are significant and preserved.
 */
export function normalizeId(value: string | null | undefined): string {
  if (!value) return '';
  return value.toUpperCase().replace(/[^A-Z0-9]/g, '');
}

/** Legal-suffix / descriptor noise stripped from a carrier name before compare. */
const CARRIER_NOISE = new Set([
  'INC', 'INCORPORATED', 'LLC', 'CO', 'COMPANY', 'CORP', 'CORPORATION',
  'INSURANCE', 'ASSURANCE', 'MUTUAL', 'GROUP', 'THE', 'AND', '&',
]);

/**
 * A carrier name. "Allstate" == "Allstate Inc." == "Allstate Insurance Group"
 * after upper-casing, dropping punctuation, and removing legal/descriptor words.
 */
export function normalizeCarrier(value: string | null | undefined): string {
  if (!value) return '';
  return squish(value.toUpperCase().replace(/[.,&]/g, ' '))
    .split(' ')
    .filter((w) => w && !CARRIER_NOISE.has(w))
    .join(' ');
}

export function namesMatch(a: string | null | undefined, b: string | null | undefined): boolean {
  const na = normalizeName(a);
  const nb = normalizeName(b);
  return na !== '' && na === nb;
}

export function addressesMatch(a: string | null | undefined, b: string | null | undefined): boolean {
  const na = normalizeAddress(a);
  const nb = normalizeAddress(b);
  return na !== '' && na === nb;
}

export function idsMatch(a: string | null | undefined, b: string | null | undefined): boolean {
  const na = normalizeId(a);
  const nb = normalizeId(b);
  return na !== '' && na === nb;
}

export function carriersMatch(a: string | null | undefined, b: string | null | undefined): boolean {
  const na = normalizeCarrier(a);
  const nb = normalizeCarrier(b);
  return na !== '' && na === nb;
}
