/**
 * Work-distribution weights.
 *
 * Capacity is a *relative weight*, not a hard cap. Auto-distribution is
 * weighted least-loaded: each new letter goes to the eligible Escrow Admin with
 * the lowest `open / weight` ratio, so a Heavy admin steadily accumulates more
 * work than a Light one without any ceiling.
 *
 * The three numbers below are the only place the ratios live; the Team Workload
 * screen reads them (via the API) to size its load bars, and the picker uses
 * them to choose an assignee.
 */

export type CapacityLevel = 'light' | 'regular' | 'heavy';

export const CAPACITY_WEIGHT: Record<CapacityLevel, number> = {
  light: 8,
  regular: 15,
  heavy: 25,
};

export const CAPACITY_LEVELS: readonly CapacityLevel[] = ['light', 'regular', 'heavy'] as const;

export function isCapacityLevel(v: unknown): v is CapacityLevel {
  return v === 'light' || v === 'regular' || v === 'heavy';
}

export function capacityWeight(level: CapacityLevel): number {
  return CAPACITY_WEIGHT[level] ?? CAPACITY_WEIGHT.regular;
}

/** A candidate for auto-distribution and their current open load. */
export interface AssigneeLoad {
  userId: string;
  capacity: CapacityLevel;
  openCount: number;
}

/**
 * Weighted least-loaded pick. Returns the userId whose load ratio
 * (open+1)/weight would be smallest after taking one more letter, or null when
 * the pool is empty. Deterministic tie-break by userId keeps tests stable.
 */
export function pickAssignee(pool: readonly AssigneeLoad[]): string | null {
  if (pool.length === 0) return null;
  let best: AssigneeLoad | null = null;
  let bestRatio = Infinity;
  for (const c of pool) {
    const ratio = (c.openCount + 1) / capacityWeight(c.capacity);
    if (ratio < bestRatio || (ratio === bestRatio && (!best || c.userId < best.userId))) {
      best = c;
      bestRatio = ratio;
    }
  }
  return best ? best.userId : null;
}
