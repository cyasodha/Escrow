/**
 * Nightly Out-of-Office sync.
 *
 * At the business cutoff, read each Escrow Admin's Outlook OOO for the NEXT
 * working day and set users.ooo_auto accordingly (admins who returned are
 * re-included). The assignment layer (eligiblePool) then splits new letters only
 * among the present admins.
 *
 * Two entry points call runOooSync:
 *   - the timer (functions/timer/oooSync.ts) — obeys ooo_sync_enabled + the
 *     configured cutoff/timezone, once per day;
 *   - the "Run now" admin endpoint — force = true, bypassing the schedule.
 * Both require Microsoft Graph to be enabled. If Graph can't be reached, the sync
 * ABORTS without touching ooo_auto (never clobber a good state on a blip).
 */

import {
  getCalendar,
  nextActivity,
  todayInZone,
  minutesInZone,
  toMinutes,
  getOooSyncLastRun,
  setOooSyncLastRun,
} from './schedule';
import { graphConfigured, getOutOnDate } from './graph/client';
import { listEscrowAdmins, applyOooAuto } from './repository/users';
import { query } from './db';
import type { Logger } from './logger';

export interface OooSyncResult {
  ran: boolean;
  /** Present when ran = false: why it was skipped. */
  reason?: 'graph-disabled' | 'sync-disabled' | 'before-cutoff' | 'already-ran-today' | 'graph-error';
  targetDate?: string;
  markedOut?: string[];
  totalAdmins?: number;
}

export async function runOooSync(opts: { force: boolean; log: Logger }): Promise<OooSyncResult> {
  const { force, log } = opts;
  const cal = await getCalendar();

  // Graph is required either way — we can't read OOO without it.
  if (!graphConfigured()) return { ran: false, reason: 'graph-disabled' };

  const today = todayInZone(cal.timezone);
  if (!force) {
    if (!cal.oooSyncEnabled) return { ran: false, reason: 'sync-disabled' };
    if (minutesInZone(new Date(), cal.timezone) < toMinutes(cal.workCutoff)) {
      return { ran: false, reason: 'before-cutoff' };
    }
    if ((await getOooSyncLastRun()) === today) return { ran: false, reason: 'already-ran-today' };
  }

  // Target the day letters received "now" are being assigned for — same logic as
  // assignment dating. In-hours on a working day → today; after the end of day /
  // weekend / holiday → the next working day. So a manual run before end-of-day
  // reflects TODAY's OOO, and only excludes next-day OOO once past the cutoff.
  const targetDate = nextActivity(new Date(), cal).taskDate;
  const admins = await listEscrowAdmins();

  let outMap: Record<string, boolean>;
  try {
    outMap = await getOutOnDate(
      admins.map((a) => a.email),
      targetDate,
      cal.timezone,
      log
    );
  } catch (err) {
    log.warn('OOO sync aborted — Graph unavailable', {
      reason: err instanceof Error ? err.message : String(err),
    });
    return { ran: false, reason: 'graph-error' };
  }

  const outAdmins = admins.filter((a) => a.email && outMap[a.email.toLowerCase()]);
  const outIds = outAdmins.map((a) => a.id);
  const markedOut = outAdmins.map((a) => a.fullName ?? a.email ?? a.id);

  const counts = await applyOooAuto(outIds);
  // Only the automatic (timer) run "consumes" the day. A manual run refreshes
  // ooo_auto but must NOT stamp last_run, so the scheduled run at cutoff still
  // fires later that day.
  if (!force) await setOooSyncLastRun(today);

  await query(
    `INSERT INTO audit_logs (entity_type, entity_id, action, metadata)
     VALUES ('ooo_sync', NULL, 'ooo_synced', $1::jsonb)`,
    [JSON.stringify({ targetDate, markedOut, total: counts.total, trigger: force ? 'manual' : 'timer' })]
  );

  log.info('OOO sync complete', { targetDate, markedOut: markedOut.length, total: counts.total });
  return { ran: true, targetDate, markedOut, totalAdmins: counts.total };
}
