/**
 * Storage Queue — letter processing jobs.
 *
 * The queue is what lets an upload return in ~1 second while the multi-second AI
 * pipeline (extract → Oracle match → compare → tier) runs in the background. It
 * also gives us automatic retry and, after `maxDequeueCount` (5, set in
 * host.json), a poison queue.
 *
 * The poison queue is the "needs a human" list. Monitor it — an unwatched
 * poison queue is silent data loss with extra steps.
 */

import { QueueServiceClient, QueueClient } from '@azure/storage-queue';
import { DefaultAzureCredential } from '@azure/identity';
import { config } from './config';

export type LetterSource = 'manual_upload' | 'email_ingest' | 'api_ingest';

/** Message placed on the queue for each letter awaiting processing. */
export interface LetterJob {
  letterId: string;
  blobPath: string;
  fileHash: string;
  source: LetterSource;
  /** Incremented by the worker when it re-queues deliberately. */
  attempt?: number;
  /**
   * Set on a per-policy fan-out job: extract only this policy from a document
   * that holds several. Its presence also tells the worker this job is a scoped
   * child, so it must NOT run policy detection again (no re-fan-out).
   */
  policyHint?: string;
}

/**
 * Message for the classify-and-split stage. Carries the original uploaded file
 * (which may hold several letters) plus the anchor letter row already created
 * for it, and enough context to create sibling rows for the extra letters.
 */
export interface ClassifyJob {
  /** The letter row already created for this upload (segment 0 reuses it). */
  letterId: string;
  /** The original (possibly multi-letter) uploaded blob. */
  blobPath: string;
  fileHash: string;
  source: LetterSource;
  originalFilename: string;
  submittedBy: string;
  assignedTo: string | null;
}

const clients = new Map<string, QueueClient>();

function connectionString(): string | undefined {
  const cs = process.env['AzureWebJobsStorage'];
  return cs && cs.includes('=') ? cs : undefined;
}

async function getQueue(name: string): Promise<QueueClient> {
  const existing = clients.get(name);
  if (existing) return existing;

  const cs = connectionString();
  const service = cs
    ? QueueServiceClient.fromConnectionString(cs)
    : new QueueServiceClient(config.storage.queueAccountUrl, new DefaultAzureCredential());

  const client = service.getQueueClient(name);
  await client.createIfNotExists();

  clients.set(name, client);
  return client;
}

/** The Functions queue trigger expects base64 for JSON payloads (host default). */
async function send(queueName: string, job: unknown): Promise<void> {
  const queue = await getQueue(queueName);
  const payload = Buffer.from(JSON.stringify(job)).toString('base64');
  await queue.sendMessage(payload);
}

/** Queue a letter for processing (OCR → extract → match → route). */
export async function enqueueLetterJob(job: LetterJob): Promise<void> {
  await send(config.storage.queueName, job);
}

/** Queue an uploaded file for classification & splitting into per-letter jobs. */
export async function enqueueClassifyJob(job: ClassifyJob): Promise<void> {
  await send(config.storage.classifyQueueName, job);
}

/** Parse a queue message body into JSON, whether or not it arrives base64. */
function parseMessage<T>(raw: unknown): T {
  if (typeof raw === 'object' && raw !== null) {
    return raw as T;
  }

  if (typeof raw === 'string') {
    // The host usually decodes base64 for us; handle the raw case defensively.
    try {
      return JSON.parse(raw) as T;
    } catch {
      return JSON.parse(Buffer.from(raw, 'base64').toString('utf8')) as T;
    }
  }

  throw new Error('Unrecognised queue message payload');
}

export function parseLetterJob(raw: unknown): LetterJob {
  return parseMessage<LetterJob>(raw);
}

export function parseClassifyJob(raw: unknown): ClassifyJob {
  return parseMessage<ClassifyJob>(raw);
}
