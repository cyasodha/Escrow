/**
 * Escalation notification — composes the email and POSTs it to the Logic App
 * HTTP trigger (shared/notifications/sender.ts) for immediate delivery.
 *
 * POST-COMMIT, best-effort: the escalation is already persisted by the time this
 * runs, so a delivery hiccup must never fail the request. notifyEscalation NEVER
 * throws — it logs and returns. The actual send happens in the Logic App.
 */

import { config } from '../config';
import { postNotification } from './sender';
import * as users from '../repository/users';
import * as letters from '../repository/letters';
import type { AppUser } from '../repository/users';
import type { LetterRow } from '../repository/letters';
import type { Logger } from '../logger';

function esc(s: string | null | undefined): string {
  return (s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function composeEscalationHtml(input: {
  letter: LetterRow | undefined;
  byName: string;
  note: string;
}): string {
  const { letter, byName, note } = input;
  const link =
    letter && config.notifications.appBaseUrl
      ? `${config.notifications.appBaseUrl}/letters/${letter.id}`
      : null;

  const button = link
    ? `<p style="margin:20px 0 8px;">` +
      `<a href="${esc(link)}" style="background:#2563eb;color:#ffffff;text-decoration:none;` +
      `padding:10px 18px;border-radius:6px;font-weight:600;display:inline-block;">Open the letter</a>` +
      `</p>`
    : '';

  return (
    `<div style="font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:#111827;` +
    `max-width:560px;line-height:1.5;">` +
    `<p style="margin:0 0 16px;color:#374151;">` +
    `<strong>${esc(byName)}</strong> escalated a letter and asked you to review it.</p>` +
    `<div style="background:#fef2f2;border:1px solid #fecaca;border-radius:6px;padding:12px 14px;margin:12px 0;">` +
    `<div style="color:#991b1b;font-weight:700;font-size:12px;text-transform:uppercase;letter-spacing:.03em;margin-bottom:4px;">Escalation note</div>` +
    `<div style="color:#7f1d1d;">${esc(note)}</div>` +
    `</div>` +
    button +
    `<hr style="border:none;border-top:1px solid #e5e7eb;margin:20px 0 10px;">` +
    `<p style="margin:0;color:#9ca3af;font-size:12px;">BFSFCU Escrow Insurance Automation — automated notification.</p>` +
    `</div>`
  );
}

/**
 * Send an escalation notification for the target manager (POST to the Logic App).
 * Best-effort: skips (with a log line) when notifications are off or the target
 * has no email, and swallows delivery errors. Never throws.
 */
export async function notifyEscalation(
  input: { letterId: string; toManagerId: string; byUser: AppUser; note: string },
  log: Logger
): Promise<void> {
  if (!config.notifications.enabled || !config.notifications.logicAppUrl) {
    log.info('Notifications off or Logic App URL not set — escalation email skipped', {
      letterId: input.letterId,
    });
    return;
  }
  try {
    const manager = await users.findById(input.toManagerId);
    if (!manager?.email) {
      log.warn('Escalation target has no email — escalation email skipped', {
        toManagerId: input.toManagerId,
      });
      return;
    }

    const letter = await letters.getById(input.letterId);
    const byName = input.byUser.fullName ?? input.byUser.email ?? 'An escrow admin';
    const subject = 'A letter was escalated to you for review';

    await postNotification({
      type: 'escalation',
      to: manager.email,
      subject,
      html: composeEscalationHtml({ letter, byName, note: input.note }),
      meta: {
        letterId: input.letterId,
        escalatedById: input.byUser.id,
        escalatedByName: byName,
        managerId: manager.id,
      },
    });
    log.info('Escalation notification sent to Logic App', { letterId: input.letterId, to: manager.email });
  } catch (err) {
    log.warn('Escalation notification failed to send (non-fatal)', {
      letterId: input.letterId,
      reason: err instanceof Error ? err.message : String(err),
    });
  }
}
