/**
 * Notification sender — POSTs the composed email to a Logic App HTTP trigger.
 *
 * The app never sends mail; it hands the email to a Logic App (owned by the
 * client's IT) over HTTP so it goes out immediately. The trigger URL carries its
 * own SAS signature, so it is a secret — kept in LOGIC_APP_URL (Key Vault). The
 * app holds no mailbox permission and no mail credential of its own.
 *
 * The JSON body below IS what the Logic App's "When a HTTP request is received"
 * trigger receives — the fields are available directly as `triggerBody()?['to']`
 * etc., no queue message or decode step. See docs/notifications-logic-app.md.
 */

import { config } from '../config';

export interface NotificationMessage {
  /** Discriminator so the Logic App can branch/log by kind. */
  type: 'escalation';
  to: string;
  subject: string;
  html: string;
  /** Non-rendered context for logging / auditing on the Logic App side. */
  meta?: Record<string, unknown>;
}

/**
 * POST one notification to the Logic App. Retries once on a transient failure
 * (we no longer have a queue's durability). Throws if the URL is unset or the
 * Logic App does not accept the request.
 */
export async function postNotification(message: NotificationMessage): Promise<void> {
  const url = config.notifications.logicAppUrl;
  if (!url) throw new Error('LOGIC_APP_URL is not configured');

  const body = JSON.stringify(message);
  let lastErr: unknown;
  for (let attempt = 1; attempt <= 2; attempt++) {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body,
      });
      // A Logic App HTTP trigger returns 202 Accepted (or 200 with a Response
      // action) — any 2xx means it took the request.
      if (res.ok) return;
      const detail = await res.text().catch(() => '');
      throw new Error(`Logic App responded ${res.status}: ${detail.slice(0, 200)}`);
    } catch (err) {
      lastErr = err;
      if (attempt < 2) await new Promise((r) => setTimeout(r, 500));
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error(String(lastErr));
}
