/**
 * Blob Storage — scanned escrow letter documents.
 *
 * Production uses Managed Identity. Local development falls back to the
 * Azurite connection string in AzureWebJobsStorage.
 *
 * Files are private; the browser never gets a container URL. When a user needs
 * to view a document the API issues a short-lived SAS URL.
 */

import {
  BlobServiceClient,
  StorageSharedKeyCredential,
  generateBlobSASQueryParameters,
  BlobSASPermissions,
  SASProtocol,
} from '@azure/storage-blob';
import { DefaultAzureCredential } from '@azure/identity';
import { config } from './config';
import { AppError } from './errors';

let serviceClient: BlobServiceClient | undefined;

function connectionString(): string | undefined {
  const cs = process.env['AzureWebJobsStorage'];
  // A bare "UseDevelopmentStorage=true" or a full connection string.
  return cs && cs.includes('=') ? cs : undefined;
}

function getServiceClient(): BlobServiceClient {
  if (serviceClient) return serviceClient;

  const cs = connectionString();
  serviceClient = cs
    ? BlobServiceClient.fromConnectionString(cs)
    : new BlobServiceClient(config.storage.blobAccountUrl, new DefaultAzureCredential());

  return serviceClient;
}

async function getContainer() {
  const container = getServiceClient().getContainerClient(config.storage.blobContainer);
  // Safe to call repeatedly; no-op when it already exists.
  await container.createIfNotExists();
  return container;
}

/** Storage path for a new document: <container>/YYYY/MM/<uuid>.<ext> */
export function buildBlobPath(originalFilename: string, id: string): string {
  const now = new Date();
  const year = now.getUTCFullYear();
  const month = String(now.getUTCMonth() + 1).padStart(2, '0');
  const ext = originalFilename.split('.').pop()?.toLowerCase() ?? 'pdf';
  const safeExt = /^[a-z0-9]{1,5}$/.test(ext) ? ext : 'pdf';
  return `${year}/${month}/${id}.${safeExt}`;
}

/**
 * Validate a caller-supplied blob path and return the safe, container-relative
 * key. Used by the blob-reference ingest path, where the Logic App inbox flow
 * uploads the letter straight into the letters container — bypassing any
 * gateway/WAF request-body size limit — and posts only its path to the API.
 *
 * A leading `/` and an optional leading container segment are tolerated (the
 * Blob connector's `Path` output includes them) and stripped. Full URLs, `..`
 * traversal, and unsafe characters are rejected so a caller cannot steer the
 * API at an arbitrary blob. `downloadBlob` is already scoped to the letters
 * container, so the remaining surface is only which key within it.
 */
export function toContainerRelativePath(raw: string): string {
  let path = raw.trim();
  if (!path) throw AppError.validation('blobPath is empty');
  if (/^[a-z][a-z0-9+.\-]*:\/\//i.test(path)) {
    throw AppError.validation('blobPath must be a container path, not a full URL');
  }
  path = path.replace(/^\/+/, '');
  const prefix = config.storage.blobContainer.toLowerCase() + '/';
  if (path.toLowerCase().startsWith(prefix)) {
    path = path.slice(prefix.length);
  }
  if (path.includes('..') || !/^[A-Za-z0-9][A-Za-z0-9._\-/]{0,254}$/.test(path)) {
    throw AppError.validation('blobPath contains invalid characters');
  }
  return path;
}

export async function uploadBlob(
  path: string,
  content: Buffer,
  contentType: string
): Promise<void> {
  const container = await getContainer();
  const blob = container.getBlockBlobClient(path);
  await blob.uploadData(content, {
    blobHTTPHeaders: { blobContentType: contentType },
  });
}

export async function downloadBlob(path: string): Promise<Buffer> {
  const container = await getContainer();
  const blob = container.getBlockBlobClient(path);

  if (!(await blob.exists())) {
    throw AppError.notFound(`Document not found: ${path}`);
  }

  return blob.downloadToBuffer();
}

export async function deleteBlob(path: string): Promise<void> {
  const container = await getContainer();
  await container.getBlockBlobClient(path).deleteIfExists();
}

/**
 * Short-lived read URL for the browser.
 *
 * With Managed Identity there is no account key, so we sign with a user
 * delegation key — which is itself time-limited and tied to the identity.
 */
export async function getReadUrl(path: string, minutes = 15): Promise<string> {
  const container = await getContainer();
  const blob = container.getBlockBlobClient(path);

  if (!(await blob.exists())) {
    throw AppError.notFound(`Document not found: ${path}`);
  }

  const startsOn = new Date(Date.now() - 60_000); // small clock-skew allowance
  const expiresOn = new Date(Date.now() + minutes * 60_000);
  const service = getServiceClient();

  const credential = (service as unknown as { credential?: unknown }).credential;

  // Local development (Azurite) signs with the shared key.
  if (credential instanceof StorageSharedKeyCredential) {
    const sas = generateBlobSASQueryParameters(
      {
        containerName: config.storage.blobContainer,
        blobName: path,
        permissions: BlobSASPermissions.parse('r'),
        startsOn,
        expiresOn,
        protocol: SASProtocol.HttpsAndHttp,
      },
      credential
    ).toString();
    return `${blob.url}?${sas}`;
  }

  // Production: user delegation SAS via Managed Identity.
  const delegationKey = await service.getUserDelegationKey(startsOn, expiresOn);
  const accountName = service.accountName;
  const sas = generateBlobSASQueryParameters(
    {
      containerName: config.storage.blobContainer,
      blobName: path,
      permissions: BlobSASPermissions.parse('r'),
      startsOn,
      expiresOn,
      protocol: SASProtocol.Https,
    },
    delegationKey,
    accountName
  ).toString();

  return `${blob.url}?${sas}`;
}
