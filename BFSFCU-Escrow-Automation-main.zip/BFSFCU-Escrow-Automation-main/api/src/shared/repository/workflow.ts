/**
 * Letter workflow transitions: approve, decline, move-to-task, return, batch.
 *
 * Every transition writes an audit entry in the SAME transaction as the status
 * change, so an approval can never exist without its audit record.
 *
 * There is no automatic Exception routing: the Task queue is populated ONLY by a
 * reviewer calling moveToTask(). Downstream (payment / export) is on hold, so
 * approve() just records the decision — it stages nothing external.
 */

import { transaction } from '../db';
import { AppError } from '../errors';
import type { LetterStatus } from './letters';

interface StatusRow {
  id: string;
  status: LetterStatus;
  submitted_by: string | null;
  assigned_to: string | null;
  confidence_tier: 'high' | 'low' | null;
}

/** Statuses from which a letter may still be approved / declined / moved. */
const REVIEWABLE: readonly LetterStatus[] = ['high_confidence', 'low_confidence', 'task'];

async function lock(client: import('pg').PoolClient, letterId: string): Promise<StatusRow> {
  const found = await client.query<StatusRow>(
    `SELECT id, status, submitted_by, assigned_to, confidence_tier FROM letters WHERE id = $1 FOR UPDATE`,
    [letterId]
  );
  const row = found.rows[0];
  if (!row) throw AppError.notFound('Letter not found');
  return row;
}

/**
 * Escrow Admins may act only on letters assigned to them. Managers (ownerId
 * undefined) may act on any. Called inside the row lock.
 */
function assertOwner(letter: StatusRow, ownerId?: string): void {
  if (ownerId && letter.assigned_to !== ownerId) {
    throw AppError.forbidden('This letter is not assigned to you.');
  }
}

/**
 * Copy a Closure note into the letter's Notes, prefixed with the action taken
 * (e.g. "Declined — …"), in the same transaction. A blank note adds nothing.
 */
async function addClosureNote(
  client: import('pg').PoolClient,
  letterId: string,
  actorId: string,
  action: string,
  note?: string | null
): Promise<void> {
  const text = note?.trim();
  if (!text) return;
  await client.query(
    `INSERT INTO letter_notes (letter_id, user_id, body) VALUES ($1, $2, $3)`,
    [letterId, actorId, `${action} — ${text}`]
  );
}

export async function approve(
  letterId: string,
  actorId: string,
  note?: string,
  ownerId?: string
): Promise<void> {
  await transaction(async (client) => {
    const letter = await lock(client, letterId);
    assertOwner(letter, ownerId);

    if (letter.status === 'approved') {
      throw AppError.conflict('This letter has already been approved');
    }
    if (!REVIEWABLE.includes(letter.status)) {
      throw AppError.conflict(`A letter with status "${letter.status}" cannot be approved`);
    }

    await client.query(
      `UPDATE letters
          SET status = 'approved', approved_by = $2, approved_at = now(),
              declined_by = NULL, declined_at = NULL, checker_comment = NULL,
              escalated = false, escalated_at = NULL, escalated_by = NULL, escalated_to = NULL
        WHERE id = $1`,
      [letterId, actorId]
    );

    // Any user may approve any letter. Self-approval (approver == submitter) is
    // not blocked but is flagged in the audit trail so it is visible/reportable.
    const selfApproved = letter.submitted_by != null && letter.submitted_by === actorId;

    await client.query(
      `INSERT INTO audit_logs (entity_type, entity_id, action, user_id, metadata)
       VALUES ('letter', $1, 'approved', $2, $3::jsonb)`,
      [letterId, actorId, JSON.stringify({ from: letter.status, note: note ?? null, self_approved: selfApproved })]
    );
    await addClosureNote(client, letterId, actorId, 'Accepted', note);
  });
}

export async function decline(
  letterId: string,
  actorId: string,
  reason: string,
  ownerId?: string
): Promise<void> {
  if (!reason || reason.trim().length < 3) {
    throw AppError.validation('A decline reason is required');
  }

  await transaction(async (client) => {
    const letter = await lock(client, letterId);
    assertOwner(letter, ownerId);
    if (letter.status === 'rejected') {
      throw AppError.conflict('This letter has already been declined');
    }
    if (letter.status === 'approved') {
      throw AppError.conflict('An approved letter cannot be declined');
    }

    await client.query(
      `UPDATE letters
          SET status = 'rejected', declined_by = $2, declined_at = now(),
              checker_comment = $3, approved_by = NULL, approved_at = NULL,
              escalated = false, escalated_at = NULL, escalated_by = NULL, escalated_to = NULL
        WHERE id = $1`,
      [letterId, actorId, reason.trim()]
    );

    await client.query(
      `INSERT INTO audit_logs (entity_type, entity_id, action, user_id, metadata)
       VALUES ('letter', $1, 'declined', $2, $3::jsonb)`,
      [letterId, actorId, JSON.stringify({ from: letter.status, reason: reason.trim() })]
    );
    await addClosureNote(client, letterId, actorId, 'Declined', reason);
  });
}

/**
 * The ONLY way a letter enters the Task/Exception queue: a reviewer moves it
 * there manually (e.g. a cancellation that needs escalation/alignment, or a
 * premium change worth investigating). Not auto-routed.
 */
export async function moveToTask(
  letterId: string,
  actorId: string,
  reason: string,
  ownerId?: string
): Promise<void> {
  await transaction(async (client) => {
    const letter = await lock(client, letterId);
    assertOwner(letter, ownerId);
    if (letter.status === 'approved') {
      throw AppError.conflict('An approved letter cannot be moved to Task');
    }
    if (letter.status === 'task') {
      throw AppError.conflict('This letter is already in the Task queue');
    }

    await client.query(`UPDATE letters SET status = 'task' WHERE id = $1`, [letterId]);

    await client.query(
      `INSERT INTO audit_logs (entity_type, entity_id, action, user_id, metadata)
       VALUES ('letter', $1, 'moved_to_task', $2, $3::jsonb)`,
      [letterId, actorId, JSON.stringify({ from: letter.status, reason: reason || null })]
    );
    await addClosureNote(client, letterId, actorId, 'Moved to Action Required', reason);
  });
}

/**
 * Send a letter from Task back to a review queue. When no target is given, it
 * returns to the queue matching its ORIGINAL tier — a High-tier letter goes back
 * to High Confidence, not Low — so the tier and the queue never disagree.
 */
export async function returnToReview(
  letterId: string,
  actorId: string,
  reason: string,
  target?: 'high_confidence' | 'low_confidence'
): Promise<void> {
  await transaction(async (client) => {
    const letter = await lock(client, letterId);
    if (letter.status === 'approved') {
      throw AppError.conflict('An approved letter cannot be returned to review');
    }

    const dest = target ?? (letter.confidence_tier === 'high' ? 'high_confidence' : 'low_confidence');

    await client.query(
      `UPDATE letters SET status = $2::letter_status, checker_comment = $3 WHERE id = $1`,
      [letterId, dest, reason || null]
    );

    await client.query(
      `INSERT INTO audit_logs (entity_type, entity_id, action, user_id, metadata)
       VALUES ('letter', $1, 'returned_to_review', $2, $3::jsonb)`,
      [letterId, actorId, JSON.stringify({ from: letter.status, to: dest, reason: reason || null })]
    );
  });
}

/**
 * Edit the extracted insurance details (the 11 fields) on a letter that is still
 * awaiting a decision. Escrow Admins may edit only letters assigned to them
 * (ownerId set); Managers may edit any. The derived due date follows the policy
 * period start. Writes an 'edited' audit row in the same transaction.
 */
export interface LetterDetailsInput {
  insuredName: string | null;
  carrier: string | null;
  policyNumber: string | null;
  policyType: string | null;
  loanNumber: string | null;
  propertyAddress: string | null;
  reason: string | null;
  dwellingCoverage: string | null;
  totalPremium: string | null;
  policyPeriodStart: string | null;
  policyPeriodEnd: string | null;
  /**
   * Letter type + its coupled fields. `undefined` means "leave the type as-is"
   * (a details-only edit); a value (including null) replaces it. A reviewer uses
   * this to correct a misclassified renewal/cancellation. The subtype and
   * effective date only apply to a cancellation and are forced null otherwise.
   */
  letterType?: 'modification' | 'cancellation' | null;
  cancellationSubtype?: 'nonpayment' | 'provider_switch' | 'non_renewal' | null;
  cancellationEffectiveDate?: string | null;
}

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

export async function editLetterDetails(
  letterId: string,
  actorId: string,
  fields: LetterDetailsInput,
  ownerId?: string
): Promise<void> {
  const start = fields.policyPeriodStart && DATE_RE.test(fields.policyPeriodStart) ? fields.policyPeriodStart : null;
  const end = fields.policyPeriodEnd && DATE_RE.test(fields.policyPeriodEnd) ? fields.policyPeriodEnd : null;

  // Type is edited only when explicitly provided; a details-only edit leaves it
  // untouched. Subtype + effective date are meaningful only for a cancellation.
  const editType = fields.letterType !== undefined;
  const letterType =
    fields.letterType === 'modification' || fields.letterType === 'cancellation'
      ? fields.letterType
      : null;
  const subtype =
    letterType === 'cancellation' &&
    (fields.cancellationSubtype === 'nonpayment' ||
      fields.cancellationSubtype === 'provider_switch' ||
      fields.cancellationSubtype === 'non_renewal')
      ? fields.cancellationSubtype
      : null;
  const cancelEff =
    letterType === 'cancellation' &&
    fields.cancellationEffectiveDate &&
    DATE_RE.test(fields.cancellationEffectiveDate)
      ? fields.cancellationEffectiveDate
      : null;

  await transaction(async (client) => {
    const letter = await lock(client, letterId);
    assertOwner(letter, ownerId);
    if (!REVIEWABLE.includes(letter.status)) {
      throw AppError.conflict('Only a letter awaiting a decision can be edited');
    }

    await client.query(
      `UPDATE letters SET
          insured_name            = $2,
          carrier                 = $3,
          policy_number           = $4,
          policy_type             = $5,
          loan_number             = $6,
          property_address        = $7,
          reason                  = $8,
          dwelling_coverage       = $9,
          total_premium           = $10,
          policy_period_start     = $11::date,
          policy_period_end       = $12::date,
          letter_type                 = CASE WHEN $13::boolean THEN $14::letter_type          ELSE letter_type END,
          cancellation_subtype        = CASE WHEN $13::boolean THEN $15::cancellation_subtype ELSE cancellation_subtype END,
          cancellation_effective_date = CASE WHEN $13::boolean THEN $16::date                 ELSE cancellation_effective_date END,
          due_date                = CASE WHEN $11::date IS NOT NULL THEN $11::date ELSE due_date END,
          due_date_defaulted      = CASE WHEN $11::date IS NOT NULL THEN true ELSE due_date_defaulted END,
          due_date_default_source = CASE WHEN $11::date IS NOT NULL THEN 'policy_period_start (edited)' ELSE due_date_default_source END
        WHERE id = $1`,
      [
        letterId,
        fields.insuredName,
        fields.carrier,
        fields.policyNumber,
        fields.policyType,
        fields.loanNumber,
        fields.propertyAddress,
        fields.reason,
        fields.dwellingCoverage,
        fields.totalPremium,
        start,
        end,
        editType,
        letterType,
        subtype,
        cancelEff,
      ]
    );

    await client.query(
      `INSERT INTO audit_logs (entity_type, entity_id, action, user_id, metadata)
       VALUES ('letter', $1, 'edited', $2, $3::jsonb)`,
      [
        letterId,
        actorId,
        JSON.stringify(
          editType
            ? { section: 'insurance_details', letterType, cancellationSubtype: subtype }
            : { section: 'insurance_details' }
        ),
      ]
    );
  });
}

/**
 * Move (reschedule) a letter's working task date. Escrow Admins move only their
 * own letters (ownerId set); a note is required — it becomes the letter's current
 * next-activity task (stored on the letter, shown on the Next activity tile) and
 * is also recorded in the audit trail. It is NOT appended to the letter notes.
 * Only open letters can be moved.
 */
export async function moveTaskDate(
  letterId: string,
  actorId: string,
  taskDate: string,
  note: string,
  ownerId?: string
): Promise<void> {
  if (!DATE_RE.test(taskDate)) {
    throw AppError.validation('taskDate must be a valid date (YYYY-MM-DD)');
  }
  if (!note || note.trim().length < 3) {
    throw AppError.validation('A note is required to move the task date');
  }

  await transaction(async (client) => {
    const letter = await lock(client, letterId);
    assertOwner(letter, ownerId);
    if (!REVIEWABLE.includes(letter.status)) {
      throw AppError.conflict('Only a letter awaiting a decision can be rescheduled');
    }

    const cur = await client.query<{ task_date: string | null }>(
      `SELECT task_date::text AS task_date FROM letters WHERE id = $1`,
      [letterId]
    );
    const from = cur.rows[0]?.task_date ?? null;

    // The note is the letter's current next-activity task — stored on the letter
    // (shown on the Next activity tile), not appended to the letter notes.
    await client.query(
      `UPDATE letters SET task_date = $2::date, task_note = $3 WHERE id = $1`,
      [letterId, taskDate, note.trim()]
    );

    await client.query(
      `INSERT INTO audit_logs (entity_type, entity_id, action, user_id, metadata)
       VALUES ('letter', $1, 'task_date_moved', $2, $3::jsonb)`,
      [letterId, actorId, JSON.stringify({ from, to: taskDate, note: note.trim() })]
    );
  });
}

