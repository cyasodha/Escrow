/**
 * Notes and audit trail.
 *
 * Both feed the letter timeline in the UI. `audit_logs` is append-only —
 * a trigger blocks UPDATE and DELETE at the database level.
 */

import { query, queryOne } from '../db';

export interface NoteRow {
  id: string;
  letter_id: string;
  user_id: string | null;
  author_name: string | null;
  body: string;
  created_at: string;
}

export interface AuditRow {
  id: string;
  entity_type: string;
  entity_id: string | null;
  action: string;
  user_id: string | null;
  actor_name: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
}

// --------------------------------------------------------------------------
// Notes
// --------------------------------------------------------------------------
export async function listNotes(letterId: string): Promise<NoteRow[]> {
  return query<NoteRow>(
    `SELECT n.*, u.full_name AS author_name
       FROM letter_notes n
       LEFT JOIN users u ON u.id = n.user_id
      WHERE n.letter_id = $1
      ORDER BY n.created_at ASC`,
    [letterId]
  );
}

export async function addNote(letterId: string, userId: string, body: string): Promise<NoteRow> {
  const row = await queryOne<NoteRow>(
    `INSERT INTO letter_notes (letter_id, user_id, body)
     VALUES ($1, $2, $3)
     RETURNING *`,
    [letterId, userId, body]
  );

  if (!row) throw new Error('Note insert returned no row');

  await recordAudit({
    entityType: 'letter',
    entityId: letterId,
    action: 'note_added',
    userId,
    metadata: { noteId: row.id },
  });

  return row;
}

// --------------------------------------------------------------------------
// Audit
// --------------------------------------------------------------------------
// The audit identifies the actor by name (falling back to email). Both a system
// event with no user_id AND an action performed by the `system` service account
// (the inbox pipeline) yield null actor_name, which the UI renders as "System" —
// so the machine account never appears by its email in the trail.
const ACTOR_NAME_SQL = `CASE WHEN u.role = 'system' THEN NULL
                             ELSE COALESCE(u.full_name, u.email) END AS actor_name`;

export async function listAudit(entityType: string, entityId: string): Promise<AuditRow[]> {
  return query<AuditRow>(
    `SELECT a.*, ${ACTOR_NAME_SQL}
       FROM audit_logs a
       LEFT JOIN users u ON u.id = a.user_id
      WHERE a.entity_type = $1 AND a.entity_id = $2
      ORDER BY a.created_at ASC`,
    [entityType, entityId]
  );
}

export async function listRecentAudit(limit: number): Promise<AuditRow[]> {
  return query<AuditRow>(
    `SELECT a.*, ${ACTOR_NAME_SQL}
       FROM audit_logs a
       LEFT JOIN users u ON u.id = a.user_id
      ORDER BY a.created_at DESC
      LIMIT $1`,
    [limit]
  );
}

export async function recordAudit(entry: {
  entityType: string;
  entityId: string | null;
  action: string;
  userId: string | null;
  metadata?: Record<string, unknown>;
}): Promise<void> {
  await query(
    `INSERT INTO audit_logs (entity_type, entity_id, action, user_id, metadata)
     VALUES ($1, $2, $3, $4, $5::jsonb)`,
    [entry.entityType, entry.entityId, entry.action, entry.userId, JSON.stringify(entry.metadata ?? {})]
  );
}
