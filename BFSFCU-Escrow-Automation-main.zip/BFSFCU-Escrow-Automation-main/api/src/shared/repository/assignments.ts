/**
 * Letter assignment + escalation + Team Workload aggregates.
 *
 * Distribution model (see shared/assignment.ts):
 *   - Every processed letter — clean match (high_confidence), a discrepancy
 *     (task), or unreadable / not-matched (low_confidence) — is auto-distributed
 *     to the eligible Escrow Admin with the lowest weighted load, unless it was
 *     already self-assigned at upload. There is no Manager exception bucket:
 *     low_confidence is just "Action needed" work like any other.
 *
 * Every manager action (reassign, escalate) writes an audit row in the same
 * transaction as the change.
 */

import type { PoolClient } from 'pg';
import { query, transaction } from '../db';
import { AppError } from '../errors';
import { pickAssignee, capacityWeight, type CapacityLevel, type AssigneeLoad } from '../assignment';
import { getCalendar, nextActivity } from '../schedule';
import { POWER_AUTOMATE_EMAIL } from './apiKeys';

/**
 * SQL predicate: the Escrow Admin is effectively OUT of office and must be
 * skipped by auto-distribution. Driven by the nightly OOO sync (ooo_auto). Kept
 * separate from auto_assign_enabled (the manual load pause) so the two never
 * clobber each other.
 */
const EFFECTIVE_OUT_SQL = `(u.ooo_auto)`;

/** Statuses that count as open, owner-actionable work for an Escrow Admin. */
const OPEN_WORK: readonly string[] = ['high_confidence', 'task', 'low_confidence'];

// ---------------------------------------------------------------------------
// Internal helpers (operate inside a caller-supplied transaction)
// ---------------------------------------------------------------------------

async function eligiblePool(client: PoolClient): Promise<AssigneeLoad[]> {
  const res = await client.query<{ user_id: string; capacity: CapacityLevel; open_count: string }>(
    `SELECT u.id AS user_id, u.capacity,
            COUNT(l.id) FILTER (WHERE l.status IN ('high_confidence','task','low_confidence')) AS open_count
       FROM users u
       LEFT JOIN letters l ON l.assigned_to = u.id
      WHERE u.role = 'user' AND u.is_active AND u.auto_assign_enabled
        AND NOT ${EFFECTIVE_OUT_SQL}
        AND lower(u.email) <> lower($1)
      GROUP BY u.id, u.capacity`,
    [POWER_AUTOMATE_EMAIL]
  );
  return res.rows.map((r) => ({
    userId: r.user_id,
    capacity: r.capacity,
    openCount: Number(r.open_count),
  }));
}

async function setAssignee(
  client: PoolClient,
  letterId: string,
  userId: string | null,
  byUserId: string | null
): Promise<void> {
  await client.query(
    `UPDATE letters
        SET assigned_to = $2::uuid,
            assigned_at = CASE WHEN $2::uuid IS NULL THEN NULL ELSE now() END,
            assigned_by = $3::uuid
      WHERE id = $1`,
    [letterId, userId, byUserId]
  );
}

async function audit(
  client: PoolClient,
  letterId: string,
  action: string,
  userId: string | null,
  metadata: Record<string, unknown>
): Promise<void> {
  await client.query(
    `INSERT INTO audit_logs (entity_type, entity_id, action, user_id, metadata)
     VALUES ('letter', $1, $2, $3, $4::jsonb)`,
    [letterId, action, userId, JSON.stringify(metadata)]
  );
}

/**
 * Stamp the letter's business-adjusted next-activity date from its receipt time:
 * task_date (the working DATE to start it) and first_activity_at (the precise
 * instant — the metric baseline, set ONCE). Applies to every letter regardless
 * of who ends up assigned, so an after-hours / weekend / holiday letter lands on
 * the next working day at the start time.
 */
async function stampFirstActivity(client: PoolClient, letterId: string): Promise<void> {
  const cur = await client.query<{ created_at: Date }>(
    `SELECT created_at FROM letters WHERE id = $1`,
    [letterId]
  );
  const createdAt = cur.rows[0]?.created_at;
  if (!createdAt) return;

  const cal = await getCalendar(client);
  const na = nextActivity(new Date(createdAt), cal);
  await client.query(
    `UPDATE letters
        SET task_date = $2::date,
            first_activity_at = COALESCE(
              first_activity_at,
              CASE WHEN $3 THEN ($2 || ' ' || $4)::timestamp AT TIME ZONE $5 ELSE now() END)
      WHERE id = $1`,
    [letterId, na.taskDate, na.deferred, cal.workStart, cal.timezone]
  );
}

/**
 * Assign a just-processed letter to an Escrow Admin. Called from pipeline/persist
 * inside its transaction, so the write commits atomically with the letter. Every
 * status (high_confidence | task | low_confidence) is distributed the same way;
 * a self-assignment made at upload is respected.
 */
export async function assignAfterProcessing(
  client: PoolClient,
  letterId: string,
  _status: 'high_confidence' | 'low_confidence' | 'task'
): Promise<void> {
  // Stamp the business-adjusted next-activity date first, for every letter.
  await stampFirstActivity(client, letterId);

  const cur = await client.query<{ assigned_to: string | null }>(
    `SELECT assigned_to FROM letters WHERE id = $1`,
    [letterId]
  );
  if (cur.rows[0]?.assigned_to) return; // self-assigned at upload — respect it

  const pick = pickAssignee(await eligiblePool(client));
  if (pick) {
    await setAssignee(client, letterId, pick, null);
    await audit(client, letterId, 'assigned', null, { to: pick, auto: true });
  }
}

/**
 * Distribute a letter to an Escrow Admin on the failure path (retries exhausted —
 * it is marked low_confidence = Action needed), unless already self-assigned.
 */
export async function autoAssignToPool(letterId: string): Promise<void> {
  await transaction(async (client) => {
    await stampFirstActivity(client, letterId);
    const cur = await client.query<{ assigned_to: string | null }>(
      `SELECT assigned_to FROM letters WHERE id = $1`,
      [letterId]
    );
    if (cur.rows[0]?.assigned_to) return;
    const pick = pickAssignee(await eligiblePool(client));
    if (pick) {
      await setAssignee(client, letterId, pick, null);
      await audit(client, letterId, 'assigned', null, { to: pick, auto: true });
    }
  });
}

// ---------------------------------------------------------------------------
// Manager actions (each opens its own transaction)
// ---------------------------------------------------------------------------

/** Assign/reassign a letter to a specific user, or 'auto' to redistribute. */
export async function assignLetter(
  letterId: string,
  target: string | 'auto',
  byUserId: string
): Promise<{ assignedTo: string | null }> {
  return transaction(async (client) => {
    const found = await client.query<{ id: string; assigned_to: string | null }>(
      `SELECT id, assigned_to FROM letters WHERE id = $1 FOR UPDATE`,
      [letterId]
    );
    if (found.rows.length === 0) throw AppError.notFound('Letter not found');
    const from = found.rows[0]!.assigned_to;

    let to: string | null;
    if (target === 'auto') {
      const pool = (await eligiblePool(client)).filter((c) => c.userId !== from);
      to = pickAssignee(pool.length ? pool : await eligiblePool(client));
      if (!to) throw AppError.validation('No Escrow Admin is available for auto-assignment');
    } else {
      const ok = await client.query<{ id: string }>(
        `SELECT id FROM users WHERE id = $1 AND is_active AND role = 'user'`,
        [target]
      );
      if (ok.rows.length === 0) throw AppError.validation('Target is not an active Escrow Admin');
      to = target;
    }

    await setAssignee(client, letterId, to, byUserId);
    await audit(client, letterId, 'reassigned', byUserId, { from, to, auto: target === 'auto' });
    return { assignedTo: to };
  });
}

/**
 * Soft-delete a user (deactivate) and hand off their work:
 *   - A manager cannot be removed if they are the last active manager — the app
 *     must always keep at least one (no specific account is special).
 *   - The user's OPEN letters are auto-distributed to the remaining eligible
 *     Escrow Admins (the now-inactive user is excluded). If no one is eligible,
 *     the letters are left unassigned for a manager to place.
 * All in one transaction, so a letter is never orphaned on a half-done delete.
 */
export async function deactivateUser(
  userId: string,
  byUserId: string
): Promise<{ redistributed: number; unassigned: number }> {
  return transaction(async (client) => {
    const found = await client.query<{ role: string; is_active: boolean }>(
      `SELECT role, is_active FROM users WHERE id = $1 FOR UPDATE`,
      [userId]
    );
    if (found.rows.length === 0) throw AppError.notFound('User not found');
    const target = found.rows[0]!;
    // The system service account is not a user and cannot be managed here.
    if (target.role === 'system') throw AppError.notFound('User not found');
    if (!target.is_active) return { redistributed: 0, unassigned: 0 }; // already gone

    // Never delete the last active manager.
    if (target.role === 'admin') {
      const others = await client.query<{ n: string }>(
        `SELECT count(*)::int AS n FROM users WHERE role = 'admin' AND is_active AND id <> $1`,
        [userId]
      );
      if (Number(others.rows[0]!.n) === 0) {
        throw AppError.conflict(
          'Cannot delete the last manager — make another user a manager first.'
        );
      }
    }

    await client.query(`UPDATE users SET is_active = false, updated_at = now() WHERE id = $1`, [userId]);

    // Redistribute their open work. The user is already inactive above, so
    // eligiblePool excludes them; per-letter selection rebalances as it goes.
    const open = await client.query<{ id: string }>(
      `SELECT id FROM letters
         WHERE assigned_to = $1 AND status IN ('high_confidence','task','low_confidence')
         FOR UPDATE`,
      [userId]
    );
    let redistributed = 0;
    let unassigned = 0;
    for (const row of open.rows) {
      const pick = pickAssignee(await eligiblePool(client));
      await setAssignee(client, row.id, pick, byUserId);
      await audit(client, row.id, 'reassigned', byUserId, {
        from: userId,
        to: pick,
        auto: true,
        reason: pick ? 'user_deactivated' : 'user_deactivated_no_pool',
      });
      if (pick) redistributed++;
      else unassigned++;
    }
    return { redistributed, unassigned };
  });
}

/**
 * Flag / unflag a letter as escalated (priority).
 *
 * Escrow Admins raise the priority on a letter assigned to them from the letter
 * page (ownerId set — enforced here). Managers can clear it (de-escalate) from
 * the Escalations screen or the letter page (ownerId undefined — unrestricted).
 *
 * A note is required for both escalating and de-escalating: it is stored as a
 * visible letter note and in the audit metadata, in the same transaction.
 */
export async function setEscalated(
  letterId: string,
  byUserId: string,
  escalated: boolean,
  ownerId?: string,
  note?: string,
  escalatedTo?: string
): Promise<void> {
  if (!note || note.trim().length < 3) {
    throw AppError.validation('A note is required to escalate or de-escalate a letter');
  }
  if (escalated && !escalatedTo) {
    throw AppError.validation('Choose a manager to escalate to');
  }
  const reason = note.trim();

  await transaction(async (client) => {
    const found = await client.query<{ id: string; assigned_to: string | null }>(
      `SELECT id, assigned_to FROM letters WHERE id = $1 FOR UPDATE`,
      [letterId]
    );
    if (found.rows.length === 0) throw AppError.notFound('Letter not found');
    if (ownerId && found.rows[0]!.assigned_to !== ownerId) {
      throw AppError.forbidden('This letter is not assigned to you.');
    }

    await client.query(
      `UPDATE letters
          SET escalated = $2,
              escalated_at = CASE WHEN $2 THEN now() ELSE NULL END,
              escalated_by = CASE WHEN $2 THEN $3::uuid ELSE NULL END,
              escalated_to = CASE WHEN $2 THEN $4::uuid ELSE NULL END
        WHERE id = $1`,
      [letterId, escalated, byUserId, escalatedTo ?? null]
    );
    await client.query(
      `INSERT INTO letter_notes (letter_id, user_id, body) VALUES ($1, $2, $3)`,
      [letterId, byUserId, `${escalated ? 'Escalated' : 'De-escalated'} — ${reason}`]
    );
    await audit(client, letterId, escalated ? 'escalated' : 'de_escalated', byUserId, {
      escalated,
      note: reason,
      escalatedTo: escalatedTo ?? null,
    });
  });
}

/**
 * Set a letter's triage priority (normal | high). This is a lightweight tag,
 * INDEPENDENT of escalation — it does not touch `escalated`. Managers set it for
 * any letter; Escrow Admins (ownerId set) only for their own. Audited, no note.
 */
export async function setPriority(
  letterId: string,
  byUserId: string,
  priority: 'normal' | 'high',
  ownerId?: string
): Promise<void> {
  await transaction(async (client) => {
    const found = await client.query<{ id: string; assigned_to: string | null; priority: string }>(
      `SELECT id, assigned_to, priority FROM letters WHERE id = $1 FOR UPDATE`,
      [letterId]
    );
    if (found.rows.length === 0) throw AppError.notFound('Letter not found');
    if (ownerId && found.rows[0]!.assigned_to !== ownerId) {
      throw AppError.forbidden('This letter is not assigned to you.');
    }
    const from = found.rows[0]!.priority;
    if (from === priority) return; // no-op

    await client.query(`UPDATE letters SET priority = $2 WHERE id = $1`, [letterId, priority]);
    await audit(client, letterId, 'priority_changed', byUserId, { from, to: priority });
  });
}

// ---------------------------------------------------------------------------
// Team Workload (Manager screen)
// ---------------------------------------------------------------------------

export interface TeamMember {
  id: string;
  fullName: string | null;
  email: string | null;
  capacity: CapacityLevel;
  weight: number;
  autoAssignEnabled: boolean;
  /** Nightly Graph sync result: out of office for the next working day. */
  oooAuto: boolean;
  /** "Is out" per the nightly sync — excluded from auto-assign. */
  effectiveOut: boolean;
  openCount: number;
  /** Open letters tagged high priority. */
  urgentCount: number;
  /** Open letters escalated to a manager. */
  escalatedCount: number;
  noActionCount: number;
  actionCount: number;
  /** Fair share of the current total open load, by weight. */
  fairShare: number;
}

export async function teamWorkload(): Promise<{ members: TeamMember[]; totalOpen: number }> {
  const rows = await query<{
    id: string;
    full_name: string | null;
    email: string | null;
    capacity: CapacityLevel;
    auto_assign_enabled: boolean;
    ooo_auto: boolean;
    open_count: string;
    urgent_count: string;
    escalated_count: string;
    no_action_count: string;
    action_count: string;
  }>(
    `SELECT u.id, u.full_name, u.email, u.capacity, u.auto_assign_enabled, u.ooo_auto,
            COUNT(l.id) FILTER (WHERE l.status IN ('high_confidence','task','low_confidence')) AS open_count,
            COUNT(l.id) FILTER (WHERE l.status IN ('high_confidence','task','low_confidence') AND l.priority = 'high') AS urgent_count,
            COUNT(l.id) FILTER (WHERE l.status IN ('high_confidence','task','low_confidence') AND l.escalated) AS escalated_count,
            COUNT(l.id) FILTER (WHERE l.status = 'high_confidence') AS no_action_count,
            COUNT(l.id) FILTER (WHERE l.status IN ('task','low_confidence')) AS action_count
       FROM users u
       LEFT JOIN letters l ON l.assigned_to = u.id
      WHERE u.role = 'user' AND u.is_active AND lower(u.email) <> lower($1)
      GROUP BY u.id
      ORDER BY u.full_name ASC NULLS LAST, u.email ASC`,
    [POWER_AUTOMATE_EMAIL]
  );

  const base = rows.map((r) => {
    const effectiveOut = r.ooo_auto;
    return {
      id: r.id,
      fullName: r.full_name,
      email: r.email,
      capacity: r.capacity,
      weight: capacityWeight(r.capacity),
      autoAssignEnabled: r.auto_assign_enabled,
      oooAuto: r.ooo_auto,
      effectiveOut,
      openCount: Number(r.open_count),
      urgentCount: Number(r.urgent_count),
      escalatedCount: Number(r.escalated_count),
      noActionCount: Number(r.no_action_count),
      actionCount: Number(r.action_count),
    };
  });

  const totalOpen = base.reduce((s, m) => s + m.openCount, 0);
  // Fair share is by weight among those actually receiving work (not paused, not out).
  const receiving = (m: (typeof base)[number]) => m.autoAssignEnabled && !m.effectiveOut;
  const activeWeight = base.filter(receiving).reduce((s, m) => s + m.weight, 0);

  const members: TeamMember[] = base.map((m) => ({
    ...m,
    fairShare:
      activeWeight > 0 && receiving(m)
        ? Math.round((m.weight / activeWeight) * totalOpen)
        : 0,
  }));

  return { members, totalOpen };
}
