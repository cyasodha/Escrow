/**
 * Escrow letters — reads and simple state writes.
 *
 * The heavy "save everything the pipeline produced" write lives in
 * pipeline/persist.ts (one transaction, letter + audit together). Workflow
 * transitions (approve / decline / move-to-task) live in repository/workflow.ts;
 * assignment / escalation in repository/assignments.ts. Routes never touch the
 * database directly — they come through here.
 */

import { query, queryOne } from '../db';
import { POWER_AUTOMATE_EMAIL } from './apiKeys';

export type LetterStatus =
  | 'queued'
  | 'processing'
  | 'high_confidence'
  | 'low_confidence'
  | 'task'
  | 'approved'
  | 'rejected';

export type LetterSource = 'manual_upload' | 'email_ingest' | 'api_ingest';

export interface LetterRow {
  id: string;
  letter_type: 'modification' | 'cancellation' | null;
  cancellation_subtype: 'nonpayment' | 'provider_switch' | 'non_renewal' | null;
  cancellation_effective_date: string | null;

  carrier: string | null;
  policy_number: string | null;
  property_address: string | null;
  insured_name: string | null;
  loan_number: string | null;
  dwelling_coverage: string | null;
  total_premium: string | null;
  policy_period_start: string | null;
  policy_period_end: string | null;
  policy_type: string | null;
  reason: string | null;

  due_date: string | null;
  due_date_defaulted: boolean;
  due_date_default_source: string | null;

  status: LetterStatus;
  source: LetterSource;

  match_status: 'matched_by_loan' | 'matched_by_name_address' | 'no_match' | null;
  matched_loan_number: string | null;
  oracle_match_raw: unknown;

  compare_result: unknown;
  premium_delta: string | null;
  premium_delta_pct: string | null;
  compare_flags: string[];

  confidence_tier: 'high' | 'low' | null;
  pii_match: boolean | null;
  account_match: boolean | null;
  tier_reason: string | null;

  confidence_score: string | null;
  extraction_flags: string[];
  extraction_provider: string | null;
  reasoning_provider: string | null;
  processing_error: string | null;

  blob_path: string;
  original_filename: string | null;
  file_hash: string;

  batch_id: string | null;
  source_blob_path: string | null;
  source_pages: string | null;
  split_index: number | null;
  split_total: number | null;
  doc_type: string | null;

  duplicate_of: string | null;
  duplicate_type: string | null;

  submitted_by: string | null;
  approved_by: string | null;
  approved_at: string | null;
  declined_by: string | null;
  declined_at: string | null;
  checker_comment: string | null;

  assigned_to: string | null;
  assigned_to_name: string | null;
  assigned_at: string | null;
  escalated: boolean;
  escalated_at: string | null;
  escalated_to: string | null;
  escalated_to_name: string | null;
  priority: 'normal' | 'high';
  task_date: string | null;
  task_note: string | null;

  created_at: string;
  updated_at: string;
}

const SELECT_COLS = `
  l.id, l.letter_type, l.cancellation_subtype, l.cancellation_effective_date::text AS cancellation_effective_date,
  l.carrier, l.policy_number, l.property_address, l.insured_name, l.loan_number,
  l.dwelling_coverage, l.total_premium,
  l.policy_period_start::text AS policy_period_start, l.policy_period_end::text AS policy_period_end,
  l.policy_type, l.reason,
  l.due_date::text AS due_date, l.due_date_defaulted, l.due_date_default_source,
  l.status, l.source,
  l.match_status, l.matched_loan_number, l.oracle_match_raw,
  l.compare_result, l.premium_delta, l.premium_delta_pct, l.compare_flags,
  l.confidence_tier, l.pii_match, l.account_match, l.tier_reason,
  l.confidence_score, l.extraction_flags, l.extraction_provider, l.reasoning_provider, l.processing_error,
  l.blob_path, l.original_filename, l.file_hash,
  l.batch_id, l.source_blob_path, l.source_pages, l.split_index, l.split_total, l.doc_type,
  l.duplicate_of, l.duplicate_type,
  l.submitted_by, l.approved_by, l.approved_at, l.declined_by, l.declined_at, l.checker_comment,
  l.assigned_to, au.full_name AS assigned_to_name, l.assigned_at::text AS assigned_at,
  l.escalated, l.escalated_at::text AS escalated_at, l.escalated_to, eu.full_name AS escalated_to_name,
  l.priority, l.task_date::text AS task_date, l.task_note,
  l.created_at, l.updated_at
`;

const FROM = `FROM letters l
  LEFT JOIN users au ON au.id = l.assigned_to
  LEFT JOIN users eu ON eu.id = l.escalated_to`;

// --------------------------------------------------------------------------
/** Provenance for a letter split out of a multi-letter upload. */
export interface SplitProvenance {
  batchId: string;
  sourceBlobPath: string;
  sourcePages: string;
  splitIndex: number;
  splitTotal: number;
  docType: string | null;
}

export async function createQueued(input: {
  blobPath: string;
  fileHash: string;
  originalFilename: string;
  source: LetterSource;
  /** Null for a sibling row that inherits an ingested (unattributed) upload. */
  submittedBy: string | null;
  assignedTo?: string | null;
  /** Set when this row is a sibling split from a multi-letter upload. */
  split?: SplitProvenance;
}): Promise<{ id: string }> {
  const s = input.split ?? null;
  const row = await queryOne<{ id: string }>(
    `INSERT INTO letters (blob_path, file_hash, original_filename, source, submitted_by, status,
                          assigned_to, assigned_at, assigned_by,
                          batch_id, source_blob_path, source_pages, split_index, split_total, doc_type)
     VALUES ($1, $2, $3, $4, $5::uuid, 'queued',
             $6::uuid,
             CASE WHEN $6::uuid IS NULL THEN NULL ELSE now() END,
             CASE WHEN $6::uuid IS NULL THEN NULL ELSE $5::uuid END,
             $7::uuid, $8, $9, $10, $11, $12)
     RETURNING id`,
    [
      input.blobPath,
      input.fileHash,
      input.originalFilename,
      input.source,
      input.submittedBy,
      input.assignedTo ?? null,
      s?.batchId ?? null,
      s?.sourceBlobPath ?? null,
      s?.sourcePages ?? null,
      s?.splitIndex ?? null,
      s?.splitTotal ?? null,
      s?.docType ?? null,
    ]
  );
  if (!row) throw new Error('Letter insert returned no row');
  return row;
}

/**
 * Point an already-created (anchor) letter row at its own split PDF and record
 * the split provenance. Used for segment 0 of a multi-letter upload, which
 * reuses the row created at upload time instead of creating a new one.
 */
export async function attachSplit(
  letterId: string,
  input: { blobPath: string; fileHash: string; split: SplitProvenance }
): Promise<void> {
  await query(
    `UPDATE letters
        SET blob_path = $2, file_hash = $3,
            batch_id = $4::uuid, source_blob_path = $5, source_pages = $6,
            split_index = $7, split_total = $8, doc_type = $9
      WHERE id = $1`,
    [
      letterId,
      input.blobPath,
      input.fileHash,
      input.split.batchId,
      input.split.sourceBlobPath,
      input.split.sourcePages,
      input.split.splitIndex,
      input.split.splitTotal,
      input.split.docType,
    ]
  );
}

export async function setStatus(id: string, status: LetterStatus): Promise<void> {
  await query(`UPDATE letters SET status = $2 WHERE id = $1`, [id, status]);
}

/**
 * Retries exhausted — land it in the exception bucket (low_confidence, a
 * Manager's My Tasks). Never Task, which is a reviewer action.
 */
export async function markProcessingFailed(id: string, message: string): Promise<void> {
  await query(
    `UPDATE letters
        SET status = 'low_confidence',
            confidence_tier = 'low',
            tier_reason = COALESCE(tier_reason, 'Extraction failed — needs manual review.'),
            processing_error = $2
      WHERE id = $1`,
    [id, message]
  );
}

export async function getById(id: string): Promise<LetterRow | undefined> {
  return queryOne<LetterRow>(`SELECT ${SELECT_COLS} ${FROM} WHERE l.id = $1`, [id]);
}

export interface ListParams {
  limit: number;
  offset: number;
  statuses?: readonly LetterStatus[];
  sources?: readonly LetterSource[];
  assignedTo?: string;
  search?: string;
  /** Sort escalated letters to the top (My Tasks). */
  escalatedFirst?: boolean;
  /** Only escalated (priority) letters — the Manager Escalations screen. */
  escalatedOnly?: boolean;
  /** With escalatedOnly, scope to escalations directed to this manager (or unassigned). */
  escalatedForManagerId?: string;
}

export async function list(params: ListParams): Promise<LetterRow[]> {
  const where: string[] = [];
  const values: unknown[] = [];
  let i = 1;

  if (params.statuses && params.statuses.length) {
    where.push(`l.status = ANY($${i++}::letter_status[])`);
    values.push(params.statuses as string[]);
  }
  if (params.sources && params.sources.length) {
    where.push(`l.source = ANY($${i++}::letter_source[])`);
    values.push(params.sources as string[]);
  }
  if (params.assignedTo) {
    where.push(`l.assigned_to = $${i++}`);
    values.push(params.assignedTo);
  }
  if (params.escalatedOnly) {
    where.push(`l.escalated = true`);
    if (params.escalatedForManagerId) {
      where.push(`(l.escalated_to = $${i} OR l.escalated_to IS NULL)`);
      values.push(params.escalatedForManagerId);
      i++;
    }
  }
  if (params.search) {
    where.push(
      `(l.insured_name ILIKE $${i} OR l.carrier ILIKE $${i} OR l.policy_number ILIKE $${i}
        OR l.loan_number ILIKE $${i} OR l.property_address ILIKE $${i} OR l.original_filename ILIKE $${i})`
    );
    values.push(`%${params.search}%`);
    i++;
  }

  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const orderSql = params.escalatedFirst
    ? `ORDER BY l.escalated DESC, (l.priority = 'high') DESC, l.task_date ASC, l.created_at DESC`
    : `ORDER BY l.created_at DESC`;
  values.push(params.limit, params.offset);

  return query<LetterRow>(
    `SELECT ${SELECT_COLS} ${FROM} ${whereSql} ${orderSql} LIMIT $${i++} OFFSET $${i}`,
    values
  );
}

export interface StatusCounts {
  queued: number;
  processing: number;
  high_confidence: number;
  low_confidence: number;
  task: number;
  approved: number;
  rejected: number;
  total: number;
}

export async function countByStatus(): Promise<StatusCounts> {
  const rows = await query<{ status: LetterStatus; count: string }>(
    `SELECT status, COUNT(*)::int AS count FROM letters GROUP BY status`
  );
  const counts: StatusCounts = {
    queued: 0,
    processing: 0,
    high_confidence: 0,
    low_confidence: 0,
    task: 0,
    approved: 0,
    rejected: 0,
    total: 0,
  };
  for (const r of rows) {
    const n = Number(r.count);
    counts[r.status] = n;
    counts.total += n;
  }
  return counts;
}

/** Sidebar counts for an Escrow Admin — scoped to letters assigned to them. */
export async function countsForEscrowAdmin(
  userId: string
): Promise<{ myTasks: number; accepted: number; declined: number }> {
  const row = await queryOne<{ my_tasks: string; accepted: string; declined: string }>(
    `SELECT
        COUNT(*) FILTER (WHERE status IN ('high_confidence','task','low_confidence')) AS my_tasks,
        COUNT(*) FILTER (WHERE status = 'approved') AS accepted,
        COUNT(*) FILTER (WHERE status = 'rejected') AS declined
       FROM letters WHERE assigned_to = $1`,
    [userId]
  );
  return {
    myTasks: Number(row?.my_tasks ?? 0),
    accepted: Number(row?.accepted ?? 0),
    declined: Number(row?.declined ?? 0),
  };
}

/**
 * Sidebar counts for a Manager. Managers have no personal task queue; accepted /
 * declined are team-wide totals for oversight.
 */
export async function countsForManager(managerId: string): Promise<{
  teamOpen: number;
  escalations: number;
  inbox: number;
  accepted: number;
  declined: number;
}> {
  const row = await queryOne<{
    team_open: string;
    escalations: string;
    inbox: string;
    accepted: string;
    declined: string;
  }>(
    `SELECT
        COUNT(*) FILTER (WHERE status IN ('high_confidence','task','low_confidence')) AS team_open,
        COUNT(*) FILTER (WHERE escalated
                          AND status IN ('high_confidence','task','low_confidence')
                          AND (escalated_to = $1 OR escalated_to IS NULL)) AS escalations,
        COUNT(*) FILTER (WHERE source IN ('email_ingest','api_ingest')
                          AND status NOT IN ('approved','rejected')) AS inbox,
        COUNT(*) FILTER (WHERE status = 'approved') AS accepted,
        COUNT(*) FILTER (WHERE status = 'rejected') AS declined
       FROM letters`,
    [managerId]
  );
  return {
    teamOpen: Number(row?.team_open ?? 0),
    escalations: Number(row?.escalations ?? 0),
    inbox: Number(row?.inbox ?? 0),
    accepted: Number(row?.accepted ?? 0),
    declined: Number(row?.declined ?? 0),
  };
}

/** Inbox Monitor tiles — pipeline health for ingested (non-manual) letters. */
export interface InboxTiles {
  processing: number;
  stuck: number;
  failed: number;
  inReview: number;
  resolved: number;
  total: number;
}

/** A letter is "stuck" if it has been queued/processing longer than this. */
const STUCK_MINUTES = 10;

export async function inboxTiles(): Promise<InboxTiles> {
  const row = await queryOne<{
    processing: string;
    stuck: string;
    failed: string;
    in_review: string;
    resolved: string;
    total: string;
  }>(
    `SELECT
        COUNT(*) FILTER (WHERE status IN ('queued','processing')
                          AND created_at >  now() - interval '${STUCK_MINUTES} minutes') AS processing,
        COUNT(*) FILTER (WHERE status IN ('queued','processing')
                          AND created_at <= now() - interval '${STUCK_MINUTES} minutes') AS stuck,
        COUNT(*) FILTER (WHERE processing_error IS NOT NULL) AS failed,
        COUNT(*) FILTER (WHERE status IN ('high_confidence','low_confidence','task')
                          AND processing_error IS NULL) AS in_review,
        COUNT(*) FILTER (WHERE status IN ('approved','rejected')) AS resolved,
        COUNT(*) AS total
       FROM letters
      WHERE source IN ('email_ingest','api_ingest')`
  );
  return {
    processing: Number(row?.processing ?? 0),
    stuck: Number(row?.stuck ?? 0),
    failed: Number(row?.failed ?? 0),
    inReview: Number(row?.in_review ?? 0),
    resolved: Number(row?.resolved ?? 0),
    total: Number(row?.total ?? 0),
  };
}

// --------------------------------------------------------------------------
// Task-timing metrics (Metrics page, Manager). Optionally scoped to one
// Escrow Admin. "Closed" = approved | rejected; close time = approved_at /
// declined_at. "Open" = high_confidence | task | low_confidence.
export interface TaskMetrics {
  /** Overall mean close time for the current scope (an admin, or the whole team). */
  meanTimeToCloseSeconds: number | null;
  closedTotal: number;
  /**
   * Last 6 months, oldest → newest. `meanSeconds` is the scope's mean close time
   * for tickets closed that month; `teamMeanSeconds` is the whole team's (for the
   * comparison line). `closed` / `openBacklog` power the closed-vs-open chart.
   */
  trend: {
    month: string;
    meanSeconds: number | null;
    teamMeanSeconds: number | null;
    closed: number;
    openBacklog: number;
  }[];
  /** Every active Escrow Admin's overall mean close time (fastest → slowest). */
  ranking: { adminId: string; name: string; meanSeconds: number | null }[];
  /** The 5 oldest open tickets, team-wide. */
  topOpen: {
    id: string;
    insuredName: string | null;
    policyNumber: string | null;
    adminId: string | null;
    assignedToName: string | null;
    openSeconds: number;
    createdAt: string;
  }[];
}

export async function taskMetrics(assignedTo?: string): Promise<TaskMetrics> {
  const scopeParam = assignedTo ? [assignedTo] : [];
  const scope = assignedTo ? 'AND l.assigned_to = $1' : '';
  const scopeClosed = assignedTo ? 'AND assigned_to = $1' : '';

  const summary = await queryOne<{ mean_seconds: string | null; closed_total: string }>(
    `SELECT AVG(EXTRACT(EPOCH FROM (COALESCE(approved_at, declined_at) - created_at))) AS mean_seconds,
            COUNT(*) AS closed_total
       FROM letters
      WHERE status IN ('approved','rejected') ${scopeClosed}`,
    scopeParam
  );

  // One pass over a 6-month series → scope mean, team mean, scope closed count,
  // and the scope's open backlog at each month end.
  const trend = await query<{
    month: string;
    mean_seconds: string | null;
    team_mean_seconds: string | null;
    closed: string;
    open_backlog: string;
  }>(
    `WITH months AS (
       SELECT generate_series(date_trunc('month', now()) - interval '5 months',
                              date_trunc('month', now()), interval '1 month') AS m
     )
     SELECT to_char(months.m, 'YYYY-MM') AS month,
       (SELECT AVG(EXTRACT(EPOCH FROM (COALESCE(l.approved_at, l.declined_at) - l.created_at)))
          FROM letters l
         WHERE l.status IN ('approved','rejected')
           AND date_trunc('month', COALESCE(l.approved_at, l.declined_at)) = months.m ${scope}) AS mean_seconds,
       (SELECT AVG(EXTRACT(EPOCH FROM (COALESCE(l.approved_at, l.declined_at) - l.created_at)))
          FROM letters l
         WHERE l.status IN ('approved','rejected')
           AND date_trunc('month', COALESCE(l.approved_at, l.declined_at)) = months.m) AS team_mean_seconds,
       (SELECT COUNT(*)
          FROM letters l
         WHERE l.status IN ('approved','rejected')
           AND date_trunc('month', COALESCE(l.approved_at, l.declined_at)) = months.m ${scope}) AS closed,
       (SELECT COUNT(*)
          FROM letters l
         WHERE l.created_at < months.m + interval '1 month'
           AND (COALESCE(l.approved_at, l.declined_at) IS NULL
                OR COALESCE(l.approved_at, l.declined_at) >= months.m + interval '1 month') ${scope}) AS open_backlog
       FROM months
      ORDER BY months.m ASC`,
    scopeParam
  );

  // Team-wide ranking — every active human Escrow Admin's overall mean.
  const ranking = await query<{ admin_id: string; name: string; mean_seconds: string | null }>(
    `SELECT u.id AS admin_id, COALESCE(u.full_name, u.email) AS name,
            AVG(EXTRACT(EPOCH FROM (COALESCE(l.approved_at, l.declined_at) - l.created_at))) AS mean_seconds
       FROM users u
       LEFT JOIN letters l ON l.assigned_to = u.id AND l.status IN ('approved','rejected')
      WHERE u.role = 'user' AND u.is_active AND lower(u.email) <> lower($1)
      GROUP BY u.id, COALESCE(u.full_name, u.email)
      ORDER BY mean_seconds ASC NULLS LAST`,
    [POWER_AUTOMATE_EMAIL]
  );

  // Team-wide top-5 oldest open tickets.
  const topOpen = await query<{
    id: string;
    insured_name: string | null;
    policy_number: string | null;
    admin_id: string | null;
    assigned_to_name: string | null;
    created_at: string;
    open_seconds: string;
  }>(
    `SELECT l.id, l.insured_name, l.policy_number, l.assigned_to AS admin_id,
            COALESCE(au.full_name, au.email) AS assigned_to_name,
            l.created_at::text AS created_at,
            EXTRACT(EPOCH FROM (now() - l.created_at)) AS open_seconds
       FROM letters l LEFT JOIN users au ON au.id = l.assigned_to
      WHERE l.status IN ('high_confidence','task','low_confidence')
      ORDER BY l.created_at ASC
      LIMIT 5`
  );

  return {
    meanTimeToCloseSeconds: summary?.mean_seconds != null ? Number(summary.mean_seconds) : null,
    closedTotal: Number(summary?.closed_total ?? 0),
    trend: trend.map((r) => ({
      month: r.month,
      meanSeconds: r.mean_seconds != null ? Number(r.mean_seconds) : null,
      teamMeanSeconds: r.team_mean_seconds != null ? Number(r.team_mean_seconds) : null,
      closed: Number(r.closed),
      openBacklog: Number(r.open_backlog),
    })),
    ranking: ranking.map((r) => ({
      adminId: r.admin_id,
      name: r.name,
      meanSeconds: r.mean_seconds != null ? Number(r.mean_seconds) : null,
    })),
    topOpen: topOpen.map((r) => ({
      id: r.id,
      insuredName: r.insured_name,
      policyNumber: r.policy_number,
      adminId: r.admin_id,
      assignedToName: r.assigned_to_name,
      openSeconds: Number(r.open_seconds),
      createdAt: r.created_at,
    })),
  };
}
