/**
 * Application users.
 *
 * Holds the application-side profile, role, capacity weight, and — for local
 * authentication — the password hash. `auth_provider` and `external_id` are the
 * seam for Microsoft Entra SSO (match-existing-only, so an Entra user needs an
 * admin-created account first).
 *
 * Role display: value 'admin' = "Manager", value 'user' = "Escrow Admin". The
 * enum values are unchanged; only the labels differ in the UI.
 */

import { query, queryOne } from '../db';
import { AppError } from '../errors';
import type { AppRole, Principal } from '../auth';
import { POWER_AUTOMATE_EMAIL } from './apiKeys';
import type { CapacityLevel } from '../assignment';

export interface AppUser {
  id: string;
  email: string | null;
  fullName: string | null;
  role: AppRole;
  isActive: boolean;
  authProvider: string;
  capacity: CapacityLevel;
  autoAssignEnabled: boolean;
}

interface UserRow {
  id: string;
  email: string | null;
  full_name: string | null;
  role: AppRole;
  is_active: boolean;
  auth_provider: string;
  capacity: CapacityLevel;
  auto_assign_enabled: boolean;
}

const COLS = `id, email, full_name, role, is_active, auth_provider, capacity, auto_assign_enabled`;

function toUser(row: UserRow): AppUser {
  return {
    id: row.id,
    email: row.email,
    fullName: row.full_name,
    role: row.role,
    isActive: row.is_active,
    authProvider: row.auth_provider,
    capacity: row.capacity,
    autoAssignEnabled: row.auto_assign_enabled,
  };
}

/**
 * Active managers (role 'admin') — for the escalate "assign to a manager" picker.
 * Exposes only id + name/email, so it is safe for any authenticated user (an
 * Escrow Admin cannot read the full user list).
 */
export async function listManagers(): Promise<
  { id: string; fullName: string | null; email: string | null }[]
> {
  const rows = await query<{ id: string; full_name: string | null; email: string | null }>(
    `SELECT id, full_name, email
       FROM users
      WHERE role = 'admin' AND is_active
      ORDER BY full_name ASC NULLS LAST, email ASC`
  );
  return rows.map((r) => ({ id: r.id, fullName: r.full_name, email: r.email }));
}

export async function findById(id: string): Promise<AppUser | undefined> {
  const row = await queryOne<UserRow>(`SELECT ${COLS} FROM users WHERE id = $1`, [id]);
  return row ? toUser(row) : undefined;
}

/** Full row including the password hash — for the login path only. */
export async function findByEmailForLogin(
  email: string
): Promise<(AppUser & { passwordHash: string | null }) | undefined> {
  const row = await queryOne<UserRow & { password_hash: string | null }>(
    `SELECT ${COLS}, password_hash FROM users WHERE lower(email) = lower($1)`,
    [email]
  );
  if (!row) return undefined;
  return { ...toUser(row), passwordHash: row.password_hash };
}

/**
 * Resolve the application user for a verified session. Role and active status are
 * read fresh here on every request, so a role change or deactivation takes effect
 * at once.
 */
export async function resolveUser(principal: Principal): Promise<AppUser> {
  const user = await findById(principal.sub);
  if (!user) throw AppError.forbidden('Your account no longer exists.');
  if (!user.isActive) throw AppError.forbidden('Your account has been deactivated.');
  return user;
}

/** Every human account. The `system` service principal (Power Automate) is not
 * a user and is never listed or managed here — it lives under Connections. */
export async function listUsers(): Promise<AppUser[]> {
  const rows = await query<UserRow>(
    `SELECT ${COLS} FROM users WHERE role <> 'system' ORDER BY created_at ASC`
  );
  return rows.map(toUser);
}

/**
 * Human Escrow Admins (role 'user', active, excluding the Power Automate machine
 * account). This is the population shown in Team Workload and the source of the
 * auto-distribution pool.
 */
export async function listEscrowAdmins(): Promise<AppUser[]> {
  const rows = await query<UserRow>(
    `SELECT ${COLS} FROM users
      WHERE role = 'user' AND is_active AND lower(email) <> lower($1)
      ORDER BY full_name ASC NULLS LAST, email ASC`,
    [POWER_AUTOMATE_EMAIL]
  );
  return rows.map(toUser);
}

/** Active Managers (role 'admin'). Exceptions are routed to one of these. */
export async function listManagerIds(): Promise<string[]> {
  const rows = await query<{ id: string }>(
    `SELECT id FROM users WHERE role = 'admin' AND is_active ORDER BY created_at ASC`
  );
  return rows.map((r) => r.id);
}

export interface CreateUserInput {
  email: string;
  fullName: string | null;
  role: AppRole;
  passwordHash: string;
  capacity?: CapacityLevel;
  autoAssignEnabled?: boolean;
}

export async function createLocalUser(input: CreateUserInput): Promise<AppUser> {
  const row = await queryOne<UserRow>(
    `INSERT INTO users (email, full_name, role, auth_provider, password_hash, is_active, capacity, auto_assign_enabled)
     VALUES ($1, $2, $3, 'local', $4, true, COALESCE($5::capacity_level, 'regular'), COALESCE($6, true))
     ON CONFLICT (lower(email)) WHERE email IS NOT NULL DO NOTHING
     RETURNING ${COLS}`,
    [
      input.email,
      input.fullName,
      input.role,
      input.passwordHash,
      input.capacity ?? null,
      input.autoAssignEnabled ?? null,
    ]
  );
  if (!row) throw AppError.conflict('A user with that email already exists');
  return toUser(row);
}

/** Update a user's role, active flag, capacity, and/or auto-assign switch. */
export async function updateUser(
  id: string,
  fields: {
    role?: AppRole;
    isActive?: boolean;
    capacity?: CapacityLevel;
    autoAssignEnabled?: boolean;
  }
): Promise<AppUser> {
  const row = await queryOne<UserRow>(
    `UPDATE users
        SET role                = COALESCE($2::app_role, role),
            is_active           = COALESCE($3, is_active),
            capacity            = COALESCE($4::capacity_level, capacity),
            auto_assign_enabled = COALESCE($5, auto_assign_enabled),
            updated_at          = now()
      WHERE id = $1 AND role <> 'system'
      RETURNING ${COLS}`,
    [
      id,
      fields.role ?? null,
      fields.isActive ?? null,
      fields.capacity ?? null,
      fields.autoAssignEnabled ?? null,
    ]
  );
  if (!row) throw AppError.notFound('User not found');
  return toUser(row);
}

/**
 * Apply the nightly OOO sync result: set ooo_auto = true for the given ids and
 * false for every other active human Escrow Admin (so admins who returned are
 * re-included). Returns how many are out vs. the total considered.
 */
export async function applyOooAuto(outUserIds: string[]): Promise<{ out: number; total: number }> {
  const rows = await query<{ out_count: string; total: string }>(
    `WITH upd AS (
       UPDATE users
          SET ooo_auto = (id = ANY($1::uuid[])), updated_at = now()
        WHERE role = 'user' AND is_active AND lower(email) <> lower($2)
        RETURNING ooo_auto
     )
     SELECT COUNT(*) FILTER (WHERE ooo_auto) AS out_count, COUNT(*) AS total FROM upd`,
    [outUserIds, POWER_AUTOMATE_EMAIL]
  );
  const r = rows[0];
  return { out: Number(r?.out_count ?? 0), total: Number(r?.total ?? 0) };
}

/** Self-service availability toggle (the auto-assign on/off switch). */
export async function setAutoAssign(userId: string, enabled: boolean): Promise<AppUser> {
  const row = await queryOne<UserRow>(
    `UPDATE users SET auto_assign_enabled = $2, updated_at = now() WHERE id = $1 RETURNING ${COLS}`,
    [userId, enabled]
  );
  if (!row) throw AppError.notFound('User not found');
  return toUser(row);
}

export async function setPassword(userId: string, passwordHash: string): Promise<void> {
  await queryOne(`UPDATE users SET password_hash = $2, updated_at = now() WHERE id = $1`, [
    userId,
    passwordHash,
  ]);
}

/**
 * Find the application user for an Entra sign-in. Match by `external_id` (the
 * Entra object id) first, then fall back to email so an admin-created local user
 * can sign in via SSO the first time. Returns undefined if neither matches — SSO
 * does not create accounts.
 */
export async function findByEntra(
  externalId: string,
  email: string | null
): Promise<(AppUser & { externalId: string | null }) | undefined> {
  let row = await queryOne<UserRow & { external_id: string | null }>(
    `SELECT ${COLS}, external_id FROM users WHERE external_id = $1`,
    [externalId]
  );
  if (!row && email) {
    row = await queryOne<UserRow & { external_id: string | null }>(
      `SELECT ${COLS}, external_id FROM users WHERE lower(email) = lower($1)`,
      [email]
    );
  }
  return row ? { ...toUser(row), externalId: row.external_id } : undefined;
}

/** Store the Entra object id on first SSO login. Only fills a blank value. */
export async function linkExternalId(userId: string, externalId: string): Promise<void> {
  await queryOne(
    `UPDATE users SET external_id = $2, updated_at = now()
      WHERE id = $1 AND external_id IS NULL`,
    [userId, externalId]
  );
}
