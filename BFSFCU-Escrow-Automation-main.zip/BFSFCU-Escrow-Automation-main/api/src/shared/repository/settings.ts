/**
 * Application settings (the single app_settings row).
 *
 * Two blocks, both NON-SECRET:
 *   - Entra SSO   — a public-client integration, so no client secret is stored.
 *   - Oracle      — the read-only loan-lookup CONNECTION (host/port/service/user
 *                   + enabled). The Oracle PASSWORD is NOT here; it is read from
 *                   ORACLE_PASSWORD (Key Vault) in shared/config.ts. So nothing
 *                   secret is ever written to the database.
 */

import { queryOne } from '../db';

// --------------------------------------------------------------------------
// Entra SSO
// --------------------------------------------------------------------------
export interface SsoConfig {
  enabled: boolean;
  tenantId: string | null;
  clientId: string | null;
}

interface SsoRow {
  entra_enabled: boolean;
  entra_tenant_id: string | null;
  entra_client_id: string | null;
}

function toSso(row: SsoRow | undefined): SsoConfig {
  return {
    enabled: row?.entra_enabled ?? false,
    tenantId: row?.entra_tenant_id ?? null,
    clientId: row?.entra_client_id ?? null,
  };
}

export async function getSsoConfig(): Promise<SsoConfig> {
  const row = await queryOne<SsoRow>(
    `SELECT entra_enabled, entra_tenant_id, entra_client_id
       FROM app_settings WHERE id = true`
  );
  return toSso(row);
}

export async function updateSsoConfig(input: SsoConfig): Promise<SsoConfig> {
  const row = await queryOne<SsoRow>(
    `UPDATE app_settings
        SET entra_enabled   = $1,
            entra_tenant_id = $2,
            entra_client_id = $3
      WHERE id = true
      RETURNING entra_enabled, entra_tenant_id, entra_client_id`,
    [input.enabled, input.tenantId, input.clientId]
  );
  return toSso(row);
}

// --------------------------------------------------------------------------
// Oracle loan-lookup connection (non-secret parts only)
// --------------------------------------------------------------------------
export interface OracleConfig {
  enabled: boolean;
  host: string | null;
  port: number;
  serviceName: string | null;
  user: string | null;
}

interface OracleRow {
  oracle_enabled: boolean;
  oracle_host: string | null;
  oracle_port: number;
  oracle_service_name: string | null;
  oracle_user: string | null;
}

function toOracle(row: OracleRow | undefined): OracleConfig {
  return {
    enabled: row?.oracle_enabled ?? false,
    host: row?.oracle_host ?? null,
    port: row?.oracle_port ?? 1521,
    serviceName: row?.oracle_service_name ?? null,
    user: row?.oracle_user ?? null,
  };
}

export async function getOracleConfig(): Promise<OracleConfig> {
  const row = await queryOne<OracleRow>(
    `SELECT oracle_enabled, oracle_host, oracle_port, oracle_service_name, oracle_user
       FROM app_settings WHERE id = true`
  );
  return toOracle(row);
}

/**
 * Update the Oracle connection. `password` is write-only: a non-empty value is
 * stored, and anything else (undefined / empty) leaves the existing password
 * untouched — so re-saving the other fields never wipes it.
 */
export async function updateOracleConfig(
  input: OracleConfig & { password?: string | null }
): Promise<OracleConfig> {
  const newPassword =
    typeof input.password === 'string' && input.password.trim() !== '' ? input.password : null;
  const row = await queryOne<OracleRow>(
    `UPDATE app_settings
        SET oracle_enabled      = $1,
            oracle_host         = $2,
            oracle_port         = $3,
            oracle_service_name = $4,
            oracle_user         = $5,
            oracle_password     = COALESCE($6, oracle_password)
      WHERE id = true
      RETURNING oracle_enabled, oracle_host, oracle_port, oracle_service_name, oracle_user`,
    [input.enabled, input.host, input.port, input.serviceName, input.user, newPassword]
  );
  return toOracle(row);
}

/**
 * The Oracle password stored from the admin UI, if any. Read only by the
 * connector — never returned to the browser. Empty/absent means "not set here".
 */
export async function getOraclePassword(): Promise<string | null> {
  const row = await queryOne<{ oracle_password: string | null }>(
    `SELECT oracle_password FROM app_settings WHERE id = true`
  );
  const v = row?.oracle_password;
  return v && v.trim() !== '' ? v : null;
}
