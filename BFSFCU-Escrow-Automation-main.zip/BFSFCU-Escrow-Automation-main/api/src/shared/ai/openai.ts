/**
 * Azure OpenAI — field extraction and normalisation (stage 2).
 *
 * Stage 1 (Document Intelligence layout) gives us the letter's raw text. This
 * step pulls the 11 escrow fields plus the letter type and — for a cancellation
 * — the 3-way subtype out of that text, and canonicalises them (dates to
 * YYYY-MM-DD, amounts to plain numbers).
 *
 * Non-blocking by design: if this fails, the caller keeps whatever it has and
 * the letter is flagged. A reasoning failure must never lose a letter — so a
 * total misconfiguration looks like success (extraction "works", the 11 fields
 * are simply empty). Verify with `confidence_score`, which only this step
 * populates.
 */

import { config } from '../config';
import { openAiAuthHeaders } from './credential';
import type { ExtractedLetter } from './documentIntelligence';
import type { Logger } from '../logger';

/**
 * One distinct policy detected in a document. A single document sometimes covers
 * more than one policy (several properties on one notice); the extractor lists
 * every one it sees so stage 2 can fan the letter out into one task per policy.
 * The 11 fields on NormalizedLetter describe a SINGLE policy — the only one, or
 * the one named by `policyHint` on a scoped extraction.
 */
export interface LocatedPolicy {
  policyNumber: string | null;
  insuredName: string | null;
  /** The model's certainty this is a real, distinct policy (0–1). */
  confidence: number;
}

/**
 * The stage-2 contract. Every field is always present — never undefined — so
 * persistence and the UI can rely on the shape without per-field guards.
 */
export interface NormalizedLetter {
  letterType: 'modification' | 'cancellation' | null;
  cancellationSubtype: 'nonpayment' | 'provider_switch' | 'non_renewal' | null;
  cancellationEffectiveDate: string | null;

  // The 11 fields captured manually today.
  carrier: string | null;
  policyNumber: string | null;
  propertyAddress: string | null;
  insuredName: string | null;
  loanNumber: string | null;
  dwellingCoverage: number | null;
  totalPremium: number | null;
  policyPeriodStart: string | null;
  policyPeriodEnd: string | null;
  policyType: string | null;
  reason: string | null;

  /** Every distinct policy detected in the document (usually exactly one). */
  policies: LocatedPolicy[];

  confidence: number;
  flags: string[];
}

/**
 * The flag vocabulary. Closed on purpose: the UI maps these to labels
 * (web/src/lib/letterReasons.ts), so a free-text flag would render as a raw
 * identifier. Anything outside this list is dropped.
 */
const FLAG_VALUES = [
  'letter_type_uncertain',
  'cancellation_subtype_missing',
  'loan_number_missing',
  'policy_number_missing',
  'insured_name_missing',
  'property_address_missing',
  'carrier_missing',
  'dwelling_coverage_missing',
  'total_premium_missing',
  'policy_period_missing',
  'non_escrow_document',
  'low_ocr_quality',
] as const;

const LETTER_TYPES = ['modification', 'cancellation'] as const;
const SUBTYPES = ['nonpayment', 'provider_switch', 'non_renewal'] as const;

/**
 * Strict JSON schema. With `strict: true` the model is *constrained* to this
 * shape rather than asked for it. Value-level formats (date, amount) are enforced
 * in canonicalize() below, since strict mode does not support `pattern`/`minimum`.
 */
const RESPONSE_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  required: [
    'letter_type',
    'cancellation_subtype',
    'cancellation_effective_date',
    'carrier',
    'policy_number',
    'property_address',
    'insured_name',
    'loan_number',
    'dwelling_coverage',
    'total_premium',
    'policy_period_start',
    'policy_period_end',
    'policy_type',
    'reason',
    'policies',
    'confidence',
    'flags',
  ],
  properties: {
    letter_type: { type: ['string', 'null'], enum: [...LETTER_TYPES, null] },
    cancellation_subtype: { type: ['string', 'null'], enum: [...SUBTYPES, null] },
    cancellation_effective_date: { type: ['string', 'null'], description: 'YYYY-MM-DD' },
    carrier: { type: ['string', 'null'] },
    policy_number: { type: ['string', 'null'] },
    property_address: { type: ['string', 'null'], description: 'The situs / subject property address' },
    insured_name: { type: ['string', 'null'], description: 'The named insured (homeowner), NOT the mortgagee' },
    loan_number: { type: ['string', 'null'], description: 'Mortgage loan number as printed, leading zeros preserved' },
    dwelling_coverage: { type: ['number', 'null'] },
    total_premium: { type: ['number', 'null'] },
    policy_period_start: { type: ['string', 'null'], description: 'YYYY-MM-DD' },
    policy_period_end: { type: ['string', 'null'], description: 'YYYY-MM-DD' },
    policy_type: { type: ['string', 'null'], description: 'e.g. HO-3' },
    reason: { type: ['string', 'null'] },
    policies: {
      type: 'array',
      description:
        'One entry per DISTINCT policy number present in the document. Usually exactly one.',
      items: {
        type: 'object',
        additionalProperties: false,
        required: ['policy_number', 'insured_name', 'confidence'],
        properties: {
          policy_number: { type: ['string', 'null'] },
          insured_name: { type: ['string', 'null'] },
          confidence: {
            type: 'number',
            description: '0 to 1 — certainty this is a real, distinct policy',
          },
        },
      },
    },
    confidence: { type: 'number', description: '0 to 1' },
    flags: { type: 'array', items: { type: 'string', enum: FLAG_VALUES } },
  },
} as const;

const SYSTEM_PROMPT = `You extract fields from a scanned BFSFCU escrow insurance letter.

There are two kinds of letter — MODIFICATION and CANCELLATION. Decide by what
happens to COVERAGE, not by isolated keywords:

- MODIFICATION: coverage CONTINUES or is updated/replaced going forward. This covers
  the "Agreement for Modification, Amendment, or Replacement of a Property Insurance
  Policy" AND a policy RENEWAL / continuation notice — a letter saying the policy IS
  being renewed for a new term (e.g. "renewal notice", "your policy will renew",
  "renewal premium due", "renewal declarations", a new policy period going forward).
  Set letter_type = "modification". cancellation_subtype and cancellation_effective_date
  are null.

- CANCELLATION: coverage is ENDING or will NOT continue. This covers a "Request for
  Cancellation ... (Pursuant to LA R.S. 22:1266)", a Notice of Cancellation, or a
  NON-RENEWAL (the insurer will NOT renew and coverage lapses at expiration). Cues:
  "cancelled effective", "notice of cancellation", "coverage will terminate",
  "will not be renewed". Set letter_type = "cancellation" and read the 3-way checkbox:
    * "nonpayment of premium" -> "nonpayment"
    * "written request of the named insured — replacement coverage obtained or bound" -> "provider_switch"
    * "non-renewal at expiration of the policy term" -> "non_renewal"
  cancellation_effective_date is the "cancelled effective" date.

CRITICAL — RENEWAL vs NON-RENEWAL: these are OPPOSITES, do not confuse them.
  * A RENEWAL (the policy IS continuing for a new term) is a MODIFICATION, NEVER a
    cancellation. The word "renewal" by itself does NOT mean cancellation.
  * A NON-RENEWAL (the insurer will NOT renew; coverage ends) is a CANCELLATION with
    subtype "non_renewal".
  If you cannot tell whether coverage is continuing or ending, prefer leaving
  letter_type null (it will be flagged for human review) over guessing.

CRITICAL: "Bank Fund Credit Union, ISAOA/ATIMA" (P.O. Box 4400, Baton Rouge, LA 70821)
is the MORTGAGEE / loss payee on every letter. It is NEVER the insured, the carrier,
or the property address. Do not extract it into any of the 11 fields.

The 11 fields:
1. carrier            — the insurance carrier / insurer (e.g. Progressive, Allstate,
                        Liberty Mutual, USAA). On a cancellation it is the entity the
                        notice is "given on behalf of" / the "Insurance carrier".
2. policy_number      — the policy number ("Policy No."), e.g. PGR-6634210.
3. property_address   — the situs / subject property address (the insured home),
                        NOT the mortgagee's P.O. Box and NOT the agent/carrier mailing address.
4. insured_name       — the named insured (the homeowner / member).
5. loan_number        — "Mortgage Loan No." Keep it EXACTLY as printed, including any
                        leading zeros. Return it as a string.
6. dwelling_coverage  — the limit of insurance applicable to the dwelling / "Dwelling coverage".
7. total_premium      — the total policy premium DUE AND PAYABLE for the new/current policy
                        period. If the letter also states an "expiring term" premium, that is
                        NOT this value — use the current one.
8. policy_period_start / 9. policy_period_end — the policy period dates.
10. policy_type       — e.g. "HO-3" (from "Homeowners (HO-3)").
11. reason            — the stated reason for the modification or cancellation.

MULTIPLE POLICIES: one document sometimes covers more than one policy (e.g. several
properties, or several policies listed on a single notice). In "policies", list EVERY
distinct policy number you can see — one entry per distinct number — even when the 11
fields above describe only one of them. A document that covers exactly one policy has
exactly one entry. Never merge two different policy numbers into one entry, and never
split one policy number into two. Per-entry confidence is how sure you are that it is a
real, separate policy (a faint or partially-read number is low confidence).

Rules:
- Dates are MM/DD/YYYY on the letter; emit every date as YYYY-MM-DD with zero padding.
- Amounts are plain numbers: no "$", no thousands separators, a dot decimal, at most 2 decimals.
- Never invent a value. If a field is not clearly present, return null — for a
  regulated document, null is always better than a guess. Do not substitute "N/A" or 0.
- confidence is your own certainty in the whole record, 0 to 1.
- Add flags for anything missing/uncertain (see the allowed list). If the document is
  clearly not an escrow insurance letter, set letter_type null and add "non_escrow_document".`;

const MAX_RAW_TEXT = 6_000;
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

function stripCodeFence(text: string): string {
  return text.replace(/```json\s*/gi, '').replace(/```\s*/g, '').trim();
}

/** A calendar date or nothing. Rejects timestamps and impossible dates alike. */
function asDate(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (!ISO_DATE.test(trimmed)) return null;
  const [y, m, d] = trimmed.split('-').map(Number) as [number, number, number];
  const date = new Date(Date.UTC(y, m - 1, d));
  const valid =
    date.getUTCFullYear() === y && date.getUTCMonth() === m - 1 && date.getUTCDate() === d;
  return valid ? trimmed : null;
}

/** A finite money amount at 2 decimals, or null. Never NaN, never Infinity. */
function asAmount(value: unknown): number | null {
  const n =
    typeof value === 'number'
      ? value
      : typeof value === 'string'
        ? Number(value.replace(/[,\s$]/g, ''))
        : NaN;
  if (!Number.isFinite(n)) return null;
  return Math.round(n * 100) / 100;
}

function asText(value: unknown): string | null {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (!trimmed || /^(n\/?a|none|unknown|null|-|—)$/i.test(trimmed)) return null;
  return trimmed;
}

function asEnum<T extends string>(value: unknown, allowed: readonly T[]): T | null {
  if (typeof value !== 'string') return null;
  const v = value.trim().toLowerCase() as T;
  return allowed.includes(v) ? v : null;
}

async function chat(
  messages: Array<{ role: string; content: string }>,
  maxTokens: number,
  responseFormat?: Record<string, unknown>
): Promise<string> {
  const endpoint = config.ai.openAiEndpoint.replace(/\/$/, '');
  const url =
    `${endpoint}/openai/deployments/${config.ai.openAiDeployment}/chat/completions` +
    `?api-version=${config.ai.openAiApiVersion}`;

  // Reasoning deployments take max_completion_tokens and reject a non-default
  // temperature; gpt-4o-style ones take max_tokens and honour temperature 0.
  const limits = config.ai.openAiReasoningModel
    ? { max_completion_tokens: maxTokens }
    : { max_tokens: maxTokens, temperature: 0 };

  const res = await fetch(url, {
    method: 'POST',
    headers: { ...(await openAiAuthHeaders()), 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messages,
      ...limits,
      ...(responseFormat ? { response_format: responseFormat } : {}),
    }),
  });

  if (!res.ok) {
    const detail = await res.text().catch(() => '');
    throw new Error(`Azure OpenAI error ${res.status}: ${detail.slice(0, 300)}`);
  }

  const body = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
  return body.choices?.[0]?.message?.content ?? '';
}

/**
 * Force the model's reply into the fixed contract and reconcile the flags to the
 * values actually present, so the flags never disagree with the fields.
 */
function canonicalize(parsed: Record<string, unknown>): NormalizedLetter {
  const letterType = asEnum(parsed['letter_type'], LETTER_TYPES);
  let cancellationSubtype = asEnum(parsed['cancellation_subtype'], SUBTYPES);
  // A subtype only makes sense on a cancellation.
  if (letterType !== 'cancellation') cancellationSubtype = null;

  const carrier = asText(parsed['carrier']);
  const policyNumber = asText(parsed['policy_number']);
  const propertyAddress = asText(parsed['property_address']);
  const insuredName = asText(parsed['insured_name']);
  const loanNumber = asText(parsed['loan_number']);
  const dwellingCoverage = asAmount(parsed['dwelling_coverage']);
  const totalPremium = asAmount(parsed['total_premium']);
  const policyPeriodStart = asDate(parsed['policy_period_start']);
  const policyPeriodEnd = asDate(parsed['policy_period_end']);
  const policyType = asText(parsed['policy_type']);
  const reason = asText(parsed['reason']);

  const flags = new Set(
    (Array.isArray(parsed['flags']) ? parsed['flags'] : [])
      .filter((f): f is string => typeof f === 'string')
      .map((f) => f.trim().toLowerCase())
      .filter((f): f is (typeof FLAG_VALUES)[number] =>
        (FLAG_VALUES as readonly string[]).includes(f)
      )
  );

  // Reconcile the missing-field flags with what we actually parsed.
  if (!letterType) flags.add('letter_type_uncertain');
  if (letterType === 'cancellation' && !cancellationSubtype) flags.add('cancellation_subtype_missing');
  if (!carrier) flags.add('carrier_missing');
  if (!policyNumber) flags.add('policy_number_missing');
  if (!insuredName) flags.add('insured_name_missing');
  if (!propertyAddress) flags.add('property_address_missing');
  if (!loanNumber) flags.add('loan_number_missing');
  if (dwellingCoverage === null) flags.add('dwelling_coverage_missing');
  if (totalPremium === null) flags.add('total_premium_missing');
  if (!policyPeriodStart || !policyPeriodEnd) flags.add('policy_period_missing');

  const confidenceRaw = typeof parsed['confidence'] === 'number' ? parsed['confidence'] : 0;
  const confidence = Number.isFinite(confidenceRaw) ? Math.min(1, Math.max(0, confidenceRaw)) : 0;

  const clamp01 = (n: unknown): number => {
    const v = typeof n === 'number' ? n : 0;
    return Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : 0;
  };
  const policies: LocatedPolicy[] = (Array.isArray(parsed['policies']) ? parsed['policies'] : [])
    .filter((p): p is Record<string, unknown> => !!p && typeof p === 'object')
    .map((p) => ({
      policyNumber: asText(p['policy_number']),
      insuredName: asText(p['insured_name']),
      confidence: clamp01(p['confidence']),
    }))
    .filter((p) => p.policyNumber);
  // Backfill from the single field so a one-policy document always has one entry,
  // even if the model left `policies` empty.
  if (policies.length === 0 && policyNumber) {
    policies.push({ policyNumber, insuredName, confidence });
  }

  return {
    letterType,
    cancellationSubtype,
    cancellationEffectiveDate: asDate(parsed['cancellation_effective_date']),
    carrier,
    policyNumber,
    propertyAddress,
    insuredName,
    loanNumber,
    dwellingCoverage,
    totalPremium,
    policyPeriodStart,
    policyPeriodEnd,
    policyType,
    reason,
    policies,
    confidence,
    flags: [...flags],
  };
}

/**
 * Guardrail for the renewal-vs-cancellation confusion.
 *
 * The model occasionally reads a policy RENEWAL (coverage continues → modification)
 * as a cancellation, or vice versa, because "renewal" appears in both a renewal and
 * a non-renewal. This is a defence-in-depth cross-check, NOT the classifier: it only
 * fires when the extracted type clearly CONTRADICTS the text signals AND the support
 * for the chosen type is absent. On a conflict it adds `letter_type_uncertain`, which
 * routes the letter to Review (pipeline/routing.ts) so a human confirms the type.
 */
function flagTypeUncertainty(
  result: NormalizedLetter,
  rawText: string,
  log?: Logger
): NormalizedLetter {
  const t = rawText.toLowerCase();
  const cancelWord = /\bcancel/.test(t); // cancel / cancelled / cancellation
  const nonRenewal =
    /non[-\s]?renew/.test(t) || /\bnot\s+(?:be\s+)?renew/.test(t) || /will\s+not\s+be\s+renew/.test(t);
  const terminating = /\bterminat/.test(t) || /coverage\s+will\s+(?:end|cease|lapse)/.test(t);
  // A renewal that CONTINUES coverage (guarded so non-renewal phrasing never matches).
  const renewalContinuing =
    /renewal\s+(?:notice|declaration|premium|offer|dec)/.test(t) ||
    /will\s+renew/.test(t) ||
    /policy\s+(?:will\s+)?renew/.test(t) ||
    /automatically\s+renew/.test(t) ||
    (/\brenew(?:al|s|ed|ing)?\b/.test(t) && !nonRenewal && !cancelWord);

  let conflict = false;
  if (result.letterType === 'cancellation' && renewalContinuing && !cancelWord && !nonRenewal && !terminating) {
    conflict = true; // reads like a renewal, but the model said cancellation
  } else if (result.letterType === 'modification' && (cancelWord || nonRenewal) && !renewalContinuing) {
    conflict = true; // reads like a cancellation, but the model said modification
  }
  if (!conflict) return result;

  log?.warn('Letter-type signals conflict with the extracted type; flagging for review', {
    letterType: result.letterType,
    cancelWord,
    nonRenewal,
    renewalContinuing,
  });
  const flags = result.flags.includes('letter_type_uncertain')
    ? result.flags
    : [...result.flags, 'letter_type_uncertain'];
  return { ...result, flags };
}

/**
 * Extract and normalise the 11 fields + type/subtype from a letter's text.
 *
 * Returns null on failure — the caller continues without the extracted fields,
 * so a reasoning outage never loses a letter. Pass `log` to find out that
 * happened: this step failing is invisible in the data (the fields are simply
 * empty and no confidence score is set), so silence here reads like success.
 *
 * `opts.policyHint` scopes the 11 fields to a single policy on a document that
 * holds several — used by the per-policy fan-out, where each task extracts only
 * its own policy from the shared document. `policies` is still fully populated.
 */
export async function extractLetter(
  extracted: ExtractedLetter,
  log?: Logger,
  opts?: { policyHint?: string | null }
): Promise<NormalizedLetter | null> {
  let content = '';
  try {
    const kv = extracted.keyValuePairs.length
      ? `\n\nKey/value pairs detected by layout:\n${extracted.keyValuePairs
          .map((p) => `${p.key}: ${p.value}`)
          .join('\n')
          .slice(0, 1_500)}`
      : '';

    const hint = opts?.policyHint?.trim();
    const scoping = hint
      ? `\n\nThis document describes MORE THAN ONE policy. Extract the 11 fields for ` +
        `policy number "${hint}" ONLY — the carrier, property, insured, coverage, premium, ` +
        `dates, type and reason that belong to THAT policy. Ignore every other policy on the ` +
        `document. Still list every distinct policy you see in "policies".`
      : '';

    content = await chat(
      [
        { role: 'system', content: SYSTEM_PROMPT },
        {
          role: 'user',
          content: `Letter text:\n${extracted.rawText.slice(0, MAX_RAW_TEXT)}${kv}${scoping}`,
        },
      ],
      // Generous budget: a reasoning deployment (gpt-5.x / o-series) spends tokens
      // on internal reasoning before emitting the structured output, so a tight
      // limit truncates the reply and silently drops the extraction.
      6_000,
      {
        type: 'json_schema',
        json_schema: { name: 'escrow_letter', strict: true, schema: RESPONSE_SCHEMA },
      }
    );

    const parsed = JSON.parse(stripCodeFence(content)) as Record<string, unknown>;
    // Cross-check the type against the text (renewal vs cancellation) before returning.
    return flagTypeUncertainty(canonicalize(parsed), extracted.rawText, log);
  } catch (err) {
    log?.warn('Letter extraction failed; keeping raw text only', {
      reason: err instanceof Error ? err.message : String(err),
      replyPreview: content.slice(0, 200),
    });
    return null;
  }
}
