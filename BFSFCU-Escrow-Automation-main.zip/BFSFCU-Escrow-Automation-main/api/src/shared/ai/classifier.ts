/**
 * Azure Document Intelligence — letter classification & auto-split (stage 0).
 *
 * A single uploaded file can hold several insurance letters. A trained custom
 * classifier, called with `split=auto`, returns one segment per detected
 * document with its category (`docType`) and the page range it spans. The
 * caller slices each range into its own PDF and runs the normal per-letter
 * pipeline on it.
 *
 * Like the layout call, the API is asynchronous: submit, then poll the
 * Operation-Location header until it succeeds. Running in the classify queue
 * worker means no user is waiting.
 *
 * Local development without a tenant: `CLASSIFY_STUB_SEGMENTS` (e.g. "1-2,3-4")
 * short-circuits the network call and returns those ranges, so the split and
 * fan-out path can be exercised end to end.
 */

import { config } from '../config';
import { docIntelAuthHeaders } from './credential';
import { AppError } from '../errors';
import type { Logger } from '../logger';

/** One detected letter within an uploaded file. Pages are 1-based, inclusive. */
export interface ClassifiedSegment {
  docType: string | null;
  startPage: number;
  endPage: number;
  confidence: number | null;
}

const POLL_INTERVAL_MS = 800;
const POLL_TIMEOUT_MS = 120_000;
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

interface ClassifierDocument {
  docType?: string;
  confidence?: number;
  boundingRegions?: Array<{ pageNumber?: number }>;
  spans?: Array<{ offset?: number; length?: number }>;
  pages?: Array<{ pageNumber?: number }>;
}

/** Which classifier categories count as a letter (empty = accept all). */
function letterDocTypes(): Set<string> {
  return new Set(
    config.ai.classifyLetterDocTypes
      .split(',')
      .map((s) => s.trim().toLowerCase())
      .filter(Boolean)
  );
}

function isLetterSegment(seg: ClassifiedSegment): boolean {
  const allow = letterDocTypes();
  if (allow.size === 0) return true;
  return seg.docType != null && allow.has(seg.docType.toLowerCase());
}

/** Parse the dev stub ("1-2,3-4" / "5") into segments. */
function parseStubSegments(spec: string): ClassifiedSegment[] {
  const segments: ClassifiedSegment[] = [];
  for (const part of spec.split(',').map((s) => s.trim()).filter(Boolean)) {
    const m = /^(\d+)(?:\s*-\s*(\d+))?$/.exec(part);
    if (!m) continue;
    const start = Number.parseInt(m[1]!, 10);
    const end = m[2] ? Number.parseInt(m[2], 10) : start;
    if (start >= 1 && end >= start) {
      segments.push({ docType: 'stub', startPage: start, endPage: end, confidence: null });
    }
  }
  return segments;
}

/** Page span of a classifier document = min..max of its bounding-region pages. */
function pageRangeOf(doc: ClassifierDocument): { startPage: number; endPage: number } | null {
  const pages = [
    ...(doc.boundingRegions ?? []).map((r) => r.pageNumber),
    ...(doc.pages ?? []).map((p) => p.pageNumber),
  ].filter((n): n is number => typeof n === 'number' && n >= 1);
  if (pages.length === 0) return null;
  return { startPage: Math.min(...pages), endPage: Math.max(...pages) };
}

/**
 * Classify an uploaded file into its constituent letters.
 *
 * Returns the letter segments (after the docType allow-list), ordered by page.
 * An empty array means the classifier found no letter — the caller decides the
 * fallback. Throws AppError.upstream on a real API failure so the worker can
 * retry or fall back.
 */
export async function classifyAndSplit(file: Buffer, log?: Logger): Promise<ClassifiedSegment[]> {
  // Dev stub takes precedence — no network call.
  const stub = config.ai.classifyStubSegments.trim();
  if (stub) {
    const segments = parseStubSegments(stub).filter(isLetterSegment);
    log?.warn('Classifier STUB in use — using configured page ranges, not a real classifier', {
      spec: stub,
      segments: segments.length,
    });
    return segments.sort((a, b) => a.startPage - b.startPage);
  }

  const classifierId = config.ai.docIntelClassifierId;
  if (!classifierId) {
    throw AppError.upstream('Classification enabled but no DOCINTEL_CLASSIFIER_ID is configured');
  }

  const endpoint = config.ai.docIntelEndpoint.replace(/\/$/, '');
  const url =
    `${endpoint}/documentintelligence/documentClassifiers/${classifierId}:analyze` +
    `?api-version=${config.ai.docIntelApiVersion}&split=auto`;

  const submit = await fetch(url, {
    method: 'POST',
    headers: { ...(await docIntelAuthHeaders()), 'Content-Type': 'application/json' },
    body: JSON.stringify({ base64Source: file.toString('base64') }),
  });

  if (!submit.ok) {
    const detail = await submit.text().catch(() => '');
    throw AppError.upstream(
      `Classifier rejected the document (${submit.status}): ${detail.slice(0, 300)}`
    );
  }

  const operationUrl = submit.headers.get('operation-location');
  if (!operationUrl) {
    throw AppError.upstream('Classifier did not return an Operation-Location header');
  }

  const deadline = Date.now() + POLL_TIMEOUT_MS;
  while (Date.now() < deadline) {
    await sleep(POLL_INTERVAL_MS);

    const poll = await fetch(operationUrl, { headers: await docIntelAuthHeaders() });
    if (!poll.ok) continue; // one transient failure is worth another loop

    const body = (await poll.json()) as {
      status?: string;
      error?: { message?: string };
      analyzeResult?: { documents?: ClassifierDocument[] };
    };

    if (body.status === 'succeeded') {
      const docs = body.analyzeResult?.documents ?? [];
      const segments: ClassifiedSegment[] = [];
      for (const doc of docs) {
        const range = pageRangeOf(doc);
        if (!range) continue;
        segments.push({
          docType: doc.docType ?? null,
          startPage: range.startPage,
          endPage: range.endPage,
          confidence: typeof doc.confidence === 'number' ? doc.confidence : null,
        });
      }
      const letters = segments.filter(isLetterSegment).sort((a, b) => a.startPage - b.startPage);
      log?.info('Classification complete', { detected: docs.length, letters: letters.length });
      return letters;
    }

    if (body.status === 'failed') {
      throw AppError.upstream(`Classification failed: ${body.error?.message ?? 'unknown error'}`);
    }
    // running / notStarted — keep polling.
  }

  throw AppError.upstream('Classifier timed out');
}
