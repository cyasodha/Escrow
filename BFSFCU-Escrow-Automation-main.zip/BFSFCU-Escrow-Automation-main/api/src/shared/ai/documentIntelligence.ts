/**
 * Azure Document Intelligence — letter text extraction (stage 1).
 *
 * These escrow letters (a modification agreement, a LA R.S. 22:1266 cancellation
 * request) are not invoices, so there is no prebuilt field model for them. We run
 * `prebuilt-layout`, which returns the full document text plus any key/value
 * pairs it detects, and let stage 2 (Azure OpenAI) pull the 11 fields + the
 * letter type/subtype out of that text. A custom model trained on real letters
 * can be dropped in later by changing `DOCINTEL_MODEL` — the call shape is
 * identical (SOW Appendix A).
 *
 * The API is asynchronous: submit, then poll the Operation-Location header until
 * it succeeds. Polling here is safe because this runs in the queue worker — no
 * user is waiting on the request.
 */

import { config } from '../config';
import { docIntelAuthHeaders } from './credential';
import { AppError } from '../errors';

export interface ExtractedLetter {
  /** Full OCR text of the letter — the primary input to stage 2. */
  rawText: string;
  /** Key/value pairs the layout model detected (extra signal; may be empty). */
  keyValuePairs: Array<{ key: string; value: string }>;
  /** Which model produced this, for provenance. */
  model: string;
}

// First poll after 800ms, then every 800ms. Layout on a 1–2 page letter usually
// finishes in a few seconds.
const POLL_INTERVAL_MS = 800;
const POLL_TIMEOUT_MS = 120_000;

interface LayoutKeyValuePair {
  key?: { content?: string };
  value?: { content?: string };
}

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Extract the text of an escrow letter (PDF or image).
 * Throws AppError.upstream on any failure — the worker decides whether to retry.
 */
export async function analyzeLetter(file: Buffer): Promise<ExtractedLetter> {
  const endpoint = config.ai.docIntelEndpoint.replace(/\/$/, '');
  const model = config.ai.docIntelModel;
  const url =
    `${endpoint}/documentintelligence/documentModels/${model}:analyze` +
    `?api-version=${config.ai.docIntelApiVersion}`;

  const headers = {
    ...(await docIntelAuthHeaders()),
    'Content-Type': 'application/json',
  };

  const submit = await fetch(url, {
    method: 'POST',
    headers,
    body: JSON.stringify({ base64Source: file.toString('base64') }),
  });

  if (!submit.ok) {
    const detail = await submit.text().catch(() => '');
    throw AppError.upstream(
      `Document Intelligence rejected the document (${submit.status}): ${detail.slice(0, 300)}`
    );
  }

  const operationUrl = submit.headers.get('operation-location');
  if (!operationUrl) {
    throw AppError.upstream('Document Intelligence did not return an Operation-Location header');
  }

  const deadline = Date.now() + POLL_TIMEOUT_MS;

  while (Date.now() < deadline) {
    await sleep(POLL_INTERVAL_MS);

    const poll = await fetch(operationUrl, { headers: await docIntelAuthHeaders() });
    if (!poll.ok) {
      // Transient poll failures are worth one more loop, not an immediate abort.
      continue;
    }

    const body = (await poll.json()) as {
      status?: string;
      error?: { message?: string };
      analyzeResult?: {
        content?: string;
        keyValuePairs?: LayoutKeyValuePair[];
      };
    };

    if (body.status === 'succeeded') {
      const content = body.analyzeResult?.content ?? '';
      if (!content.trim()) {
        throw AppError.upstream('Document Intelligence returned no readable text');
      }

      const keyValuePairs = (body.analyzeResult?.keyValuePairs ?? [])
        .map((kv) => ({
          key: kv.key?.content?.trim() ?? '',
          value: kv.value?.content?.trim() ?? '',
        }))
        .filter((kv) => kv.key !== '');

      return { rawText: content, keyValuePairs, model };
    }

    if (body.status === 'failed') {
      throw AppError.upstream(
        `Document extraction failed: ${body.error?.message ?? 'unknown error'}`
      );
    }
    // status is running / notStarted — keep polling.
  }

  throw AppError.upstream('Document Intelligence timed out');
}
