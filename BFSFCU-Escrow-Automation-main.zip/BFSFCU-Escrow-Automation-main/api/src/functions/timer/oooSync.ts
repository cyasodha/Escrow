/**
 * Nightly OOO sync timer.
 *
 * Fires every 15 minutes; runOooSync only acts once per day at/after the
 * configured cutoff (work_cutoff / work_timezone in app_settings), so the run
 * time stays editable in the admin UI without a redeploy. No-op unless both
 * Microsoft Graph (GRAPH_ENABLED) and the sync (ooo_sync_enabled) are on.
 */

import { app, type InvocationContext, type Timer } from '@azure/functions';
import { createLogger } from '../../shared/logger';
import { runOooSync } from '../../shared/oooSync';

app.timer('oooSyncTimer', {
  schedule: '0 */15 * * * *',
  handler: async (_timer: Timer, context: InvocationContext): Promise<void> => {
    const log = createLogger(context, { job: 'ooo-sync-timer' });
    try {
      const result = await runOooSync({ force: false, log });
      if (result.ran) {
        log.info('OOO sync ran', {
          targetDate: result.targetDate,
          markedOut: result.markedOut?.length ?? 0,
        });
      }
    } catch (err) {
      log.error('OOO sync timer failed', err);
    }
  },
});
