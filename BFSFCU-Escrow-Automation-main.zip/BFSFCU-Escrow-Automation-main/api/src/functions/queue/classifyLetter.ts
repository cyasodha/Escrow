/**
 * Classify-and-split worker (stage 0).
 *
 * A single uploaded file can contain several insurance letters. This worker
 * classifies the file (Azure Document Intelligence custom classifier, or the
 * local stub), slices each detected letter into its own PDF, and enqueues a
 * normal `process-letter` job for each — so the downstream pipeline never has to
 * know a file held more than one letter.
 *
 * The row created at upload time is the "anchor": segment 0 reuses it (its blob
 * is replaced by the slice); each additional letter gets its own sibling row,
 * all sharing `batch_id = anchor id`.
 *
 * Safety: nothing is ever lost. If the classifier is disabled/finds one letter,
 * or fails after all retries, the whole original file is processed as a single
 * letter.
 */

import { app, type InvocationContext } from '@azure/functions';
import { parseClassifyJob, enqueueLetterJob, type ClassifyJob } from '../../shared/queue';
import { downloadBlob, uploadBlob, buildBlobPath } from '../../shared/blob';
import { classifyAndSplit } from '../../shared/ai/classifier';
import { splitPdf } from '../../shared/pipeline/splitPdf';
import * as letters from '../../shared/repository/letters';
import { recordAudit } from '../../shared/repository/activity';
import { createLogger } from '../../shared/logger';
import { createHash, randomUUID } from 'node:crypto';

const MAX_DEQUEUE = 5;

/** Insert " (letter 2 of 3)" before a filename's extension. */
function withSuffix(filename: string, suffix: string): string {
  const dot = filename.lastIndexOf('.');
  if (dot <= 0) return `${filename} ${suffix}`;
  return `${filename.slice(0, dot)} ${suffix}${filename.slice(dot)}`;
}

const sha256 = (buf: Buffer) => createHash('sha256').update(buf).digest('hex');

app.storageQueue('classify-letter', {
  queueName: '%CLASSIFY_QUEUE_NAME%',
  connection: 'AzureWebJobsStorage',
  handler: async (message: unknown, context: InvocationContext) => {
    const log = createLogger(context);
    let job: ClassifyJob;

    try {
      job = parseClassifyJob(message);
    } catch (err) {
      log.error('Discarding unparseable classify message', err);
      return;
    }

    const jobLog = log.child({ letterId: job.letterId });
    jobLog.info('Classification started', { source: job.source });

    /** Send the whole original file through as a single letter (the anchor). */
    const processWhole = () =>
      enqueueLetterJob({
        letterId: job.letterId,
        blobPath: job.blobPath,
        fileHash: job.fileHash,
        source: job.source,
      });

    try {
      await letters.setStatus(job.letterId, 'processing');

      const file = await downloadBlob(job.blobPath);
      const segments = await classifyAndSplit(file, jobLog);

      // 0 or 1 letter → no split; process the whole file as the anchor letter.
      if (segments.length <= 1) {
        if (segments.length === 0) {
          jobLog.warn('Classifier found no letter segment; processing the whole file as one letter');
        }
        await processWhole();
        return;
      }

      const total = segments.length;
      for (let i = 0; i < total; i++) {
        const seg = segments[i]!;
        const slice = await splitPdf(file, seg.startPage, seg.endPage);
        const sliceHash = sha256(slice);
        const slicePath = buildBlobPath(job.originalFilename, randomUUID());
        await uploadBlob(slicePath, slice, 'application/pdf');

        const pages = seg.startPage === seg.endPage ? `${seg.startPage}` : `${seg.startPage}-${seg.endPage}`;
        const split = {
          batchId: job.letterId,
          sourceBlobPath: job.blobPath,
          sourcePages: pages,
          splitIndex: i,
          splitTotal: total,
          docType: seg.docType,
        };

        let childId: string;
        if (i === 0) {
          // Segment 0 reuses the anchor row created at upload time.
          await letters.attachSplit(job.letterId, { blobPath: slicePath, fileHash: sliceHash, split });
          childId = job.letterId;
        } else {
          const created = await letters.createQueued({
            blobPath: slicePath,
            fileHash: sliceHash,
            originalFilename: withSuffix(job.originalFilename, `(letter ${i + 1} of ${total})`),
            source: job.source,
            submittedBy: job.submittedBy,
            assignedTo: job.assignedTo,
            split,
          });
          childId = created.id;
          await recordAudit({
            entityType: 'letter',
            entityId: childId,
            action: 'uploaded',
            userId: job.submittedBy,
            metadata: { splitFrom: job.letterId, pages, docType: seg.docType },
          }).catch(() => undefined);
        }

        await enqueueLetterJob({
          letterId: childId,
          blobPath: slicePath,
          fileHash: sliceHash,
          source: job.source,
        });
      }

      jobLog.info('Split complete', { letters: total });
    } catch (err) {
      jobLog.error('Classification failed', err);

      const dequeueCount = Number(
        (context.triggerMetadata as Record<string, unknown> | undefined)?.['dequeueCount'] ?? 1
      );
      if (Number.isFinite(dequeueCount) && dequeueCount < MAX_DEQUEUE) {
        throw err; // retry
      }

      // Retries exhausted — never lose the upload: process the whole file as one letter.
      jobLog.warn('Classification failed after retries; processing the whole file as one letter', {
        dequeueCount,
      });
      await processWhole().catch(() => undefined);
    }
  },
});
