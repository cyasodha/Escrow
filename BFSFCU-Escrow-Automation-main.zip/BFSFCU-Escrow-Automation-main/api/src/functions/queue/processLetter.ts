/**
 * Letter processing worker.
 *
 * Triggered by a queue message, so nothing here blocks a user request. On an
 * unhandled throw the host returns the message to the queue and retries; after
 * `maxDequeueCount` (5) it lands in the poison queue for a human to inspect.
 *
 * Pipeline:
 *   download → Document Intelligence (text) → Azure OpenAI (11 fields + type,
 *   non-blocking) → Oracle match → compare-to-on-file → High/Low tier →
 *   duplicate check → write
 */

import { app, type InvocationContext } from '@azure/functions';
import { parseLetterJob, enqueueLetterJob, type LetterJob } from '../../shared/queue';
import { downloadBlob } from '../../shared/blob';
import { analyzeLetter } from '../../shared/ai/documentIntelligence';
import { extractLetter, type LocatedPolicy, type NormalizedLetter } from '../../shared/ai/openai';
import { pdfPageCount } from '../../shared/pipeline/splitPdf';
import { matchToOracle } from '../../shared/pipeline/oracleMatch';
import { compareToOnFile } from '../../shared/pipeline/compare';
import { tierLetter } from '../../shared/pipeline/tiering';
import { routeLetter } from '../../shared/pipeline/routing';
import { detectDuplicate } from '../../shared/pipeline/duplicateCheck';
import { saveProcessedLetter } from '../../shared/pipeline/persist';
import * as letters from '../../shared/repository/letters';
import { recordAudit } from '../../shared/repository/activity';
import { autoAssignToPool } from '../../shared/repository/assignments';
import { createLogger, type Logger } from '../../shared/logger';
import { config } from '../../shared/config';

const AOAI_MODEL = config.ai.openAiDeployment;

/** An empty extraction when stage 2 is unavailable — every field null. */
const EMPTY_LETTER: NormalizedLetter = {
  letterType: null,
  cancellationSubtype: null,
  cancellationEffectiveDate: null,
  carrier: null,
  policyNumber: null,
  propertyAddress: null,
  insuredName: null,
  loanNumber: null,
  dwellingCoverage: null,
  totalPremium: null,
  policyPeriodStart: null,
  policyPeriodEnd: null,
  policyType: null,
  reason: null,
  policies: [],
  confidence: 0,
  flags: ['low_ocr_quality'],
};

/** Insert "(policy 2 of 3)" before a filename's extension. */
function withSuffix(filename: string, suffix: string): string {
  const dot = filename.lastIndexOf('.');
  if (dot <= 0) return `${filename} ${suffix}`;
  return `${filename.slice(0, dot)} ${suffix}${filename.slice(dot)}`;
}

/**
 * The distinct, confident policies worth splitting on: a trimmed policy number,
 * confidence at or above the floor, de-duplicated case-insensitively (so the same
 * policy read on several pages counts once). Order is preserved.
 */
function splitablePolicies(policies: LocatedPolicy[], minConfidence: number): LocatedPolicy[] {
  const seen = new Set<string>();
  const out: LocatedPolicy[] = [];
  for (const p of policies) {
    const num = p.policyNumber?.trim();
    if (!num || p.confidence < minConfidence) continue;
    const key = num.toUpperCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push({ ...p, policyNumber: num });
  }
  return out;
}

/**
 * Fan a multi-policy document out into one task per policy, all sharing the same
 * blob (nothing is re-sliced — the page image is shared). Policy 0 reuses the
 * anchor row; the rest get sibling rows. Every task is (re-)queued with its
 * `policyHint`, so each does a scoped extraction and none re-detects (no loop).
 */
async function fanOutPolicies(
  job: LetterJob,
  policies: LocatedPolicy[],
  file: Buffer,
  log: Logger
): Promise<void> {
  const anchor = await letters.getById(job.letterId);
  const total = policies.length;
  const filename = anchor?.original_filename ?? 'letter.pdf';

  // All policies share every page of the document. Reuse the classifier's page
  // range if it split this doc; otherwise describe the whole document.
  const pageCount = await pdfPageCount(file);
  const sourcePages =
    anchor?.source_pages ?? (pageCount && pageCount > 1 ? `1-${pageCount}` : '1');

  const base = {
    batchId: anchor?.batch_id ?? job.letterId,
    sourceBlobPath: anchor?.source_blob_path ?? job.blobPath,
    sourcePages,
    docType: anchor?.doc_type ?? null,
    splitTotal: total,
  };

  for (let i = 0; i < total; i++) {
    const policyHint = policies[i]!.policyNumber!;
    const split = { ...base, splitIndex: i };

    if (i === 0) {
      // Policy 0 reuses the anchor row; its blob is already the shared document.
      await letters.attachSplit(job.letterId, {
        blobPath: job.blobPath,
        fileHash: job.fileHash,
        split,
      });
      await enqueueLetterJob({
        letterId: job.letterId,
        blobPath: job.blobPath,
        fileHash: job.fileHash,
        source: job.source,
        policyHint,
      });
    } else {
      const created = await letters.createQueued({
        blobPath: job.blobPath,
        fileHash: job.fileHash,
        originalFilename: withSuffix(filename, `(policy ${i + 1} of ${total})`),
        source: job.source,
        submittedBy: anchor?.submitted_by ?? null,
        assignedTo: anchor?.assigned_to ?? null,
        split,
      });
      await enqueueLetterJob({
        letterId: created.id,
        blobPath: job.blobPath,
        fileHash: job.fileHash,
        source: job.source,
        policyHint,
      });
      await recordAudit({
        entityType: 'letter',
        entityId: created.id,
        action: 'uploaded',
        userId: anchor?.submitted_by ?? null,
        metadata: { policySplitFrom: job.letterId, policyNumber: policyHint, index: i + 1, total },
      }).catch(() => undefined);
    }
  }

  log.info('Fanned out to one task per policy', { policies: total });
}

app.storageQueue('process-letter', {
  queueName: '%QUEUE_NAME%',
  connection: 'AzureWebJobsStorage',
  handler: async (message: unknown, context: InvocationContext) => {
    const log = createLogger(context);
    let job: LetterJob;

    try {
      job = parseLetterJob(message);
    } catch (err) {
      // Unparseable message: throwing would retry forever, so drop it here.
      log.error('Discarding unparseable queue message', err);
      return;
    }

    const letterLog = log.child({ letterId: job.letterId });
    letterLog.info('Processing started', { source: job.source });

    try {
      await letters.setStatus(job.letterId, 'processing');

      // 1. Fetch the document.
      const file = await downloadBlob(job.blobPath);

      // 2. Extract text (required — a failure here fails the letter).
      const extracted = await analyzeLetter(file);
      letterLog.info('Text extraction complete', {
        chars: extracted.rawText.length,
        kvPairs: extracted.keyValuePairs.length,
      });

      // 3. Pull the 11 fields + type/subtype (non-blocking — never lose a letter).
      //    On the first pass (no policy hint) the extractor also lists every
      //    distinct policy in the document. If several clear the confidence floor
      //    and the split is enabled, fan out one task per policy over the SAME
      //    blob and stop — the per-policy jobs (this row re-queued as policy 1)
      //    finish the work. A scoped child (policyHint set) skips detection.
      let normalized: NormalizedLetter | null;
      if (job.policyHint) {
        normalized = await extractLetter(extracted, letterLog, { policyHint: job.policyHint });
      } else {
        normalized = await extractLetter(extracted, letterLog);
        if (config.ai.policySplitEnabled && normalized) {
          const policies = splitablePolicies(normalized.policies, config.ai.policySplitMinConfidence);
          if (policies.length >= 2) {
            await fanOutPolicies(job, policies, file, letterLog);
            return;
          }
        }
      }
      if (!normalized) {
        letterLog.warn('Field extraction unavailable; letter will need manual review');
      }
      const letter = normalized ?? EMPTY_LETTER;

      // 4. Match to Oracle. The POLICY NUMBER is the primary insurance match;
      //    the loan is matched separately for PII (graceful when Oracle is off).
      const match = await matchToOracle(
        {
          loanNumber: letter.loanNumber,
          policyNumber: letter.policyNumber,
          insuredName: letter.insuredName,
          propertyAddress: letter.propertyAddress,
        },
        letterLog
      );
      letterLog.info('Oracle match', {
        matchStatus: match.matchStatus,
        policyFound: match.policyFound,
        oracleAvailable: match.oracleAvailable,
      });

      // 5. Compare the letter to the insurance on file.
      const compare = compareToOnFile(letter, match.insurance);

      // Primary-match tag: if the letter's policy number is not on file at all,
      // that is "No matching insurance found" (a new/replacement policy). It
      // supersedes the generic policy-changed flag.
      if (match.oracleAvailable && letter.policyNumber && !match.policyFound) {
        compare.flags = compare.flags.filter((f) => f !== 'policy_change');
        compare.flags.push('no_matching_insurance');
      }

      // 6. Tier: High (100% PII + account match) or Low.
      const tier = tierLetter(letter, match);

      // 7. Duplicate check (flag + link only; never auto-routes).
      const duplicate = await detectDuplicate({
        letterId: job.letterId,
        policyNumber: letter.policyNumber,
        loanNumber: letter.loanNumber,
      });

      // 8. Due date is derived from the policy period start (SOW §5), since it is
      //    not one of the 11 fields printed on the letter.
      let dueDate: string | null = null;
      let dueDateDefaulted = false;
      let dueDateDefaultSource: string | null = null;
      if (letter.policyPeriodStart) {
        dueDate = letter.policyPeriodStart;
        dueDateDefaulted = true;
        dueDateDefaultSource = 'policy_period_start';
      }

      // Flags shown to the reviewer = stage-2 field flags + a duplicate flag.
      const extractionFlags = [...letter.flags];
      if (duplicate.duplicateType) extractionFlags.push('possible_duplicate');
      // This task is one policy of several that shared a single document.
      if (job.policyHint) extractionFlags.push('multiple_policies');

      // Route into a work bucket: Review (unreadable), Action Required
      // (a discrepancy / gap / change), or No Action Required (clean match).
      const routing = routeLetter({
        letter,
        match,
        compare,
        tier,
        extractionFlags,
        confidence: normalized ? normalized.confidence : null,
      });

      // 9. Persist everything in one transaction.
      const status = await saveProcessedLetter({
        letterId: job.letterId,
        letter,
        dueDate,
        dueDateDefaulted,
        dueDateDefaultSource,
        match,
        compare,
        tier,
        routedStatus: routing.status,
        routingReason: routing.reason,
        duplicate,
        extractionFlags,
        confidence: normalized ? normalized.confidence : null,
        extractionProvider: `Azure Document Intelligence (${extracted.model})`,
        reasoningProvider: normalized ? `Azure OpenAI (${AOAI_MODEL})` : null,
        extractionRaw: { rawTextLength: extracted.rawText.length, kvPairs: extracted.keyValuePairs.length },
        normalizationRaw: normalized ? { ...normalized } : { unavailable: true },
      });

      letterLog.info('Processing complete', {
        status,
        tier: tier.tier,
        matchStatus: match.matchStatus,
        duplicate: duplicate.duplicateType,
      });
    } catch (err) {
      letterLog.error('Processing failed', err);

      // The host retries a throwing handler up to maxDequeueCount (host.json →
      // queues). While attempts remain, rethrow and let it try again; the letter
      // stays `processing` in the meantime.
      const MAX_DEQUEUE = 5;
      const dequeueCount = Number(
        (context.triggerMetadata as Record<string, unknown> | undefined)?.['dequeueCount'] ?? 1
      );

      if (Number.isFinite(dequeueCount) && dequeueCount < MAX_DEQUEUE) {
        throw err; // retry
      }

      // Retries exhausted. Land it in Low Confidence for review (never Task,
      // which is manual-only), with the reason attached, and consume the message.
      letterLog.warn('Extraction failed after retries; marking Action needed (low_confidence)', { dequeueCount });
      await letters
        .markProcessingFailed(
          job.letterId,
          err instanceof Error ? err.message : 'Unknown processing error'
        )
        .catch(() => undefined);
      // Distribute it to an Escrow Admin as Action-needed work (best effort).
      await autoAssignToPool(job.letterId).catch(() => undefined);
    }
  },
});
