/**
 * Letter workflow, notes and audit trail.
 *
 *   POST /api/letters/{id}/approve
 *   POST /api/letters/{id}/decline
 *   POST /api/letters/{id}/move-to-task     (the manual "move to Task/Exception")
 *   POST /api/letters/{id}/return-to-review
 *   GET  /api/letters/{id}/notes
 *   POST /api/letters/{id}/notes
 *   GET  /api/letters/{id}/audit
 *   GET  /api/audit                          (admin — recent activity)
 */

import { app } from '@azure/functions';
import { createHandler, ok } from '../../shared/handler';
import { Roles } from '../../shared/authorize';
import { AppError } from '../../shared/errors';
import * as workflow from '../../shared/repository/workflow';
import * as assignments from '../../shared/repository/assignments';
import * as activity from '../../shared/repository/activity';
import { notifyEscalation } from '../../shared/notifications/notify';
import type { AppUser } from '../../shared/repository/users';

function letterId(params: Record<string, string>): string {
  const id = params['id'];
  if (!id) throw AppError.validation('Missing letter id');
  return id;
}

/** Escrow Admins act only on their own letters; Managers are unrestricted. */
function ownerScope(user: AppUser): string | undefined {
  return user.role === 'admin' ? undefined : user.id;
}

async function readJson(req: { json: () => Promise<unknown> }): Promise<Record<string, unknown>> {
  const body = await req.json().catch(() => null);
  return body && typeof body === 'object' ? (body as Record<string, unknown>) : {};
}

// --------------------------------------------------------------------------
app.http('letter-approve', {
  methods: ['POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}/approve',
  handler: createHandler({ roles: Roles.approver }, async ({ req, user, log }) => {
    const id = letterId(req.params);
    const body = await readJson(req);
    const note = typeof body['note'] === 'string' ? body['note'] : undefined;

    await workflow.approve(id, user.id, note, ownerScope(user));
    log.info('Letter approved', { letterId: id });
    return ok({ id, status: 'approved' });
  }),
});

// --------------------------------------------------------------------------
app.http('letter-decline', {
  methods: ['POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}/decline',
  handler: createHandler({ roles: Roles.approver }, async ({ req, user, log }) => {
    const id = letterId(req.params);
    const body = await readJson(req);
    const reason = typeof body['reason'] === 'string' ? body['reason'] : '';

    await workflow.decline(id, user.id, reason, ownerScope(user));
    log.info('Letter declined', { letterId: id });
    return ok({ id, status: 'rejected' });
  }),
});

// --------------------------------------------------------------------------
// The ONLY way a letter enters the Task queue: a reviewer moves it there.
app.http('letter-move-to-task', {
  methods: ['POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}/move-to-task',
  handler: createHandler({ roles: Roles.reviewer }, async ({ req, user, log }) => {
    const id = letterId(req.params);
    const body = await readJson(req);
    const reason = typeof body['reason'] === 'string' ? body['reason'] : '';

    await workflow.moveToTask(id, user.id, reason, ownerScope(user));
    log.info('Letter moved to Task', { letterId: id });
    return ok({ id, status: 'task' });
  }),
});

// --------------------------------------------------------------------------
app.http('letter-return-to-review', {
  methods: ['POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}/return-to-review',
  handler: createHandler({ roles: Roles.reviewer }, async ({ req, user, log }) => {
    const id = letterId(req.params);
    const body = await readJson(req);
    const reason = typeof body['reason'] === 'string' ? body['reason'] : '';
    // Only honour an explicit target; otherwise returnToReview routes by tier.
    const target =
      body['target'] === 'high_confidence'
        ? 'high_confidence'
        : body['target'] === 'low_confidence'
          ? 'low_confidence'
          : undefined;

    await workflow.returnToReview(id, user.id, reason, target);
    log.info('Letter returned to review', { letterId: id, target: target ?? 'by-tier' });
    return ok({ id, status: target ?? 'returned' });
  }),
});

// --------------------------------------------------------------------------
// PATCH /api/letters/{id}/details   edit the 11 extracted fields
app.http('letter-edit-details', {
  methods: ['PATCH', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}/details',
  handler: createHandler({ roles: Roles.reviewer }, async ({ req, user, log }) => {
    const id = letterId(req.params);
    const body = await readJson(req);

    const str = (k: string): string | null => {
      const v = body[k];
      return typeof v === 'string' && v.trim() ? v.trim() : null;
    };
    const num = (k: string): string | null => {
      const v = body[k];
      if (v === null || v === undefined || v === '') return null;
      const n = Number(v);
      if (!Number.isFinite(n)) throw AppError.validation(`${k} must be a number`);
      return String(n);
    };

    const details: workflow.LetterDetailsInput = {
      insuredName: str('insuredName'),
      carrier: str('carrier'),
      policyNumber: str('policyNumber'),
      policyType: str('policyType'),
      loanNumber: str('loanNumber'),
      propertyAddress: str('propertyAddress'),
      reason: str('reason'),
      dwellingCoverage: num('dwellingCoverage'),
      totalPremium: num('totalPremium'),
      policyPeriodStart: str('policyPeriodStart'),
      policyPeriodEnd: str('policyPeriodEnd'),
    };

    // Optional letter-type correction — only touched when the client sends it, so
    // a details-only edit never wipes the type. Subtype + effective date are
    // normalised (forced null unless cancellation) by the repository.
    if ('letterType' in body) {
      const lt = body['letterType'];
      if (lt !== null && lt !== '' && lt !== 'modification' && lt !== 'cancellation') {
        throw AppError.validation('letterType must be "modification", "cancellation", or null');
      }
      const sub = body['cancellationSubtype'];
      if (
        sub !== undefined && sub !== null && sub !== '' &&
        sub !== 'nonpayment' && sub !== 'provider_switch' && sub !== 'non_renewal'
      ) {
        throw AppError.validation('cancellationSubtype is invalid');
      }
      details.letterType = lt === 'modification' || lt === 'cancellation' ? lt : null;
      details.cancellationSubtype =
        sub === 'nonpayment' || sub === 'provider_switch' || sub === 'non_renewal' ? sub : null;
      details.cancellationEffectiveDate = str('cancellationEffectiveDate');
    }

    await workflow.editLetterDetails(id, user.id, details, ownerScope(user));
    log.info('Letter details edited', { letterId: id, typeEdited: 'letterType' in body });
    return ok({ id });
  }),
});

// --------------------------------------------------------------------------
// PATCH /api/letters/{id}/task-date   { taskDate, note }   (owner Escrow Admin)
app.http('letter-task-date', {
  methods: ['PATCH', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}/task-date',
  handler: createHandler({ roles: Roles.reviewer }, async ({ req, user, log }) => {
    const id = letterId(req.params);
    const body = await readJson(req);
    const taskDate = typeof body['taskDate'] === 'string' ? body['taskDate'] : '';
    const note = typeof body['note'] === 'string' ? body['note'] : '';

    await workflow.moveTaskDate(id, user.id, taskDate, note, ownerScope(user));
    log.info('Task date moved', { letterId: id, taskDate });
    return ok({ id, taskDate });
  }),
});

// --------------------------------------------------------------------------
// POST /api/letters/{id}/assign   { to: <userId> | 'auto' }   (Manager)
app.http('letter-assign', {
  methods: ['POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}/assign',
  handler: createHandler({ roles: Roles.admin }, async ({ req, user, log }) => {
    const id = letterId(req.params);
    const body = await readJson(req);
    const to = typeof body['to'] === 'string' ? body['to'] : '';
    if (!to) throw AppError.validation("'to' is required (a user id or 'auto')");

    const result = await assignments.assignLetter(id, to === 'auto' ? 'auto' : to, user.id);
    log.info('Letter reassigned', { letterId: id, to: result.assignedTo });
    return ok({ id, assignedTo: result.assignedTo });
  }),
});

// --------------------------------------------------------------------------
// POST /api/letters/{id}/escalate   { escalated?: boolean }
// An Escrow Admin raises the priority (escalates) on a letter assigned to them;
// a Manager can escalate or de-escalate any letter. Owner scoping is enforced in
// the repository for Escrow Admins (ownerScope), unrestricted for Managers.
app.http('letter-escalate', {
  methods: ['POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}/escalate',
  handler: createHandler({ roles: Roles.reviewer }, async ({ req, user, log }) => {
    const id = letterId(req.params);
    const body = await readJson(req);
    const escalated = body['escalated'] === undefined ? true : body['escalated'] === true;
    const note = typeof body['note'] === 'string' ? body['note'] : '';
    const escalatedTo = typeof body['escalatedTo'] === 'string' ? body['escalatedTo'] : undefined;

    await assignments.setEscalated(id, user.id, escalated, ownerScope(user), note, escalatedTo);
    log.info('Letter escalation set', { letterId: id, escalated });

    // Post-commit, best-effort: notify the chosen manager. Never throws, so a
    // Graph outage cannot fail an escalation that is already persisted.
    if (escalated && escalatedTo) {
      await notifyEscalation({ letterId: id, toManagerId: escalatedTo, byUser: user, note }, log);
    }
    return ok({ id, escalated });
  }),
});

// --------------------------------------------------------------------------
// POST /api/letters/{id}/priority   { priority: 'normal' | 'high' }
// Triage priority tag — set by a Manager in Team Workload. Independent of
// escalation; Escrow Admins are owner-scoped, Managers unrestricted.
app.http('letter-priority', {
  methods: ['POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}/priority',
  handler: createHandler({ roles: Roles.reviewer }, async ({ req, user, log }) => {
    const id = letterId(req.params);
    const body = await readJson(req);
    const priority = body['priority'] === 'high' ? 'high' : 'normal';

    await assignments.setPriority(id, user.id, priority, ownerScope(user));
    log.info('Letter priority set', { letterId: id, priority });
    return ok({ id, priority });
  }),
});

// --------------------------------------------------------------------------
app.http('letter-notes', {
  methods: ['GET', 'POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}/notes',
  handler: createHandler({ roles: Roles.any }, async ({ req, user }) => {
    const id = letterId(req.params);

    if (req.method === 'GET') {
      return ok({ notes: await activity.listNotes(id) });
    }

    const body = await readJson(req);
    const text = typeof body['body'] === 'string' ? body['body'].trim() : '';
    if (!text) throw AppError.validation('Note text is required');

    return ok(await activity.addNote(id, user.id, text));
  }),
});

// --------------------------------------------------------------------------
app.http('letter-audit', {
  methods: ['GET', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}/audit',
  handler: createHandler({ roles: Roles.any }, async ({ req }) => {
    const id = letterId(req.params);
    return ok({ entries: await activity.listAudit('letter', id) });
  }),
});

// --------------------------------------------------------------------------
app.http('audit-recent', {
  methods: ['GET', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'audit',
  handler: createHandler({ roles: Roles.admin }, async ({ req }) => {
    const url = new URL(req.url);
    const limit = Math.min(Number(url.searchParams.get('limit') ?? 100), 500);
    return ok({ entries: await activity.listRecentAudit(Number.isFinite(limit) ? limit : 100) });
  }),
});
