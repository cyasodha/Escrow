/**
 * Inbox Monitor (Manager only).
 *
 *   GET /api/inbox   letters that arrived through the email / Power Automate
 *                    pipeline (source email_ingest | api_ingest) with their live
 *                    processing status, plus health tiles.
 *
 * Manual uploads never appear here — this screen is for watching the automated
 * ingestion pipeline and spotting stuck or failed deliveries.
 */

import { app } from '@azure/functions';
import { createHandler, ok } from '../../shared/handler';
import { Roles } from '../../shared/authorize';
import * as letters from '../../shared/repository/letters';

const INGEST_SOURCES: readonly letters.LetterSource[] = ['email_ingest', 'api_ingest'];

app.http('inbox', {
  methods: ['GET', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'inbox',
  handler: createHandler({ roles: Roles.admin }, async ({ req }) => {
    const url = new URL(req.url);
    const limit = Math.min(Number(url.searchParams.get('limit') ?? 100), 200);
    const search = url.searchParams.get('search') ?? undefined;

    const [rows, tiles] = await Promise.all([
      letters.list({
        limit: Number.isFinite(limit) ? limit : 100,
        offset: 0,
        sources: INGEST_SOURCES,
        ...(search ? { search } : {}),
      }),
      letters.inboxTiles(),
    ]);

    return ok({ letters: rows, tiles });
  }),
});
