/**
 * Demo utilities — available only when DEMO_MODE is enabled.
 *
 *   GET  /api/demo/config   whether demo mode is on (drives the UI control)
 *   POST /api/demo/reset    wipe transactional data (admin, demo-only)
 *
 * Reset clears the letter graph and the audit trail so a presenter gets a clean
 * slate between demos. Deliberately PRESERVED:
 *   - users        (so you can still sign in)
 *   - app_settings (Entra SSO + Oracle connection config)
 *   - api_keys     (the Power Automate machine key)
 *
 * Disabled in production: with DEMO_MODE unset the reset endpoint 404s, so even a
 * caller who knows the route cannot wipe a production database. ONE config
 * (DEMO_MODE) drives both the endpoint and the UI control (via /demo/config).
 */

import { app } from '@azure/functions';
import { createHandler, ok } from '../../shared/handler';
import { Roles } from '../../shared/authorize';
import { AppError } from '../../shared/errors';
import { config } from '../../shared/config';
import { query } from '../../shared/db';

app.http('demo-config', {
  methods: ['GET', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'demo/config',
  handler: createHandler({ roles: Roles.any }, async () => {
    return ok({ enabled: config.demo.enabled });
  }),
});

app.http('demo-reset', {
  methods: ['POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'demo/reset',
  handler: createHandler({ roles: Roles.admin }, async ({ user, log }) => {
    if (!config.demo.enabled) {
      // Not a demo environment — behave as though the route does not exist.
      throw AppError.notFound('Not found');
    }

    // TRUNCATE bypasses the append-only row trigger on audit_logs (that trigger
    // only blocks UPDATE/DELETE). CASCADE from `letters` also clears letter_notes
    // (its FK). users / app_settings / api_keys reference none of these and are
    // left intact, so sign-in, SSO/Oracle config, and the machine key survive.
    await query('TRUNCATE TABLE letters, letter_notes, audit_logs RESTART IDENTITY CASCADE');

    log.warn('Demo database reset — transactional data cleared', { by: user.id });
    return ok({ ok: true });
  }),
});

export {};
