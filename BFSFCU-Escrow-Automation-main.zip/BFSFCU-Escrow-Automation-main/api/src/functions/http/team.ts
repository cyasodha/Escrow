/**
 * Team Workload (Manager only).
 *
 *   GET /api/team-workload   per-Escrow-Admin open + urgent counts and capacity
 */

import { app } from '@azure/functions';
import { createHandler, ok } from '../../shared/handler';
import { Roles } from '../../shared/authorize';
import * as assignments from '../../shared/repository/assignments';
import { CAPACITY_WEIGHT } from '../../shared/assignment';

app.http('team-workload', {
  methods: ['GET', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'team-workload',
  handler: createHandler({ roles: Roles.admin }, async () => {
    // members already carry ooo_auto / effectiveOut (the operative OOO state).
    // ooo_auto is set by the nightly Graph sync; no live Graph read here.
    const { members, totalOpen } = await assignments.teamWorkload();
    return ok({ members, totalOpen, weights: CAPACITY_WEIGHT });
  }),
});
