/**
 * Managers list (any authenticated user).
 *
 *   GET /api/managers   active managers for the escalate "assign to" picker
 *
 * Only id + name/email are exposed, so an Escrow Admin (who cannot read the full
 * user list) can still choose which manager to escalate to.
 */

import { app } from '@azure/functions';
import { createHandler, ok } from '../../shared/handler';
import { Roles } from '../../shared/authorize';
import * as users from '../../shared/repository/users';

app.http('managers', {
  methods: ['GET', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'managers',
  handler: createHandler({ roles: Roles.any }, async () => {
    return ok({ managers: await users.listManagers() });
  }),
});
