/**
 * Letter routes.
 *
 *   POST /api/letters            upload → store → enqueue → 202
 *   GET  /api/letters            list (role-scoped: Escrow Admins see only their
 *                                own assigned letters; Managers see all)
 *   GET  /api/letters/{id}       detail (scoped)
 *   GET  /api/letters/{id}/file  short-lived view URL (scoped)
 *   GET  /api/letters-stats      per-queue counts (Manager / global)
 *   GET  /api/nav-counts         role-appropriate sidebar counts
 *
 * The upload returns immediately. All AI work (extract → match → compare → tier
 * → assign) happens in the queue worker, so the browser never waits on it.
 */

import { app } from '@azure/functions';
import { createHandler, createMethodHandler, ok, accepted } from '../../shared/handler';
import { Roles } from '../../shared/authorize';
import { AppError } from '../../shared/errors';
import {
  buildBlobPath,
  uploadBlob,
  getReadUrl,
  downloadBlob,
  toContainerRelativePath,
} from '../../shared/blob';
import { enqueueLetterJob, enqueueClassifyJob } from '../../shared/queue';
import { config } from '../../shared/config';
import * as letters from '../../shared/repository/letters';
import { recordAudit } from '../../shared/repository/activity';
import type { AppUser } from '../../shared/repository/users';
import { createHash, randomUUID } from 'node:crypto';

const MAX_UPLOAD_BYTES = 20 * 1024 * 1024; // 20 MB

const ALLOWED_TYPES: Record<string, string> = {
  'application/pdf': 'pdf',
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/tiff': 'tiff',
};

/** A PDF starts with "%PDF-"; scan the first 1 KB since some files carry a few
 * leading bytes before it. */
function looksLikePdf(bytes: Buffer): boolean {
  return bytes.subarray(0, 1024).includes(Buffer.from('%PDF-'));
}

/**
 * Detect a supported letter type from the file's own magic bytes — PDF, PNG,
 * JPEG or TIFF — or null for anything else. The blob-reference ingest has no
 * trustworthy caller content type, so it decides from the bytes it reads back.
 */
function detectSupportedType(
  bytes: Buffer
): 'application/pdf' | 'image/png' | 'image/jpeg' | 'image/tiff' | null {
  if (looksLikePdf(bytes)) return 'application/pdf';
  // PNG signature: 89 50 4E 47 0D 0A 1A 0A
  if (
    bytes.length >= 8 &&
    bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47 &&
    bytes[4] === 0x0d && bytes[5] === 0x0a && bytes[6] === 0x1a && bytes[7] === 0x0a
  ) {
    return 'image/png';
  }
  // JPEG signature: FF D8 FF
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return 'image/jpeg';
  }
  // TIFF: "II" 2A 00 (little-endian) or "MM" 00 2A (big-endian)
  if (
    bytes.length >= 4 &&
    ((bytes[0] === 0x49 && bytes[1] === 0x49 && bytes[2] === 0x2a && bytes[3] === 0x00) ||
      (bytes[0] === 0x4d && bytes[1] === 0x4d && bytes[2] === 0x00 && bytes[3] === 0x2a))
  ) {
    return 'image/tiff';
  }
  return null;
}

async function persistUpload(
  bytes: Buffer,
  filename: string,
  contentType: string,
  source: 'manual_upload' | 'email_ingest' | 'api_ingest',
  userId: string,
  assignedTo: string | null,
  // A blob-reference ingest hands us the path of a letter the caller already
  // uploaded into the container; when set, register that blob in place rather
  // than uploading a copy. Everything else is identical, so nothing downstream
  // can tell how the bytes arrived.
  existingBlobPath?: string
): Promise<string> {
  const fileHash = createHash('sha256').update(bytes).digest('hex');
  const blobPath = existingBlobPath ?? buildBlobPath(filename, randomUUID());
  if (!existingBlobPath) {
    await uploadBlob(blobPath, bytes, contentType);
  }
  const { id } = await letters.createQueued({
    blobPath,
    fileHash,
    originalFilename: filename,
    source,
    submittedBy: userId,
    assignedTo,
  });
  // A PDF may hold several letters — route it through the classify-and-split
  // stage first. Images (single page) and the classifier being off go straight
  // to processing. Either way the row above is the anchor.
  if (config.ai.classifyEnabled && contentType === 'application/pdf') {
    await enqueueClassifyJob({
      letterId: id,
      blobPath,
      fileHash,
      source,
      originalFilename: filename,
      submittedBy: userId,
      assignedTo,
    });
  } else {
    await enqueueLetterJob({ letterId: id, blobPath, fileHash, source });
  }
  await recordAudit({
    entityType: 'letter',
    entityId: id,
    action: 'uploaded',
    userId,
    metadata: { filename, bytes: bytes.length, assignedTo },
  });
  return id;
}

/** Parse a comma-separated query param into a trimmed non-empty list. */
function csv(value: string | null): string[] {
  return (value ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
}

// --------------------------------------------------------------------------
// GET  /api/letters   list
// POST /api/letters   upload
// --------------------------------------------------------------------------
app.http('letters', {
  methods: ['GET', 'POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters',
  handler: createMethodHandler({
    GET: {
      roles: Roles.any,
      handler: async ({ req, user }) => {
        const url = new URL(req.url);
        const limit = Math.min(Number(url.searchParams.get('limit') ?? 50), 200);
        const offset = Math.max(Number(url.searchParams.get('offset') ?? 0), 0);
        const statuses = csv(url.searchParams.get('status')) as letters.LetterStatus[];
        const sources = csv(url.searchParams.get('source')) as letters.LetterSource[];
        const search = url.searchParams.get('search') ?? undefined;
        const escalatedFirst = url.searchParams.get('escalatedFirst') === '1';
        const escalatedOnly = url.searchParams.get('escalated') === '1';
        const assignedParam = url.searchParams.get('assigned');

        // Escrow Admins may ONLY ever see letters assigned to them, whatever the
        // query says. Managers may optionally scope to their own with assigned=me.
        let assignedTo: string | undefined;
        if (user.role !== 'admin') {
          assignedTo = user.id;
        } else if (assignedParam === 'me') {
          assignedTo = user.id;
        } else if (assignedParam) {
          assignedTo = assignedParam;
        }

        const rows = await letters.list({
          limit: Number.isFinite(limit) ? limit : 50,
          offset: Number.isFinite(offset) ? offset : 0,
          ...(statuses.length ? { statuses } : {}),
          ...(sources.length ? { sources } : {}),
          ...(assignedTo ? { assignedTo } : {}),
          ...(search ? { search } : {}),
          // Managers see the escalations directed to them (plus any unassigned).
          ...(escalatedOnly && user.role === 'admin' ? { escalatedForManagerId: user.id } : {}),
          escalatedFirst,
          escalatedOnly,
        });

        return ok({ letters: rows, limit, offset });
      },
    },

    POST: {
      // Humans who upload, plus the `system` inbox-pipeline service account —
      // the only route its API key can reach.
      roles: Roles.ingest,
      handler: async ({ req, user, log }) => {
        const reqContentType = req.headers.get('content-type') ?? '';

        // ---- JSON: machine callers -------------------------------------------
        // Two shapes: a blob reference { blobPath, filename } — the Logic App
        // inbox flow uploads the letter straight into the letters container and
        // posts only its path, so no file bytes cross a gateway/WAF request-body
        // limit — or an inline { pdf_base64, filename }.
        if (reqContentType.includes('application/json')) {
          const body = (await req.json().catch(() => {
            throw AppError.validation('Expected a JSON body with "pdf_base64" or "blobPath"');
          })) as { pdf_base64?: string; blobPath?: string; filename?: string; fileName?: string };

          // ---- Blob reference: { blobPath, filename } ------------------------
          // Read the referenced blob back to hash + type-check it, so duplicate
          // detection, source tagging and validation behave exactly as for an
          // uploaded file — the body carries no file bytes for a WAF to inspect.
          if (typeof body.blobPath === 'string' && body.blobPath.length > 0) {
            const path = toContainerRelativePath(body.blobPath);
            // Throws 404 if the path is wrong or the blob is not yet committed.
            const bytes = await downloadBlob(path);
            if (bytes.length === 0) throw AppError.validation('The referenced blob is empty');
            if (bytes.length > MAX_UPLOAD_BYTES) {
              throw AppError.validation('File exceeds the 20 MB limit');
            }
            const contentType = detectSupportedType(bytes);
            if (!contentType) {
              throw AppError.validation(
                `Referenced blob is not a supported file (${bytes.length} bytes; expected PDF, PNG, JPEG, or TIFF).`
              );
            }
            const filename =
              body.filename || body.fileName || path.split('/').pop() || 'letter.pdf';
            // Machine ingestion is always auto-distributed after processing.
            const id = await persistUpload(bytes, filename, contentType, 'email_ingest', user.id, null, path);
            log.info('Letter queued from blob reference', {
              letterId: id,
              blobPath: path,
              bytes: bytes.length,
            });
            return accepted({ letterId: id, status: 'queued' });
          }

          const raw = body?.pdf_base64;
          if (!raw || typeof raw !== 'string') {
            throw AppError.validation('Missing "pdf_base64" or "blobPath" in the request body');
          }
          const b64 = raw.replace(/^data:[^;]*;base64,/, '').replace(/\s/g, '');
          const bytes = Buffer.from(b64, 'base64');
          if (bytes.length === 0) throw AppError.validation('The uploaded file is empty');
          if (bytes.length > MAX_UPLOAD_BYTES) throw AppError.validation('File exceeds the 20 MB limit');

          const filename = body.filename || body.fileName || 'letter.pdf';
          // Machine ingestion is always auto-distributed after processing.
          const id = await persistUpload(bytes, filename, 'application/pdf', 'api_ingest', user.id, null);
          log.info('Letter queued', { letterId: id, bytes: bytes.length });
          return accepted({ letterId: id, status: 'queued' });
        }

        // ---- multipart/form-data: one or more browser files ------------------
        const form = await req.formData().catch(() => {
          throw AppError.validation(
            'Expected a multipart/form-data upload or a JSON body with pdf_base64'
          );
        });
        const files = form.getAll('file').filter((f) => typeof f !== 'string') as unknown as File[];
        if (files.length === 0) throw AppError.validation('No file was included in the upload');

        // Escrow Admins always keep their own manual uploads — no auto-distribute
        // option. Managers are not a work target, so their uploads auto-distribute
        // to the pool after processing.
        const assignedTo = user.role === 'user' ? user.id : null;

        const created: Array<{ letterId: string; filename: string }> = [];
        for (const file of files) {
          const contentType = file.type || 'application/octet-stream';
          const bytes = Buffer.from(await file.arrayBuffer());
          const filename = file.name || 'letter.pdf';
          if (!ALLOWED_TYPES[contentType]) {
            throw AppError.validation(
              `Unsupported file type "${contentType}". Allowed: PDF, PNG, JPEG, TIFF.`
            );
          }
          if (bytes.length === 0) throw AppError.validation('The uploaded file is empty');
          if (bytes.length > MAX_UPLOAD_BYTES) throw AppError.validation('File exceeds the 20 MB limit');
          const id = await persistUpload(bytes, filename, contentType, 'manual_upload', user.id, assignedTo);
          created.push({ letterId: id, filename });
        }

        log.info('Letters queued', { count: created.length, assignedTo: assignedTo ?? 'auto' });
        // Single file keeps the simple shape existing callers expect.
        if (created.length === 1) {
          return accepted({ letterId: created[0]!.letterId, status: 'queued' });
        }
        return accepted({ created, createdCount: created.length });
      },
    },
  }),
});

/** Escrow Admins can only open letters assigned to them. */
function assertCanView(user: AppUser, letter: letters.LetterRow): void {
  if (user.role !== 'admin' && letter.assigned_to !== user.id) {
    throw AppError.notFound('Letter not found');
  }
}

// --------------------------------------------------------------------------
// GET /api/letters/{id}   detail
// --------------------------------------------------------------------------
app.http('letter-by-id', {
  methods: ['GET', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}',
  handler: createHandler({ roles: Roles.any }, async ({ req, user }) => {
    const id = req.params['id'];
    if (!id) throw AppError.validation('Missing letter id');

    const letter = await letters.getById(id);
    if (!letter) throw AppError.notFound('Letter not found');
    assertCanView(user, letter);
    return ok(letter);
  }),
});

// --------------------------------------------------------------------------
// GET /api/letters/{id}/file   short-lived view URL
// --------------------------------------------------------------------------
app.http('letter-file', {
  methods: ['GET', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters/{id}/file',
  handler: createHandler({ roles: Roles.any }, async ({ req, user }) => {
    const id = req.params['id'];
    if (!id) throw AppError.validation('Missing letter id');

    const letter = await letters.getById(id);
    if (!letter) throw AppError.notFound('Letter not found');
    assertCanView(user, letter);

    const url = await getReadUrl(letter.blob_path, 15);
    return ok({ url, expiresInMinutes: 15 });
  }),
});

// --------------------------------------------------------------------------
// GET /api/letters-stats   (global — Manager Dashboard)
// --------------------------------------------------------------------------
app.http('letters-stats', {
  methods: ['GET', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'letters-stats',
  handler: createHandler({ roles: Roles.any }, async () => {
    return ok(await letters.countByStatus());
  }),
});

// --------------------------------------------------------------------------
// GET /api/nav-counts   role-appropriate sidebar badges
// --------------------------------------------------------------------------
app.http('nav-counts', {
  methods: ['GET', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'nav-counts',
  handler: createHandler({ roles: Roles.any }, async ({ user }) => {
    if (user.role === 'admin') {
      return ok({ role: 'manager', ...(await letters.countsForManager(user.id)) });
    }
    return ok({ role: 'escrow_admin', ...(await letters.countsForEscrowAdmin(user.id)) });
  }),
});
