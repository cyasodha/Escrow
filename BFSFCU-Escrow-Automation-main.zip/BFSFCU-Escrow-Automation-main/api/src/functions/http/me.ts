/**
 * GET   /api/me              the signed-in user's profile, role, and capacity
 * PATCH /api/me/availability { autoAssignEnabled }  self-service on/off switch
 *
 * The frontend calls GET /me after login to discover who the user is. A 401
 * means "no valid session"; the app shows the login page.
 */

import { app } from '@azure/functions';
import { createHandler, ok } from '../../shared/handler';
import { AppError } from '../../shared/errors';
import * as users from '../../shared/repository/users';
import type { AppUser } from '../../shared/repository/users';

function profile(user: AppUser) {
  return {
    id: user.id,
    email: user.email,
    fullName: user.fullName,
    role: user.role,
    isActive: user.isActive,
    capacity: user.capacity,
    autoAssignEnabled: user.autoAssignEnabled,
  };
}

app.http('me', {
  methods: ['GET', 'OPTIONS'],
  authLevel: 'anonymous', // session tokens are validated in createHandler
  route: 'me',
  handler: createHandler({}, async ({ user, log }) => {
    log.info('Resolved current user', { role: user.role });
    return ok(profile(user));
  }),
});

async function readJson(req: { json: () => Promise<unknown> }): Promise<Record<string, unknown>> {
  const body = await req.json().catch(() => null);
  return body && typeof body === 'object' ? (body as Record<string, unknown>) : {};
}

app.http('me-availability', {
  methods: ['PATCH', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'me/availability',
  handler: createHandler({}, async ({ req, user, log }) => {
    const body = await readJson(req);
    if (typeof body['autoAssignEnabled'] !== 'boolean') {
      throw AppError.validation('autoAssignEnabled (boolean) is required');
    }
    const updated = await users.setAutoAssign(user.id, body['autoAssignEnabled']);
    log.info('Availability updated', { autoAssignEnabled: updated.autoAssignEnabled });
    return ok(profile(updated));
  }),
});
