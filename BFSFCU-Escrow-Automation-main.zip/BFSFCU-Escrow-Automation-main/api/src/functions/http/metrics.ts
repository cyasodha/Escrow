/**
 * Metrics (Manager only).
 *
 *   GET /api/metrics?assigned=<userId>   task-timing metrics, optionally scoped
 *                                        to one Escrow Admin (assigned=all → all)
 */

import { app } from '@azure/functions';
import { createHandler, ok } from '../../shared/handler';
import { Roles } from '../../shared/authorize';
import * as letters from '../../shared/repository/letters';

app.http('metrics', {
  methods: ['GET', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'metrics',
  handler: createHandler({ roles: Roles.admin }, async ({ req }) => {
    const url = new URL(req.url);
    const assigned = url.searchParams.get('assigned') ?? undefined;
    const metrics = await letters.taskMetrics(assigned && assigned !== 'all' ? assigned : undefined);
    return ok({ metrics });
  }),
});
