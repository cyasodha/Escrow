/**
 * Admin settings — Microsoft Entra SSO + the Oracle loan-lookup connection.
 *
 *   GET/PUT /api/settings/sso        Entra SSO config { enabled, tenantId, clientId }
 *   GET/PUT /api/settings/oracle     Oracle connection { enabled, host, port, serviceName, user }
 *   POST    /api/settings/oracle/test  live "Test connection" against the saved config
 *
 * Admin only. All stored values are NON-SECRET: Entra is a public client, and the
 * Oracle PASSWORD is never accepted or stored here — it comes from ORACLE_PASSWORD
 * (Key Vault). `passwordConfigured` tells the UI whether that env value is set.
 */

import { app } from '@azure/functions';
import { createHandler, ok } from '../../shared/handler';
import { Roles } from '../../shared/authorize';
import { AppError } from '../../shared/errors';
import { config } from '../../shared/config';
import {
  getSsoConfig,
  updateSsoConfig,
  getOracleConfig,
  updateOracleConfig,
  getOraclePassword,
} from '../../shared/repository/settings';
import { getOracleConnector, closeOraclePool } from '../../shared/oracle';
import {
  getScheduleConfig,
  updateScheduleConfig,
  listHolidays,
  addHoliday,
  deleteHoliday,
  getOooSyncLastRun,
  type ScheduleConfig,
} from '../../shared/schedule';
import { graphConfigured } from '../../shared/graph/client';
import { runOooSync } from '../../shared/oooSync';

// --------------------------------------------------------------------------
// Entra SSO
// --------------------------------------------------------------------------
app.http('settings-sso', {
  methods: ['GET', 'PUT', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'settings/sso',
  handler: createHandler({ roles: Roles.admin }, async ({ req, log }) => {
    if (req.method === 'GET') {
      return ok(await getSsoConfig());
    }

    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    const enabled = body['enabled'] === true;
    const tenantId =
      typeof body['tenantId'] === 'string' && body['tenantId'].trim() ? body['tenantId'].trim() : null;
    const clientId =
      typeof body['clientId'] === 'string' && body['clientId'].trim() ? body['clientId'].trim() : null;

    if (enabled && (!tenantId || !clientId)) {
      throw AppError.validation('Tenant ID and Client ID are required to enable SSO.');
    }

    const updated = await updateSsoConfig({ enabled, tenantId, clientId });
    log.info('Entra SSO settings updated', { enabled: updated.enabled });
    return ok(updated);
  }),
});

// --------------------------------------------------------------------------
// Oracle connection
// --------------------------------------------------------------------------
app.http('settings-oracle', {
  methods: ['GET', 'PUT', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'settings/oracle',
  handler: createHandler({ roles: Roles.admin }, async ({ req, log }) => {
    // A password exists if one was entered in the UI (app_settings) OR set via
    // ORACLE_PASSWORD (Key Vault). The value itself is never returned.
    const passwordConfigured = !!(await getOraclePassword()) || !!config.oracle.password;

    if (req.method === 'GET') {
      const cfg = await getOracleConfig();
      return ok({ ...cfg, passwordConfigured });
    }

    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    const enabled = body['enabled'] === true;
    const host = typeof body['host'] === 'string' && body['host'].trim() ? body['host'].trim() : null;
    const serviceName =
      typeof body['serviceName'] === 'string' && body['serviceName'].trim()
        ? body['serviceName'].trim()
        : null;
    const user = typeof body['user'] === 'string' && body['user'].trim() ? body['user'].trim() : null;
    const portRaw = body['port'];
    const port =
      typeof portRaw === 'number' && Number.isFinite(portRaw) ? Math.trunc(portRaw) : 1521;
    // Write-only: a non-empty value is stored; blank keeps the existing password.
    const password = typeof body['password'] === 'string' ? body['password'] : undefined;

    if (enabled && (!host || !serviceName || !user)) {
      throw AppError.validation('Host, service name, and user are required to enable Oracle lookups.');
    }

    const updated = await updateOracleConfig({ enabled, host, port, serviceName, user, password });
    // The connection changed — drop any live pool so the next use rebuilds it.
    await closeOraclePool();
    log.info('Oracle connection settings updated', { enabled: updated.enabled, host, port });
    const passwordNowConfigured = !!(await getOraclePassword()) || !!config.oracle.password;
    return ok({ ...updated, passwordConfigured: passwordNowConfigured });
  }),
});

// --------------------------------------------------------------------------
// POST /api/settings/oracle/test — live connectivity check against saved config
// --------------------------------------------------------------------------
app.http('settings-oracle-test', {
  methods: ['POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'settings/oracle/test',
  handler: createHandler({ roles: Roles.admin }, async ({ log }) => {
    // getOraclePool() throws AppError.upstream with a clear reason if the config
    // is disabled/incomplete or the server is unreachable.
    const result = await getOracleConnector().ping();
    log.info('Oracle connection test succeeded', { loanCount: result.loanCount });
    return ok({ ok: true, loanCount: result.loanCount });
  }),
});

// Escalation email notifications are configured entirely by env
// (NOTIFICATIONS_ENABLED / LOGIC_APP_URL) — there is nothing to read or set from
// the UI, so no settings endpoint. The send path lives in shared/notifications.

// --------------------------------------------------------------------------
// Business calendar (working days/hours + timezone) and holidays
// --------------------------------------------------------------------------
const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

function isValidTimeZone(tz: string): boolean {
  try {
    new Intl.DateTimeFormat('en-US', { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

app.http('settings-schedule', {
  methods: ['GET', 'PUT', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'settings/schedule',
  handler: createHandler({ roles: Roles.admin }, async ({ req, log }) => {
    if (req.method === 'GET') {
      const cfg = await getScheduleConfig();
      // Non-editable status the Scheduling page shows alongside the form.
      return ok({ ...cfg, lastRun: await getOooSyncLastRun(), graphConfigured: graphConfigured() });
    }

    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;

    const workDays = Array.isArray(body['workDays'])
      ? [...new Set(body['workDays'].map((n) => Number(n)))]
      : [];
    if (workDays.length === 0 || workDays.some((n) => !Number.isInteger(n) || n < 1 || n > 7)) {
      throw AppError.validation('workDays must be a non-empty list of ISO weekdays (1=Mon..7=Sun)');
    }
    const workStart = typeof body['workStart'] === 'string' ? body['workStart'] : '';
    const workCutoff = typeof body['workCutoff'] === 'string' ? body['workCutoff'] : '';
    if (!HHMM.test(workStart) || !HHMM.test(workCutoff)) {
      throw AppError.validation('workStart and workCutoff must be HH:MM (24-hour)');
    }
    if (workStart >= workCutoff) {
      throw AppError.validation('workStart must be earlier than workCutoff');
    }
    const timezone = typeof body['timezone'] === 'string' ? body['timezone'].trim() : '';
    if (!isValidTimeZone(timezone)) {
      throw AppError.validation('timezone must be a valid IANA zone (e.g. America/New_York)');
    }
    const oooSyncEnabled = body['oooSyncEnabled'] === true;

    const cfg: ScheduleConfig = { workDays, workStart, workCutoff, timezone, oooSyncEnabled };
    const updated = await updateScheduleConfig(cfg);
    log.info('Business calendar updated', { timezone, workStart, workCutoff });
    return ok(updated);
  }),
});

app.http('settings-holidays', {
  methods: ['GET', 'POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'settings/holidays',
  handler: createHandler({ roles: Roles.admin }, async ({ req, user, log }) => {
    if (req.method === 'GET') {
      return ok({ holidays: await listHolidays() });
    }

    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    const date = typeof body['date'] === 'string' ? body['date'].trim() : '';
    if (!ISO_DATE.test(date)) {
      throw AppError.validation('date must be YYYY-MM-DD');
    }
    const label =
      typeof body['label'] === 'string' && body['label'].trim() ? body['label'].trim() : null;
    const annual = body['annual'] === true;

    const holiday = await addHoliday(date, label, user.id, annual);
    log.info('Holiday added', { date, annual });
    return ok(holiday, 201);
  }),
});

app.http('settings-holiday-by-id', {
  methods: ['DELETE', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'settings/holidays/{id}',
  handler: createHandler({ roles: Roles.admin }, async ({ req, log }) => {
    const id = req.params['id'];
    if (!id) throw AppError.validation('Missing holiday id');
    await deleteHoliday(id);
    log.info('Holiday removed', { id });
    return ok({ id });
  }),
});

// POST /api/settings/ooo-sync/run — run the OOO sync now (Manager button / test).
// force = true bypasses the schedule, but still requires Graph to be enabled.
app.http('settings-ooo-sync-run', {
  methods: ['POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'settings/ooo-sync/run',
  handler: createHandler({ roles: Roles.admin }, async ({ log }) => {
    const result = await runOooSync({ force: true, log });
    if (!result.ran && result.reason === 'graph-disabled') {
      throw AppError.validation('Microsoft Graph is not enabled (set GRAPH_ENABLED).');
    }
    if (!result.ran && result.reason === 'graph-error') {
      throw AppError.upstream('Could not reach Microsoft Graph to read Out-of-Office.');
    }
    return ok(result);
  }),
});
