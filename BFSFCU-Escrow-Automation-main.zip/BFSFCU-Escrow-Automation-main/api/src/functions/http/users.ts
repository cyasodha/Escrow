/**
 * User management (admin only).
 *
 *   GET    /api/users        list users
 *   POST   /api/users        create a local user { email, fullName, role, password }
 *   PATCH  /api/users/{id}    update role / active flag / capacity / auto-assign
 *   DELETE /api/users/{id}    soft-delete (deactivate) + redistribute their open
 *                             letters; refuses to remove the last active manager
 *
 * There is no self-signup; an admin creates every account. SSO users are
 * match-existing-only, so an Entra user also needs an account created here first.
 */

import { app } from '@azure/functions';
import { createMethodHandler, ok } from '../../shared/handler';
import { Roles } from '../../shared/authorize';
import { AppError } from '../../shared/errors';
import { isAppRole } from '../../shared/auth';
import { isCapacityLevel, type CapacityLevel } from '../../shared/assignment';
import { hashPassword } from '../../shared/password';
import * as users from '../../shared/repository/users';
import { deactivateUser } from '../../shared/repository/assignments';
import { recordAudit } from '../../shared/repository/activity';

async function readJson(req: { json: () => Promise<unknown> }): Promise<Record<string, unknown>> {
  const body = await req.json().catch(() => null);
  return body && typeof body === 'object' ? (body as Record<string, unknown>) : {};
}

app.http('users', {
  methods: ['GET', 'POST', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'users',
  handler: createMethodHandler({
    GET: {
      roles: Roles.admin,
      handler: async () => ok({ users: await users.listUsers() }),
    },
    POST: {
      roles: Roles.admin,
      handler: async ({ req, log }) => {
        const body = await readJson(req);
        const email = typeof body['email'] === 'string' ? body['email'].trim() : '';
        const fullName = typeof body['fullName'] === 'string' ? body['fullName'].trim() : null;
        const roleRaw = typeof body['role'] === 'string' ? body['role'] : 'user';
        const password = typeof body['password'] === 'string' ? body['password'] : '';
        const capacityRaw = body['capacity'];

        if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
          throw AppError.validation('A valid email is required');
        }
        if (!isAppRole(roleRaw)) {
          throw AppError.validation("role must be 'admin' or 'user'");
        }
        if (password.length < 8) {
          throw AppError.validation('Password must be at least 8 characters');
        }
        let capacity: CapacityLevel | undefined;
        if (capacityRaw !== undefined && capacityRaw !== null) {
          if (!isCapacityLevel(capacityRaw)) {
            throw AppError.validation("capacity must be 'light', 'regular', or 'heavy'");
          }
          capacity = capacityRaw;
        }

        const created = await users.createLocalUser({
          email,
          fullName,
          role: roleRaw,
          passwordHash: await hashPassword(password),
          ...(capacity ? { capacity } : {}),
        });
        log.info('User created', { userId: created.id, role: created.role });
        return ok(created, 201);
      },
    },
  }),
});

app.http('user-by-id', {
  methods: ['PATCH', 'DELETE', 'OPTIONS'],
  authLevel: 'anonymous',
  route: 'users/{id}',
  handler: createMethodHandler({
    PATCH: {
      roles: Roles.admin,
      handler: async ({ req, log }) => {
        const id = req.params['id'];
        if (!id) throw AppError.validation('Missing user id');

        const body = await readJson(req);
        const fields: {
          role?: 'admin' | 'user';
          isActive?: boolean;
          capacity?: CapacityLevel;
          autoAssignEnabled?: boolean;
        } = {};
        if (typeof body['role'] === 'string') {
          if (!isAppRole(body['role'])) throw AppError.validation("role must be 'admin' or 'user'");
          fields.role = body['role'];
        }
        if (typeof body['isActive'] === 'boolean') fields.isActive = body['isActive'];
        if (body['capacity'] !== undefined) {
          if (!isCapacityLevel(body['capacity'])) {
            throw AppError.validation("capacity must be 'light', 'regular', or 'heavy'");
          }
          fields.capacity = body['capacity'];
        }
        if (typeof body['autoAssignEnabled'] === 'boolean') {
          fields.autoAssignEnabled = body['autoAssignEnabled'];
        }

        if (Object.keys(fields).length === 0) {
          throw AppError.validation(
            'No updatable fields were supplied (role, isActive, capacity, autoAssignEnabled)'
          );
        }

        const updated = await users.updateUser(id, fields);
        log.info('User updated', { userId: id, ...fields });
        return ok(updated);
      },
    },

    // Soft delete: deactivate the account and auto-distribute its open letters.
    // Refuses to remove the last active manager.
    DELETE: {
      roles: Roles.admin,
      handler: async ({ req, user, log }) => {
        const id = req.params['id'];
        if (!id) throw AppError.validation('Missing user id');

        const result = await deactivateUser(id, user.id);
        await recordAudit({
          entityType: 'user',
          entityId: id,
          action: 'deactivated',
          userId: user.id,
          metadata: { ...result },
        }).catch(() => undefined);
        log.info('User deactivated', { userId: id, ...result });
        return ok({ ok: true, ...result });
      },
    },
  }),
});
