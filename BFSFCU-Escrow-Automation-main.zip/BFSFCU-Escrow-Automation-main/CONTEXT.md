# Context for AI assistants

Read this before changing anything. It is written for an AI coding assistant (or
a new engineer) joining this repository cold, and covers what the code does not
say about itself: what the app is, why things are the way they are, the traps,
and how it is deployed.

---

## What this is

A standalone app for **BFSFCU Loan Servicing** that ingests **escrow insurance
letters** — **policy modifications** and **LA R.S. 22:1266 cancellations** — from
the credit union's members' insurers. It extracts the fields with AI, matches the
letter to the member's loan in **Oracle**, compares it to the insurance on file,
auto-tiers each letter **High** or **Low** confidence, and **auto-assigns** it to
an Escrow Admin (by capacity weight) for review. Bank Fund Credit Union is the
mortgagee / loss-payee on every letter.

**Two roles (UI labels), one work model:** a **Manager** (DB role `admin`)
oversees — balances the team's workload, watches the intake pipeline, escalates
and reassigns — but never accepts/declines a letter. An **Escrow Admin** (DB role
`user`) works only the letters **assigned to them**: a single **My Tasks** list
where each letter is flagged *Action required* or *No action needed*, and
escalated ones are pinned as *Priority*. (See "Roles & work distribution" below.)

It is a **fork of the AP invoice-automation app** (`../bfsfcu-ap`): the whole
platform layer (auth, handler, db, blob, queue, AI stage-1/stage-2, queue-worker
pipeline, review-queue UI) is reused; only the domain changed (invoices → escrow
letters, vendor match → Oracle loan match).

Stack: **Azure Functions (TypeScript) + React/Vite SPA + PostgreSQL + Azure Blob/
Queue + Azure Document Intelligence + Azure OpenAI + a read-only Oracle connector**.
Local auth (session cookie) + optional Microsoft Entra SSO.

---

## The flow (the whole point)

```
upload letter (manual, or Power Automate via X-Api-Key)
  → Blob + queue message → 202 returned          (upload is instant)
  → queue worker (processLetter):
       Document Intelligence (prebuilt-layout) → full text
       Azure OpenAI (gpt-5.1) → 11 fields + letter type + cancellation subtype
       Oracle match: policy # (PRIMARY) + loan # / name+address (PII)
       compare vs insurance-on-file → premium delta + flags
       AUTO-TIER: High or Low
       persist (one transaction) + AUTO-ASSIGN to an Escrow Admin by capacity weight
  → Escrow Admin "My Tasks" (only their assigned letters, flagged action / no-action)
       → Accept | Decline   (Managers cannot; they oversee only)
  → Manager: Team Workload (escalate / reassign, capacity, availability) + Inbox Monitor
```

**The 11 fields:** carrier, policy #, property address, insured name, loan #,
dwelling coverage, total premium, policy period start, policy period end, policy
type (e.g. HO-3), reason. The due date is **derived** from the policy period start.

**Cancellations** carry a 3-way subtype from the statutory checkbox — `nonpayment`
(lapse risk), `provider_switch` (replacement bound), `non_renewal` (underwriting).
It is **metadata only**: a cancellation is compared and tiered like a modification;
the subtype helps a reviewer decide whether to move it to Task. No auto-branch.

---

## Locked decisions (do not "improve" without being asked)

1. **Auto-tier is High or Low ONLY** (no automatic Exception). The tier still
   drives the flag an Escrow Admin sees: **High** → *No action needed*, **Low** →
   *Action required*. There is **no "Review" queue** — a low-confidence /
   unreadable / not-matched letter is simply *Action required* work, assigned like
   any other. `moveToTask` and `returnToReview` remain in the workflow layer but
   the escrow-admin UI exposes only Accept / Decline / Move to Action Required.
   Downstream (payment / OnBase / OSI) is on hold.
2. **High** = a 100% match on **PII** (insured name + property address) **and
   account** (loan # + policy #) with the Oracle record, after normalization, with
   an active mortgage. **Low** = anything less.
3. **Policy number is the PRIMARY insurance match.** The letter's policy # is
   looked up directly in `insurance_on_file`. If it is not on file (a new /
   replacement policy), the letter is tagged **`no_matching_insurance`** ("No
   matching insurance found"), the account match fails (→ Low), and the review
   screen **hides the Comparison card** (nothing meaningful to compare against).
4. The **premium delta** vs on-file is shown as a flag (>5%) to help the reviewer;
   it does **not** auto-route.
5. **Oracle is a separate, deployed DB** reached through a read-only connector
   (`shared/oracle/`). The connection (host/port/service/user/enabled) is
   configured from the **admin UI** and stored in `app_settings`; only the
   password comes from `ORACLE_PASSWORD` (or the UI-entered value in
   `app_settings.oracle_password`, write-only). Oracle-down degrades gracefully —
   the letter still processes and lands **Low**, never fails.
6. **Managers never accept/decline.** Only the assigned Escrow Admin does. A role
   list can't express this (`admin` implicitly satisfies every role check in
   `hasRole`), so it's an explicit `assertNotManager` guard on approve / decline /
   batch-approve, and the Review-actions card is hidden for managers.
7. **Escrow Admins see only what is assigned to them.** `GET /api/letters` forces
   `assigned_to = <caller>` for role `user`, whatever the query says; `getById` /
   `file` 404 for a non-owner. Managers see everything.
8. **Capacity is a relative WEIGHT, not a cap** (light 8 : regular 15 : heavy 25 in
   `shared/assignment.ts`). Auto-distribution is weighted least-loaded; there is no
   hard ceiling. `auto_assign_enabled=false` pauses a user (Manager-controlled).

---

## Layout

```
api/src/
  index.ts                    every function module is imported here or it won't register
  functions/http/             auth me letters workflow team inbox settings users integrations demo
  functions/queue/            processLetter.ts — the pipeline worker
  shared/
    handler.ts auth.ts authorize.ts config.ts db.ts errors.ts logger.ts cors.ts
    blob.ts queue.ts password.ts entra.ts normalize.ts
    assignment.ts             capacity weights + weighted least-loaded picker
    ai/                       credential · documentIntelligence · openai
    oracle/                   connector (interface) · oracledb (impl) · connection · index
    pipeline/                 oracleMatch · compare · tiering · duplicateCheck · persist (assigns on save)
    repository/               letters · workflow · assignments · users · activity · settings · apiKeys
db/migrations/                0001..0007, applied in filename order, idempotent
mock_db/                      the SEPARATE Oracle DB: schema + read-only user + sample data
web/src/
  App.tsx main.tsx            routes + AuthProvider (ManagerRoute gates manager-only pages)
  hooks/useAuth.ts            AuthProvider context (isManager / isEscrowAdmin)
  lib/                        api (the only way to reach the backend) · entra · roles · format · letterStatus · letterReasons
  services/index.ts           typed API calls (letters · team · inbox · me · users · …)
  components/                 Layout (topbar+sidebar) · AppSidebar (role-aware nav + demo reset)
  pages/                      Auth Dashboard MyTasks TeamWorkload InboxMonitor LettersQueue LetterDetail Upload UserManagement OracleSettings AuditConsole
.github/workflows/            deploy-api.yml · deploy-web.yml (push to dev)
```

---

## Domain model

**`letters.status`** (enum unchanged) is the lifecycle:

```
queued → processing → high_confidence | low_confidence | task
high_confidence | low_confidence | task → approved | rejected
```

`confidence_tier` (high|low) is the immutable auto-decision, stored separately from
`status` so it survives a decision. The **status → UX flag** mapping (see
`web/src/lib/letterStatus.ts` `actionFlag`): `high_confidence` → *No action
needed*; `task` and `low_confidence` → *Action required*; `approved`/`rejected` →
*Accepted*/*Declined*. There is **no separate Review queue** — every open status
(high_confidence, task, low_confidence) is owner-actionable work.

### Roles & work distribution

Two `app_role` values, **unchanged**: `admin` and `user`. UI labels differ (see
`web/src/lib/roles.ts`): **`admin` = "Manager"**, **`user` = "Escrow Admin"**.

- **Escrow Admin** — works only letters `assigned_to` them. Nav: **My Tasks**
  (assigned + open, priority-then-task-date sorted), **Accepted**, **Declined**,
  **Upload Letters**. Accepts/declines and edits the extracted fields on their own
  letters; reschedules the **task date** (a note is required). No availability
  self-toggle.
- **Manager** — oversight only. Nav: **Team Workload** (per-admin open/urgent
  counts, capacity, auto-assign toggle, drill-in to escalate / reassign / search),
  team-wide **Accepted**/**Declined**, **Upload Letters**, and a **Management**
  section (Inbox Monitor, User Management, Oracle Connection, Audit Log). No
  personal task queue; **cannot accept/decline**.
- `power-automate@bfsfcu.test` (role `user`) authenticates by **`X-Api-Key`** for
  machine ingestion and is excluded from the distribution pool.

**Assignment columns** (`letters`): `assigned_to` / `assigned_at` / `assigned_by`,
`escalated` / `escalated_at` / `escalated_by`, `task_date`. **User columns**:
`capacity` (`capacity_level` enum light|regular|heavy) + `auto_assign_enabled`.

- **Auto-distribution** (`shared/assignment.ts` + `repository/assignments.ts`,
  called from `pipeline/persist.ts`): each processed letter goes to the eligible
  Escrow Admin with the lowest `open / weight` ratio (weights 8/15/25). Skips
  paused users and the machine account. Manual uploads may self-assign instead.
- **Escalation**: a Manager flags a letter `escalated` (Team Workload) → pinned red
  as *Priority* at the top of the owner's My Tasks.
- **Task date**: defaults to the received date; the owner moves it with a required
  note (`workflow.moveTaskDate` → a letter note + `task_date_moved` audit). My Tasks
  and the Team Workload drill sort **escalated first, then task date ascending**.
- **Policy #** is the first column on every letter list.

---

## Traps (these have bitten)

- **Stage-2 AI failures are swallowed by design** (`extractLetter` returns null so
  a reasoning failure never loses a letter). A total misconfig therefore looks
  like success: the 11 fields are simply empty. Verify with `confidence_score`
  (only stage 2 sets it).
- **`no_matching_insurance` vs `policy_change`.** When the policy is not on file
  the worker replaces the generic `policy_change` flag with `no_matching_insurance`
  and the UI hides the Comparison card. Don't reintroduce `policy_change` there.
- **`audit_logs` is append-only** (a trigger blocks UPDATE/DELETE). The demo reset
  clears it with `TRUNCATE` (which bypasses the row trigger), not `DELETE`.
- **Oracle DATE drift**: dates are pulled with `TO_CHAR(...,'YYYY-MM-DD')` and PG
  `DATE` columns are returned as plain strings (`types.setTypeParser(1082,…)`).
  Keep it that way — a calendar date is not an instant.
- **Cross-origin cookies (cloud).** SPA and API are different domains, so the
  session cookie is `SameSite=None; Secure` (see `functions/http/auth.ts`) and the
  client sends `credentials:"include"`. Local dev is same-origin via the Vite
  proxy and uses `SameSite=Lax`. **Azure Functions' platform CORS intercepts the
  OPTIONS preflight**, so in the cloud CORS is configured on the Function App
  (App Service CORS: allow the SWA origin + `supportCredentials=true`) and the
  app-code `ALLOWED_ORIGINS` is left empty to avoid a duplicate `Allow-Origin`.
- **`vite build` does not typecheck.** Run `npm run typecheck` (web) and
  `npx tsc --noEmit` (api).
- Every new HTTP route file must be imported in `api/src/index.ts` or it never
  registers.

---

## Deployment (a demo, in `rg-peapod-test`)

Fully deployed in Azure; see **[docs/CLIENT-DEPLOYMENT.md](docs/CLIENT-DEPLOYMENT.md)**.

- Web → Static Web App `bfsfcuescrow-web`; API → Flex Consumption Function App
  `bfsfcuescrow-api`; app DB `bfsfcu_escrow` on the existing `bfsfcuap-pg`; Oracle
  as a Container Instance `bfsfcu-escrow-oracle`; Storage + Azure AI reused from
  the AP app.
- **CI/CD**: push to **`dev`** → GitHub Actions redeploy the API and/or web.
- SPA and API are different domains → credentialed CORS (above).
- `DEMO_MODE=true`, so the sidebar **Reset Demo Data** control is live.
- The **Oracle ACI is ephemeral** — a restart loses its data and changes its FQDN;
  reload `mock_db/*.sql` and update `app_settings.oracle_host` if you recreate it.

---

## Contributing

- **Push to `dev` only.** `main` is protected; changes reach `main` via PR from
  `dev`. See [DEVELOPER.md](DEVELOPER.md) for local setup on Windows.
- New numbered migration for any schema change (never edit an applied one).
- Secrets never go in git: `api/local.settings.json` and `web/.env*` (except
  `.env.example` / `.env.production`, which hold only public config) are ignored.
```
