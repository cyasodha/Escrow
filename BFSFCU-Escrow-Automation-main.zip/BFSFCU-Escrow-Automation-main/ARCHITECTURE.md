# Architecture

Escrow insurance letter automation for BFSFCU Loan Servicing. Letters arrive, are
extracted by AI, matched to the member's loan in Oracle, compared to the insurance
on file, auto-tiered High/Low, and reviewed. A fork of the AP invoice-automation
app; the platform layer is reused, the domain is new. See [CONTEXT.md](CONTEXT.md)
for conventions and traps, and [docs/CLIENT-DEPLOYMENT.md](docs/CLIENT-DEPLOYMENT.md)
for deployment.

---

## Stack

React/Vite SPA · Azure Functions (TypeScript, v4 programming model) · PostgreSQL
Flexible Server · Azure Blob + Queue Storage · Azure Document Intelligence + Azure
OpenAI · a read-only Oracle connector (node-oracledb, Thin mode) · local
email/password auth (HS256 session cookie) + optional Microsoft Entra SSO.

```
Browser (React SPA on Static Web App)
   │  HTTPS, credentialed CORS  (session cookie: httpOnly, Secure, SameSite=None)
   ▼
Azure Functions (Flex Consumption)  ──HTTP──►  PostgreSQL  (app workflow DB)
   │  upload → Blob + queue msg → 202              ▲
   ▼                                               │
Queue worker (processLetter)                       │
   ├─► Azure Document Intelligence (prebuilt-layout)
   ├─► Azure OpenAI (gpt-5.1, structured output)
   ├─► Oracle (read-only connector) ──► Oracle DB (loan + insurance_on_file)
   └─► Blob Storage (the scanned letter)
```

Uploads return in ~1s; all the slow work (OCR, the LLM, Oracle) runs in the
queue-triggered worker, so the browser never waits on the pipeline.

**Ingest shapes** (all land on the same `blob + row(queued) + queue message`, so
the pipeline, dedup by `file_hash`, source tagging and multi-letter classify/split
behave identically regardless of how the bytes arrived): a browser
`multipart/form-data` upload; a machine JSON `{ pdf_base64, filename }` body; or a
**blob reference** `{ blobPath, filename }` — the Logic App inbox flow uploads the
letter straight into the letters container and posts only its path, so no file
bytes cross a gateway/WAF request-body limit. The API reads the referenced blob
back to hash and type-check it. Both machine shapes present an `X-Api-Key` and are
auto-distributed after processing.

---

## Components

| Path | What it is |
|---|---|
| `web/` | React SPA (Vite). The only way it reaches the backend is `web/src/lib/api.ts`. |
| `api/` | Azure Functions: thin HTTP routes + the queue worker; all logic in `api/src/shared`. |
| `db/migrations/` | Numbered SQL (`0001`..`0007`), applied in order, idempotent. |
| `mock_db/` | The **separate** Oracle DB: schema DDL, read-only user, synthetic sample data. |
| `.github/workflows/` | CI/CD: deploy API + web on push to `dev`. |

### `api/src` request path

Every route goes through `createHandler` / `createMethodHandler` in
`shared/handler.ts` — the one place that authenticates, resolves the user, checks
the role, shapes errors, and sets CORS. A route cannot forget to authenticate.

1. **Authenticate** (`shared/auth.ts`) — an `X-Api-Key` (machine caller) if
   present, else the HS256 session cookie. The only place a token is verified.
2. **Resolve user** (`repository/users.ts`), keyed on `users.id` (the token `sub`).
3. **Authorize** (`shared/authorize.ts`) — the only place role decisions are made.
4. **Run the handler**, which returns a response or throws an `AppError`.

One `app.http()` registration per route; methods sharing a path use
`createMethodHandler` with **per-method roles**.

---

## The letter pipeline (`functions/queue/processLetter.ts`)

```
download blob
  → analyzeLetter()        Document Intelligence prebuilt-layout → full text        (required)
  → extractLetter()        Azure OpenAI, strict JSON schema → 11 fields + type/subtype (non-blocking)
  → matchToOracle()        policy # (primary) + loan#/name+address (PII)             (graceful if Oracle down)
  → compareToOnFile()      field-by-field vs insurance on file → premium delta + flags
  → tierLetter()           High = 100% PII + account (loan# + policyFound); else Low
  → detectDuplicate()      same policy# + loan# already on file → flag/link only
  → saveProcessedLetter()  one transaction: the letter row + an audit row +
                           AUTO-ASSIGN to an Escrow Admin (assignAfterProcessing)
```

- **Stage 1 (Document Intelligence)** — `prebuilt-layout` (these letters are forms,
  not invoices). Submit then poll. A failure fails the letter (→ Low after retries).
- **Stage 2 (Azure OpenAI)** — `gpt-5.1` reasoning model, `response_format`
  json_schema strict. Non-blocking by design: any failure returns null and the
  letter keeps whatever it has. Verify success with `confidence_score`.
- **Oracle match** — `findInsuranceByPolicyNumber` (PRIMARY) decides `policyFound`;
  `findLoanByNumber` → `findLoanByNameAddress` establishes the loan for PII. If the
  policy isn't on file → `no_matching_insurance` flag (and the UI hides Comparison).
- **Tiering** — pure/synchronous. `accountMatch = loan# matches AND policyFound`.
  `High` requires `piiMatch && accountMatch && mortgage ACTIVE`.
- **Route + persist** — `routeLetter` picks `high_confidence` / `task` /
  `low_confidence`; the pipeline never writes `approved`/`rejected` (reviewer
  actions).
- **Assign** — inside the same persist transaction, `assignAfterProcessing`
  (`repository/assignments.ts`) gives the letter to the eligible Escrow Admin with
  the lowest `open / capacity-weight` ratio (weights in `shared/assignment.ts`),
  unless it was self-assigned at upload. Paused users and the machine account are
  skipped. There is **no manager exception bucket** — a low-confidence letter is
  distributed like any Action-Required work.

Retries: the host redelivers a throwing worker up to `maxDequeueCount` (5); after
that the letter is marked Action-Required (`low_confidence`, error attached) and
distributed to an Escrow Admin (`autoAssignToPool`) — never the poison queue for a
normal extraction failure.

---

## The Oracle connector (`shared/oracle/`)

A thin, **read-only** data-access layer written against an interface so the source
is swappable (SOW §6) and the app writes nothing back to Oracle.

- `connector.ts` — the `OracleConnector` interface + `LoanRecord` / `InsuranceOnFile`.
- `oracledb.ts` — the node-oracledb (Thin mode) implementation:
  `findLoanByNumber`, `findLoanByNameAddress` (fallback), `getInsuranceOnFile`,
  `findInsuranceByPolicyNumber` (primary), `ping`.
- `connection.ts` — lazy pool; connection read from `app_settings` (UI-configured),
  password from `ORACLE_PASSWORD` env or `app_settings.oracle_password`. Rebuilds
  the pool when the connection changes; `isOracleReady()` gates the pipeline.
- `mock_db/` — the DDL + read-only user + synthetic data for a stood-up Oracle.

Normalization (`shared/normalize.ts`) is shared by the connector's fallback match
and the tiering, so "Rd" == "Road", "ALS-7729014" == "als 7729014", "Allstate" ==
"Allstate Inc." are treated consistently.

---

## Data (PostgreSQL)

Extensions `pgcrypto` + `pg_trgm` (allow-listed in `azure.extensions`).

| Table | Notes |
|---|---|
| `users` | id-keyed; local password + Entra SSO seam (`auth_provider`/`external_id`); `role` (admin=Manager, user=Escrow Admin) + `capacity` (`capacity_level` light\|regular\|heavy) + `auto_assign_enabled`. |
| `letters` | the 11 fields + type/subtype + Oracle match + compare result + tier; `status` + assignment (`assigned_to`/`assigned_at`/`assigned_by`), `escalated` (+`escalated_at`/`escalated_by`), and `task_date` (defaults to received date). |
| `letter_notes` | reviewer notes on a letter. |
| `audit_logs` | append-only (a trigger blocks UPDATE/DELETE); one row per action. |
| `app_settings` | single row: Entra SSO + Oracle connection (non-secret) + `oracle_password` (write-only). |
| `api_keys` | hashed machine keys (Power Automate); the raw key is shown once. |

---

## Identity, authorization, CORS

- **Local auth** — email/password → HS256 session cookie (httpOnly). **Entra SSO**
  is optional on the `auth_provider`/`external_id` seam (public client / PKCE; the
  backend verifies the ID token and issues the same cookie). Match-existing-only.
- **Machine auth** — `X-Api-Key` maps to the Power Automate service account.
- **Two roles** — `admin` (UI label **Manager**) and `user` (**Escrow Admin**); see
  `web/src/lib/roles.ts`. Managers oversee and **cannot accept/decline** (explicit
  `assertNotManager` guard, since `admin` implicitly satisfies every role check);
  Escrow Admins act only on letters assigned to them (`GET /api/letters` forces
  `assigned_to = caller` for role `user`).
- **CORS** — same-origin in local dev (Vite proxy `/api`). In the cloud the SPA and
  API are different domains: credentialed CORS with the session cookie
  `SameSite=None; Secure`. Because Azure Functions' platform intercepts the OPTIONS
  preflight, CORS is configured on the Function App (App Service CORS: the SWA
  origin + `supportCredentials=true`) and app-code `ALLOWED_ORIGINS` is left empty
  to avoid a duplicate `Access-Control-Allow-Origin`.

---

## Front end

- **Routing** (`App.tsx`) — `/dashboard`, `/my-tasks`, `/accepted`, `/declined`,
  `/upload`, `/letters/:id`; Manager-only (`ManagerRoute`): `/team-workload`,
  `/inbox`, `/user-management`, `/oracle-connection`, `/audit`. Legacy queue paths
  (`/high-confidence`, `/task`, `/low-confidence`, `/approved`) redirect.
- **Layout** — navy top bar (BFSFCU logo) over a **role-aware** collapsible sidebar
  (Escrow Admin: My Tasks / Accepted / Declined / Upload; Manager: Team Workload +
  team-wide Accepted/Declined + Upload + a **Management** section: Inbox Monitor /
  User Management / Oracle Connection / Audit Log); Manager-only footer **Reset Demo
  Data** when `DEMO_MODE` is on.
- **Review screen** (`LetterDetail`) — source document · Insurance Details (editable
  by owner/Manager while the letter is open) · Oracle loan match · Comparison
  (hidden when `no_matching_insurance`) · Flags · a **Task date** reschedule (Escrow
  Admin, note required) · **Review actions** (Escrow Admin only: Accept / Move to
  Action Required / Decline) · Notes & audit. The header shows a read-only
  **Assigned: <name>** and a Priority badge; escalate/reassign are on Team Workload.
- **Manager screens** — **Team Workload** (`/team-workload`): per-admin open/urgent
  counts, capacity, auto-assign toggle, and a drill-in to escalate / reassign /
  search that admin's letters. **Inbox Monitor** (`/inbox`): email / Power-Automate
  pipeline health tiles + list, auto-refresh.
- **Policy #** is the first column on every letter list; **My Tasks** and the Team
  Workload drill sort escalated first, then task date.
- **Audit** is per-letter: a searchable list → a per-letter history modal timeline.
- API base URL: local uses the `/api` proxy; production reads
  `web/.env.production` (`VITE_API_BASE_URL` → the Function App URL).

---

## Deployment & CI/CD

Demo deployment entirely in `rg-peapod-test`, reusing the AP app's Postgres,
Storage, and Azure AI. Web on a Static Web App, API on a Flex Consumption Function
App, Oracle on a Container Instance. Push to **`dev`** triggers the GitHub Actions
that rebuild and redeploy. For a full **from-scratch** deployment — provisioning
every Azure resource in the client's own subscription, plus all settings and the
CI/CD wiring — follow the runbook in
**[docs/CLIENT-DEPLOYMENT.md](docs/CLIENT-DEPLOYMENT.md)**.

---

## Deliberate omissions (this release)

- **No automatic Exception routing** — auto-tier is High/Low only; `moveToTask` is a
  manual reviewer action. Unreadable/low-confidence letters are Action-Required
  work distributed to Escrow Admins, not a separate exception bucket.
- **Downstream on hold** — no payment/check-run file, report, OnBase, or OSI push.
- **Email intake is the Logic App inbox flow** — it lands the document in the
  letters container and posts a `{ blobPath, filename }` reference (`X-Api-Key`);
  the inline `{ pdf_base64 }` upload path remains for other machine callers.
- **No persistence for the demo Oracle ACI** and no managed Oracle — demo scope.
