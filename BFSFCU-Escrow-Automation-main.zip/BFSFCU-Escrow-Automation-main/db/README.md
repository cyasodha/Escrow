# Application database (PostgreSQL)

This is the app's **own** workflow database — letters, users, notes, audit,
settings. It is separate from the credit union's **Oracle** loan system, which
the app only reads from through a connector (see [`../mock_db/`](../mock_db) for
the Oracle schema + sample data).

## Migrations

`migrations/` holds numbered SQL applied **in filename order**. Each is wrapped
in a transaction and written to be **idempotent** (re-runnable) — never edit an
already-applied migration; add a new numbered one.

| File | What it creates |
|---|---|
| `0001_extensions_and_users.sql` | `pgcrypto` + `pg_trgm`, `app_role` enum, `users` (local auth + SSO seam), seeded admin |
| `0002_letters.sql` | letter enums, `letters` (11 fields + type/subtype + match/compare/tier), `letter_notes`, append-only `audit_logs` |
| `0003_app_settings.sql` | single-row `app_settings` (Entra SSO + Oracle connection, non-secret only) |
| `0004_oracle_password.sql` | write-only `app_settings.oracle_password` column |
| `0005_api_keys.sql` | `api_keys` (hashed machine keys) + the Power Automate service account |
| `0006_assignment_and_capacity.sql` | `capacity_level` enum, `users.capacity`/`auto_assign_enabled`, `letters` assignment + escalation columns, seeded demo Escrow Admins |
| `0007_task_date.sql` | `letters.task_date` (defaults to the received date) + index |

### Apply locally

```bash
# Postgres 16, local Docker default creds (throwaway — not a secret)
export PGHOST=127.0.0.1 PGUSER=postgres PGPASSWORD=postgres PGDATABASE=bfsfcu_escrow
createdb bfsfcu_escrow 2>/dev/null || true
for f in db/migrations/*.sql; do echo ">> $f"; psql -v ON_ERROR_STOP=1 -f "$f"; done
```

Or on Windows with the bundled helper:

```powershell
./db/apply.ps1
```

> Azure Postgres requires `pgcrypto` and `pg_trgm` allow-listed in the
> `azure.extensions` server parameter, or `CREATE EXTENSION` is refused.

### Seeded admin

`admin@bfsfcu.test` / `Escrow@review` — **change the password after first
sign-in.** SSO users are match-existing-only (an admin must create the account
first), so this local admin is how you bootstrap.
