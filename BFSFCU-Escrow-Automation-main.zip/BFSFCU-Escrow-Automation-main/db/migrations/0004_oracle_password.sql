-- 0004_oracle_password.sql
-- Allow the Oracle read-only account password to be set from the admin UI.
--
-- NOTE: this relaxes the platform's "no secret in the database" rule for POC
-- convenience — configuring the whole Oracle connection from the UI. The value
-- is write-only over the API (never returned to the browser). For production,
-- prefer ORACLE_PASSWORD (Key Vault); if a UI-entered password is required,
-- encrypt it at rest (e.g. pgcrypto with a Key Vault-held key). The connector
-- uses this value when set, and falls back to ORACLE_PASSWORD otherwise.

BEGIN;

ALTER TABLE app_settings ADD COLUMN IF NOT EXISTS oracle_password text;

COMMENT ON COLUMN app_settings.oracle_password IS
  'Oracle read-only account password entered from the admin UI (POC convenience). Write-only over the API; prefer ORACLE_PASSWORD / encryption at rest for production.';

COMMIT;
