-- 0012_ooo_sync.sql
-- Nightly OOO sync bookkeeping.
--
-- The sync runs at the business cutoff and sets users.ooo_auto for the NEXT
-- working day. A frequent timer checks the clock against work_cutoff/work_timezone
-- (so the time stays UI-configurable); ooo_sync_last_run records the local date it
-- last ran, so it fires once per day.

BEGIN;

ALTER TABLE app_settings
  ADD COLUMN IF NOT EXISTS ooo_sync_last_run date;

COMMENT ON COLUMN app_settings.ooo_sync_last_run IS
  'Local (work_timezone) date the OOO sync last completed; guards once-per-day runs.';

COMMIT;
