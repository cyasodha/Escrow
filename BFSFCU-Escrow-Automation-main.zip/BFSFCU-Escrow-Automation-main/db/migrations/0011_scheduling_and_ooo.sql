-- 0011_scheduling_and_ooo.sql
-- Business calendar + holidays + Out-of-Office availability.
--
-- Introduces a working-hours model so letters received after the daily cutoff,
-- on weekends, or on holidays are worked on the next working day (their
-- task_date / next-activity date is stamped accordingly), and an OOO layer that
-- removes out-of-office Escrow Admins from auto-distribution.
--
-- OOO is two independent signals, kept SEPARATE from the manual auto_assign_enabled
-- pause so nothing clobbers anything:
--   - ooo_auto     : set by the nightly Graph sync (Phase 2) for the next working day.
--   - ooo_override : a Manager's explicit force-include / force-exclude (Phase 1).
-- Effective out = (ooo_override = 'force_out') OR (ooo_override = 'none' AND ooo_auto).

BEGIN;

-- ---------------------------------------------------------------------------
-- Business calendar (on the single app_settings row). Times are wall-clock in
-- work_timezone. work_days uses ISO day-of-week (1 = Mon ... 7 = Sun).
-- ---------------------------------------------------------------------------
ALTER TABLE app_settings
  ADD COLUMN IF NOT EXISTS work_days        integer[] NOT NULL DEFAULT '{1,2,3,4,5}',
  ADD COLUMN IF NOT EXISTS work_start       time      NOT NULL DEFAULT '09:00',
  ADD COLUMN IF NOT EXISTS work_cutoff      time      NOT NULL DEFAULT '17:00',
  ADD COLUMN IF NOT EXISTS work_timezone    text      NOT NULL DEFAULT 'America/New_York',
  ADD COLUMN IF NOT EXISTS ooo_sync_enabled boolean   NOT NULL DEFAULT false;

COMMENT ON COLUMN app_settings.work_days IS
  'Working days as ISO day-of-week (1=Mon..7=Sun). Default Mon-Fri.';
COMMENT ON COLUMN app_settings.work_cutoff IS
  'End of the working day (wall-clock, work_timezone). Also the OOO-sync trigger time.';
COMMENT ON COLUMN app_settings.ooo_sync_enabled IS
  'When true, the nightly Graph OOO sync (Phase 2) runs at work_cutoff.';

-- ---------------------------------------------------------------------------
-- Holidays (manager-managed non-working days).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS holidays (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  holiday_date date NOT NULL UNIQUE,
  label        text,
  created_by   uuid REFERENCES users(id),
  created_at   timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE holidays IS
  'Non-working days on top of weekends; used by the business-calendar next-activity math.';

-- ---------------------------------------------------------------------------
-- OOO availability on users.
-- ---------------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'ooo_override') THEN
    CREATE TYPE ooo_override AS ENUM ('none', 'force_in', 'force_out');
  END IF;
END$$;

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS ooo_auto     boolean      NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS ooo_override ooo_override NOT NULL DEFAULT 'none';

COMMENT ON COLUMN users.ooo_auto IS
  'Set by the nightly Graph OOO sync: true = out of office for the next working day.';
COMMENT ON COLUMN users.ooo_override IS
  'Manager override: force_out (exclude), force_in (keep in despite ooo_auto), none (follow ooo_auto).';

-- ---------------------------------------------------------------------------
-- Letters: the first (business-adjusted) next-activity instant. Set ONCE at the
-- first assignment; the metric baseline (recorded now, used later). task_date
-- (0007) remains the reschedulable working DATE; this is the precise timestamp.
-- ---------------------------------------------------------------------------
ALTER TABLE letters
  ADD COLUMN IF NOT EXISTS first_activity_at timestamptz;

COMMENT ON COLUMN letters.first_activity_at IS
  'First business-adjusted next-activity time (set once at first assignment). Metric baseline for time-to-resolve.';

COMMIT;
