-- 0005_api_keys.sql
-- Machine access: a non-interactive Power Automate service account that
-- authenticates with a rotatable API key sent as the `X-Api-Key` header.
--
-- Only a SHA-256 hash of each key is stored — the raw key is shown once, at
-- rotation, and never again (the "no secrets in the database" rule). A valid key
-- authenticates AS the service account below; role/permissions then flow from
-- that user exactly as for an interactive session.
--
-- Idempotent: safe to re-run.

BEGIN;

-- ---------------------------------------------------------------------------
-- api_keys — hashed keys, tagged by name, resolving to the service user.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS api_keys (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name         text        NOT NULL,          -- integration tag, e.g. 'Power Automate'
  key_hash     text        NOT NULL,          -- SHA-256 of the raw key
  key_prefix   text        NOT NULL,          -- first chars, safe to display
  scopes       text[]      NOT NULL DEFAULT '{}',
  created_by   uuid REFERENCES users (id) ON DELETE SET NULL,
  created_at   timestamptz NOT NULL DEFAULT now(),
  last_used_at timestamptz,
  revoked_at   timestamptz,
  CONSTRAINT api_keys_hash_ux UNIQUE (key_hash)
);

CREATE INDEX IF NOT EXISTS api_keys_name_active_idx
  ON api_keys (name) WHERE revoked_at IS NULL;

COMMENT ON TABLE api_keys IS 'Hashed machine API keys. Raw key shown once at rotation; only the hash is stored.';

-- ---------------------------------------------------------------------------
-- The Power Automate service account.
-- ---------------------------------------------------------------------------
-- Role 'user' — letter work only, no admin. The password_hash is a non-scrypt
-- sentinel so interactive login can never succeed; this account is reachable
-- only through its API key.
INSERT INTO users (email, full_name, role, auth_provider, password_hash, is_active)
SELECT 'power-automate@bfsfcu.test',
       'Power Automate (Integration)',
       'user',
       'local',
       'x-no-interactive-login',
       true
WHERE NOT EXISTS (
  SELECT 1 FROM users WHERE lower(email) = lower('power-automate@bfsfcu.test')
);

COMMIT;
