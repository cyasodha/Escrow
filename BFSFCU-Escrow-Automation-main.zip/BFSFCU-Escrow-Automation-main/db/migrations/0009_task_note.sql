-- 0009_task_note.sql
-- The "task" attached to a letter's next activity — a short note describing what
-- needs to happen when the letter is next worked. It is set when an Escrow Admin
-- (or a Manager working an escalation) reschedules the next-activity date. It is
-- shown on the letter's Next activity tile as the current task, instead of being
-- appended to the general letter notes.

BEGIN;

ALTER TABLE letters ADD COLUMN IF NOT EXISTS task_note text;

COMMENT ON COLUMN letters.task_note IS
  'Current task for the next activity (what to do when next worked). Set on reschedule; shown on the Next activity tile rather than the notes list.';

COMMIT;
