-- 0007_task_date.sql
-- A working "task date" for each letter. It starts as the received date and an
-- Escrow Admin can move it (reschedule) — every move requires a note. My Tasks
-- sorts by priority (escalated) first, then task date.

BEGIN;

ALTER TABLE letters ADD COLUMN IF NOT EXISTS task_date date;

-- Existing rows: seed the task date from the received (created) date.
UPDATE letters SET task_date = created_at::date WHERE task_date IS NULL;

-- New rows default to today (the day they are received).
ALTER TABLE letters ALTER COLUMN task_date SET DEFAULT CURRENT_DATE;
ALTER TABLE letters ALTER COLUMN task_date SET NOT NULL;

COMMENT ON COLUMN letters.task_date IS
  'Working date for the task; defaults to the received date. An Escrow Admin can move it (a note is required).';

-- Hot path for My Tasks: owner + priority + task date.
CREATE INDEX IF NOT EXISTS letters_assigned_task_idx ON letters (assigned_to, escalated, task_date);

COMMIT;
