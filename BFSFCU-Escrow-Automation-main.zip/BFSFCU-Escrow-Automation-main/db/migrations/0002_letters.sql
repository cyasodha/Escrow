-- 0002_letters.sql
-- Core escrow domain: escrow insurance letters, notes, and the append-only
-- audit log.
--
-- One row per uploaded letter. The 11 fields captured manually today live here
-- alongside the letter type/subtype, the Oracle match result, the
-- compare-to-on-file result, and the High/Low confidence tier.
--
-- Duplicate uploads are allowed (file_hash is NOT unique): re-scanning the same
-- letter produces a new row that the pipeline's duplicate check then flags by
-- policy #/loan #. This mirrors the AP platform's final behaviour.

BEGIN;

-- ---------------------------------------------------------------------------
-- Enums
-- ---------------------------------------------------------------------------
DO $$
BEGIN
  -- Modification vs cancellation. Every letter is one or the other.
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'letter_type') THEN
    CREATE TYPE letter_type AS ENUM ('modification', 'cancellation');
  END IF;

  -- The 3-way checkbox on a cancellation (LA R.S. 22:1266). Metadata only for
  -- now: it is captured so a reviewer can decide whether to escalate, but it
  -- does NOT auto-branch the workflow (payment is on hold).
  --   nonpayment      -> missed-payment (lapse risk)
  --   provider_switch -> written request / replacement bound
  --   non_renewal     -> non-renewal at expiration (underwriting decision)
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'cancellation_subtype') THEN
    CREATE TYPE cancellation_subtype AS ENUM ('nonpayment', 'provider_switch', 'non_renewal');
  END IF;

  -- Status drives every queue.
  --   queued -> processing -> high_confidence | low_confidence
  --   high_confidence | low_confidence | task -> approved | rejected
  --   any (reviewer) -> task            (manual "move to Task/Exception")
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'letter_status') THEN
    CREATE TYPE letter_status AS ENUM (
      'queued',           -- accepted, waiting for the worker
      'processing',       -- worker has picked it up
      'high_confidence',  -- 100% PII + account match — ready for batch approval
      'low_confidence',   -- anything less — needs a human sign-off
      'task',             -- manually moved to the Task/Exception queue by a reviewer
      'approved',
      'rejected'
    );
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'letter_source') THEN
    CREATE TYPE letter_source AS ENUM ('manual_upload', 'email_ingest', 'api_ingest');
  END IF;

  -- The auto-tier decision, retained separately from status so it survives an
  -- approval or a manual move to Task.
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'confidence_tier') THEN
    CREATE TYPE confidence_tier AS ENUM ('high', 'low');
  END IF;

  -- How (or whether) the letter matched an Oracle loan record.
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'match_status') THEN
    CREATE TYPE match_status AS ENUM (
      'matched_by_loan',           -- loan # -> active mortgage + property address
      'matched_by_name_address',   -- fallback: insured name + property address
      'no_match'
    );
  END IF;
END$$;

-- ---------------------------------------------------------------------------
-- Letters
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS letters (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  -- Classification
  letter_type           letter_type,
  cancellation_subtype  cancellation_subtype,          -- only for cancellations
  cancellation_effective_date date,                    -- only for cancellations

  -- The 11 fields captured manually today ------------------------------------
  carrier               text,
  policy_number         text,
  property_address      text,
  insured_name          text,
  loan_number           text,
  dwelling_coverage     numeric(14, 2),
  total_premium         numeric(14, 2),
  policy_period_start   date,
  policy_period_end     date,
  policy_type           text,                          -- e.g. HO-3
  reason                text,

  -- Derived: due date defaults from the policy period start (SOW §5), since the
  -- due date is not one of the 11 fields printed on the letter.
  due_date              date,
  due_date_defaulted    boolean NOT NULL DEFAULT false,
  due_date_default_source text,

  -- Workflow state
  status                letter_status NOT NULL DEFAULT 'queued',
  source                letter_source NOT NULL DEFAULT 'manual_upload',

  -- Oracle match result -------------------------------------------------------
  match_status          match_status,
  matched_loan_number   text,                          -- the Oracle loan matched
  oracle_match_raw      jsonb,                          -- matched loan + insurance-on-file snapshot

  -- Compare-to-on-file result -------------------------------------------------
  -- Field-by-field comparison rows: [{ field, on_file, letter, result }]
  compare_result        jsonb,
  premium_delta         numeric(14, 2),
  premium_delta_pct     numeric(6, 2),
  compare_flags         text[] NOT NULL DEFAULT '{}',

  -- Confidence tiering (High = 100% PII + account match; Low = anything less) -
  confidence_tier       confidence_tier,
  pii_match             boolean,                        -- insured name + property address
  account_match         boolean,                        -- loan # + policy #
  tier_reason           text,

  -- Extraction provenance / diagnostics
  confidence_score      numeric(4, 3),                  -- populated only by stage 2 (OpenAI)
  extraction_flags      text[] NOT NULL DEFAULT '{}',
  extraction_provider   text,
  reasoning_provider    text,
  extraction_raw        jsonb,
  normalization_raw     jsonb,
  processing_error      text,

  -- Storage
  blob_path             text NOT NULL,
  original_filename     text,
  -- SHA-256 of the file. NOT unique — duplicate uploads are allowed and handled
  -- by the pipeline's duplicate check (by policy #/loan #).
  file_hash             text NOT NULL,

  -- Duplicate detection
  duplicate_of          uuid REFERENCES letters (id) ON DELETE SET NULL,
  duplicate_type        text,

  -- Workflow actors
  submitted_by          uuid REFERENCES users (id) ON DELETE SET NULL,
  approved_by           uuid REFERENCES users (id) ON DELETE SET NULL,
  approved_at           timestamptz,
  declined_by           uuid REFERENCES users (id) ON DELETE SET NULL,
  declined_at           timestamptz,
  -- Reviewer's decline reason / return note. (The AP fork learned the hard way
  -- to read this column, not a separate decline_reason column.)
  checker_comment       text,

  created_at            timestamptz NOT NULL DEFAULT now(),
  updated_at            timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS letters_status_idx   ON letters (status, created_at DESC);
CREATE INDEX IF NOT EXISTS letters_loan_idx     ON letters (loan_number);
CREATE INDEX IF NOT EXISTS letters_policy_idx   ON letters (policy_number);
CREATE INDEX IF NOT EXISTS letters_dupe_idx     ON letters (policy_number, loan_number);
CREATE INDEX IF NOT EXISTS letters_created_idx  ON letters (created_at DESC);

COMMENT ON COLUMN letters.cancellation_subtype IS
  'The 3-way LA R.S. 22:1266 checkbox. Metadata for the reviewer — does NOT auto-branch the workflow in this release.';
COMMENT ON COLUMN letters.confidence_tier IS
  'Auto-tier: high = 100% PII (insured name + property address) AND account (loan # + policy #) match after normalization; low = anything less.';
COMMENT ON COLUMN letters.compare_flags IS
  'Non-routing flags shown to the reviewer, e.g. premium_change_gt_5pct. They do NOT auto-route in this release.';

-- ---------------------------------------------------------------------------
-- Notes
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS letter_notes (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  letter_id  uuid NOT NULL REFERENCES letters (id) ON DELETE CASCADE,
  user_id    uuid REFERENCES users (id) ON DELETE SET NULL,
  body       text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS letter_notes_idx ON letter_notes (letter_id, created_at DESC);

-- ---------------------------------------------------------------------------
-- Audit log (append-only)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_logs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entity_type text NOT NULL,
  entity_id   uuid,
  action      text NOT NULL,
  user_id     uuid REFERENCES users (id) ON DELETE SET NULL,
  metadata    jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS audit_entity_idx  ON audit_logs (entity_type, entity_id, created_at DESC);
CREATE INDEX IF NOT EXISTS audit_created_idx ON audit_logs (created_at DESC);

-- Immutable: an audit trail that can be edited is not an audit trail.
CREATE OR REPLACE FUNCTION prevent_audit_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION 'audit_logs is append-only';
END;
$$;

DROP TRIGGER IF EXISTS audit_logs_no_update ON audit_logs;
CREATE TRIGGER audit_logs_no_update
  BEFORE UPDATE OR DELETE ON audit_logs
  FOR EACH ROW EXECUTE FUNCTION prevent_audit_mutation();

-- NOTE: audit_logs grows without bound. Partition by month and set a retention
-- policy before go-live.

-- ---------------------------------------------------------------------------
-- updated_at trigger
-- ---------------------------------------------------------------------------
DROP TRIGGER IF EXISTS letters_set_updated_at ON letters;
CREATE TRIGGER letters_set_updated_at
  BEFORE UPDATE ON letters
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMIT;
