-- 0008_priority.sql
-- Letter PRIORITY (normal | high) — a lightweight triage tag set by a Manager
-- from Team Workload. This is INDEPENDENT of `escalated` (the escrow-admin →
-- manager escalation flow): a letter can be high priority without being
-- escalated, and vice versa.

ALTER TABLE letters
  ADD COLUMN IF NOT EXISTS priority text NOT NULL DEFAULT 'normal';

-- Constrain to the known levels (idempotent).
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'letters_priority_check') THEN
    ALTER TABLE letters ADD CONSTRAINT letters_priority_check CHECK (priority IN ('normal', 'high'));
  END IF;
END$$;

COMMENT ON COLUMN letters.priority IS
  'Triage priority tag (normal|high), set by a Manager in Team Workload. Independent of escalated.';

-- High-priority letters float to the top alongside escalated ones.
CREATE INDEX IF NOT EXISTS letters_priority_idx ON letters (priority) WHERE priority = 'high';
