-- 0015_system_role.sql
-- The Power Automate inbox-pipeline account is a SYSTEM principal, not a user.
--
-- Give it its own role so it (a) never appears in User Management or Team
-- Workload, (b) is never a distribution target, and (c) its API key can reach
-- only the letter-ingest route (Roles.ingest), not the rest of the app. The
-- row itself stays (letters.submitted_by / audit_logs.user_id reference it and
-- attribute ingested letters to it), but it is invisible and unmanageable.
--
-- Idempotent. A newly added enum value cannot be USED in the same transaction
-- that adds it, and apply.ps1 runs each statement in autocommit (no
-- --single-transaction), so this file is intentionally NOT wrapped in BEGIN/COMMIT.

ALTER TYPE app_role ADD VALUE IF NOT EXISTS 'system';

UPDATE users
   SET role = 'system',
       auto_assign_enabled = false,
       updated_at = now()
 WHERE lower(email) = lower('power-automate@bfsfcu.test');
