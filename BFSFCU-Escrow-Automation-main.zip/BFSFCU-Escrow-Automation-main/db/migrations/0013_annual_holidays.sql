-- 0013_annual_holidays.sql
-- Recurring (annual) holidays: fixed-date holidays (Christmas, July 4th, …) fed
-- once and applied every year. When annual = true, only the month/day matters;
-- the stored year is ignored by the business-calendar match.

BEGIN;

ALTER TABLE holidays
  ADD COLUMN IF NOT EXISTS annual boolean NOT NULL DEFAULT false;

COMMENT ON COLUMN holidays.annual IS
  'When true the holiday recurs every year on its month/day (the stored year is ignored).';

COMMIT;
