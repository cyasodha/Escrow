-- 0014_letter_split.sql
-- Multi-letter uploads: classify + auto-split provenance.
--
-- A single uploaded file may contain several insurance letters. A classify stage
-- (Azure Document Intelligence custom classifier, split=auto) splits the file
-- into one PDF per letter; each split letter is its own `letters` row and points
-- back at the original file and the page range it came from.
--
-- Grouping is lightweight (no parent table): every sibling from one upload shares
-- a `batch_id` equal to the first (anchor) letter's id. A letter that was never
-- split keeps these columns NULL.

BEGIN;

ALTER TABLE letters
  ADD COLUMN IF NOT EXISTS batch_id         uuid,
  ADD COLUMN IF NOT EXISTS source_blob_path text,
  ADD COLUMN IF NOT EXISTS source_pages     text,
  ADD COLUMN IF NOT EXISTS split_index      integer,
  ADD COLUMN IF NOT EXISTS split_total      integer,
  ADD COLUMN IF NOT EXISTS doc_type         text;

COMMENT ON COLUMN letters.batch_id IS
  'Groups letters split from one uploaded file; equals the anchor (first) letter''s id. NULL when the file was a single letter.';
COMMENT ON COLUMN letters.source_blob_path IS
  'Blob path of the original multi-letter file this letter was split from. NULL when not split.';
COMMENT ON COLUMN letters.source_pages IS
  'Page range within the original file, e.g. "3-4". NULL when not split.';
COMMENT ON COLUMN letters.split_index IS
  '0-based position of this letter within its batch (0 = anchor).';
COMMENT ON COLUMN letters.split_total IS
  'How many letters the original file was split into.';
COMMENT ON COLUMN letters.doc_type IS
  'Classifier category assigned to this segment (provenance only).';

-- Sibling lookups ("show the other letters from this upload").
CREATE INDEX IF NOT EXISTS letters_batch_id_idx ON letters (batch_id) WHERE batch_id IS NOT NULL;

COMMIT;
