-- 0010_escalated_to.sql
-- The manager an escalation is directed to. The escalator (an Escrow Admin, or a
-- Manager) picks the manager when escalating a letter; the letter then shows in
-- that manager's Escalations queue. Cleared on de-escalation. NULL = unassigned
-- (a legacy escalation, visible to any manager).

BEGIN;

ALTER TABLE letters ADD COLUMN IF NOT EXISTS escalated_to uuid REFERENCES users(id);

COMMENT ON COLUMN letters.escalated_to IS
  'Manager the escalation is directed to (chosen by the escalator). NULL = unassigned.';

-- Hot path for the Escalations queue scoped to a manager.
CREATE INDEX IF NOT EXISTS letters_escalated_to_idx ON letters (escalated_to) WHERE escalated;

COMMIT;
