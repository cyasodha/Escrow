-- 0006_assignment_and_capacity.sql
-- Work distribution model.
--
-- Adds per-user CAPACITY (a relative *weight* for proportional auto-distribution,
-- not a hard cap) and an AUTO-ASSIGN on/off switch, plus per-letter ASSIGNMENT
-- and ESCALATION. Together these turn the flat review queues into:
--   - Escrow Admins (role 'user')  -> a personal "My Tasks" of the letters
--     assigned to them, each flagged action-required or no-action.
--   - Managers (role 'admin')      -> Team Workload (balance the load), the
--     Inbox Monitor (Power-Automate pipeline health), and a "My Tasks" that
--     holds unreadable / exception letters (the old Review bucket).
--
-- Role VALUES are unchanged ('admin', 'user'); only their display labels change
-- in the app (admin = "Manager", user = "Escrow Admin"), so no enum surgery.

BEGIN;

-- ---------------------------------------------------------------------------
-- Capacity weight level
-- ---------------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'capacity_level') THEN
    CREATE TYPE capacity_level AS ENUM ('light', 'regular', 'heavy');
  END IF;
END$$;

-- ---------------------------------------------------------------------------
-- Users: capacity weight + auto-assign switch
-- ---------------------------------------------------------------------------
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS capacity            capacity_level NOT NULL DEFAULT 'regular',
  ADD COLUMN IF NOT EXISTS auto_assign_enabled boolean        NOT NULL DEFAULT true;

COMMENT ON COLUMN users.capacity IS
  'Relative weight for proportional auto-distribution (light:regular:heavy ~= 8:15:25). Not a hard cap.';
COMMENT ON COLUMN users.auto_assign_enabled IS
  'When false the user is skipped by auto-distribution (e.g. out of office). They keep letters already assigned.';

-- ---------------------------------------------------------------------------
-- Letters: assignment + escalation
-- ---------------------------------------------------------------------------
ALTER TABLE letters
  ADD COLUMN IF NOT EXISTS assigned_to  uuid REFERENCES users (id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS assigned_at  timestamptz,
  ADD COLUMN IF NOT EXISTS assigned_by  uuid REFERENCES users (id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS escalated    boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS escalated_at timestamptz,
  ADD COLUMN IF NOT EXISTS escalated_by uuid REFERENCES users (id) ON DELETE SET NULL;

COMMENT ON COLUMN letters.assigned_to IS
  'The user who owns this letter. Escrow Admins see only letters assigned to them; exceptions are assigned to a Manager.';
COMMENT ON COLUMN letters.escalated IS
  'A Manager flag that pins the letter to the top of the owner''s My Tasks as priority.';

-- Owner + status is the hot path for "My Tasks" and Team Workload aggregates.
CREATE INDEX IF NOT EXISTS letters_assigned_idx  ON letters (assigned_to, status);
-- Inbox Monitor lists ingested (non-manual) letters by recency.
CREATE INDEX IF NOT EXISTS letters_source_idx    ON letters (source, created_at DESC);
CREATE INDEX IF NOT EXISTS letters_escalated_idx ON letters (escalated) WHERE escalated;

-- ---------------------------------------------------------------------------
-- Seed Escrow Admins for the demo (idempotent).
-- All use the same password as the seeded admin: Escrow@review
-- (reusing the scrypt hash generated with shared/password.ts parameters).
-- Names mirror the Team Workload mockup.
-- ---------------------------------------------------------------------------
INSERT INTO users (email, full_name, role, auth_provider, password_hash, is_active, capacity, auto_assign_enabled)
VALUES
  ('dfontenot@bfsfcu.test',  'Danielle Fontenot',  'user', 'local',
   'scrypt$16384$8$1$3498742ad04f4f8aa5198e1533132cd9$19a64c4941a690e39eb64810a586141ee914b425630a0f8744b55483b4f433fa8374b68bb431e99d987bee54d92855bf49a416da33d16b3dfe444931477f7aa8',
   true, 'heavy',   true),
  ('karceneaux@bfsfcu.test', 'Kevin Arceneaux',    'user', 'local',
   'scrypt$16384$8$1$3498742ad04f4f8aa5198e1533132cd9$19a64c4941a690e39eb64810a586141ee914b425630a0f8744b55483b4f433fa8374b68bb431e99d987bee54d92855bf49a416da33d16b3dfe444931477f7aa8',
   true, 'regular', true),
  ('mprejean@bfsfcu.test',   'Monique Prejean',    'user', 'local',
   'scrypt$16384$8$1$3498742ad04f4f8aa5198e1533132cd9$19a64c4941a690e39eb64810a586141ee914b425630a0f8744b55483b4f433fa8374b68bb431e99d987bee54d92855bf49a416da33d16b3dfe444931477f7aa8',
   true, 'heavy',   true),
  ('jhebert@bfsfcu.test',    'Jacques Hebert',     'user', 'local',
   'scrypt$16384$8$1$3498742ad04f4f8aa5198e1533132cd9$19a64c4941a690e39eb64810a586141ee914b425630a0f8744b55483b4f433fa8374b68bb431e99d987bee54d92855bf49a416da33d16b3dfe444931477f7aa8',
   true, 'light',   false)   -- auto-assign OFF (out of office) to demo the toggle
ON CONFLICT (lower(email)) WHERE email IS NOT NULL DO NOTHING;

-- The Power Automate machine account is role 'user' but is never a distribution
-- target and never appears in Team Workload — it only ingests letters.
UPDATE users SET auto_assign_enabled = false
 WHERE lower(email) = lower('power-automate@bfsfcu.test');

COMMIT;
