-- 0003_app_settings.sql
-- Single-row application settings: Microsoft Entra SSO + the Oracle loan-lookup
-- connection.
--
-- NON-SECRET configuration only. Entra uses a public client (auth-code + PKCE),
-- so there is no client secret to store. The Oracle PASSWORD is NOT stored here
-- either — it is read from ORACLE_PASSWORD (Key Vault / Function App settings)
-- in shared/config.ts. Everything in this table is safe to keep in the database
-- and to edit from the admin UI.

BEGIN;

-- Single-row table: the CHECK (id = true) + PK makes exactly one row possible.
CREATE TABLE IF NOT EXISTS app_settings (
  id                boolean PRIMARY KEY DEFAULT true CHECK (id = true),

  -- Microsoft Entra (Azure AD) SSO -------------------------------------------
  entra_enabled     boolean NOT NULL DEFAULT false,
  entra_tenant_id   text,
  entra_client_id   text,

  -- Oracle loan-lookup connection (read-only). Password lives in Key Vault. ---
  oracle_enabled       boolean NOT NULL DEFAULT false,
  oracle_host          text,
  oracle_port          integer NOT NULL DEFAULT 1521,
  oracle_service_name  text,
  oracle_user          text,

  updated_at        timestamptz NOT NULL DEFAULT now()
);

-- Guarantee the single row exists so UPDATE ... WHERE id = true always hits it.
INSERT INTO app_settings (id) VALUES (true)
ON CONFLICT (id) DO NOTHING;

COMMENT ON TABLE  app_settings IS
  'Single-row, non-secret application settings (Entra SSO + Oracle connection). No secret is ever stored here.';
COMMENT ON COLUMN app_settings.entra_enabled IS
  'When true (and tenant/client are set), the login page offers Microsoft Entra SSO.';
COMMENT ON COLUMN app_settings.oracle_enabled IS
  'When true (and host/service/user are set), the pipeline performs live Oracle loan lookups.';
COMMENT ON COLUMN app_settings.oracle_user IS
  'Oracle read-only account username. The matching password is read from ORACLE_PASSWORD (Key Vault), never stored here.';

DROP TRIGGER IF EXISTS app_settings_set_updated_at ON app_settings;
CREATE TRIGGER app_settings_set_updated_at
  BEFORE UPDATE ON app_settings
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

COMMIT;
