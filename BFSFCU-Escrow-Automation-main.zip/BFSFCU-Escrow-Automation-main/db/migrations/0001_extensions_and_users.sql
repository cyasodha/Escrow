-- 0001_extensions_and_users.sql
-- Baseline for the Azure Postgres application database.
--
-- Single-tenant: there is no tenant_id anywhere in this schema.
--
-- Authentication is local email/password (scrypt hash + HS256 session cookie),
-- with Microsoft Entra SSO as an optional second identity source on the
-- auth_provider / external_id seam (see 0003_app_settings.sql and shared/entra.ts).
-- Two roles only: admin and user.

BEGIN;

-- ---------------------------------------------------------------------------
-- Extensions
-- ---------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS pg_trgm;    -- carrier / name similarity matching

-- ---------------------------------------------------------------------------
-- Roles
-- ---------------------------------------------------------------------------
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'app_role') THEN
    CREATE TYPE app_role AS ENUM ('admin', 'user');
  END IF;
END$$;

-- ---------------------------------------------------------------------------
-- Users
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),

  email         text,
  full_name     text,
  role          app_role NOT NULL DEFAULT 'user',

  -- Identity source: 'local' (password) or an SSO provider name.
  auth_provider text     NOT NULL DEFAULT 'local',
  -- SSO subject / Entra object id, when auth_provider is not local. Nullable.
  external_id   text,
  -- scrypt hash for local auth. Null for SSO-only users.
  password_hash text,

  -- Deactivate without deleting, so audit history keeps referential integrity.
  is_active     boolean  NOT NULL DEFAULT true,

  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- Email is the login identifier and must be unique (case-insensitive) for
-- users that have one.
CREATE UNIQUE INDEX IF NOT EXISTS users_email_lower_ux
  ON users (lower(email)) WHERE email IS NOT NULL;

-- Lookup by external_id (the Entra object id) at SSO login.
CREATE INDEX IF NOT EXISTS users_external_id_idx
  ON users (external_id) WHERE external_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS users_role_idx ON users (role) WHERE is_active;

COMMENT ON TABLE  users               IS 'Application users. Local password auth + optional Entra SSO; this table holds profile and role.';
COMMENT ON COLUMN users.auth_provider IS 'Identity source: local (password) or an SSO provider name.';
COMMENT ON COLUMN users.external_id   IS 'SSO subject / Entra object id, when auth_provider is not local. Nullable.';
COMMENT ON COLUMN users.password_hash IS 'scrypt hash for local auth. Null for SSO users.';
COMMENT ON COLUMN users.is_active     IS 'Soft deactivation. Inactive users are rejected at the API boundary.';

-- ---------------------------------------------------------------------------
-- updated_at maintenance
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS users_set_updated_at ON users;
CREATE TRIGGER users_set_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION set_updated_at();

-- ---------------------------------------------------------------------------
-- Seed the default administrator
-- ---------------------------------------------------------------------------
-- admin@bfsfcu.test / Escrow@review
-- The hash below is scrypt$N$r$p$saltHex$hashHex for that password, generated
-- with the same parameters shared/password.ts uses. CHANGE THE PASSWORD after
-- first sign-in (or before any real deployment).

INSERT INTO users (email, full_name, role, auth_provider, password_hash, is_active)
VALUES (
  'admin@bfsfcu.test',
  'Escrow Administrator',
  'admin',
  'local',
  'scrypt$16384$8$1$3498742ad04f4f8aa5198e1533132cd9$19a64c4941a690e39eb64810a586141ee914b425630a0f8744b55483b4f433fa8374b68bb431e99d987bee54d92855bf49a416da33d16b3dfe444931477f7aa8',
  true
)
ON CONFLICT (lower(email)) WHERE email IS NOT NULL DO NOTHING;

COMMIT;
