# apply.ps1 — apply all app-database migrations in order.
# Usage:  ./db/apply.ps1   (uses local Docker Postgres defaults unless PG* env vars are set)

$ErrorActionPreference = "Stop"

if (-not $env:PGHOST)     { $env:PGHOST = "127.0.0.1" }
if (-not $env:PGUSER)     { $env:PGUSER = "postgres" }
if (-not $env:PGPASSWORD) { $env:PGPASSWORD = "postgres" }
if (-not $env:PGDATABASE) { $env:PGDATABASE = "bfsfcu_escrow" }

# psql is usually here and not on PATH.
$psql = "psql"
if (-not (Get-Command $psql -ErrorAction SilentlyContinue)) {
  $psql = "C:\Program Files\PostgreSQL\17\bin\psql.exe"
  if (-not (Test-Path $psql)) { $psql = "C:\Program Files\PostgreSQL\16\bin\psql.exe" }
}

$dir = Join-Path $PSScriptRoot "migrations"
Get-ChildItem $dir -Filter *.sql | Sort-Object Name | ForEach-Object {
  Write-Host ">> $($_.Name)" -ForegroundColor Cyan
  & $psql -v ON_ERROR_STOP=1 -f $_.FullName
  if ($LASTEXITCODE -ne 0) { throw "Migration failed: $($_.Name)" }
}
Write-Host "All migrations applied to $($env:PGDATABASE)." -ForegroundColor Green
