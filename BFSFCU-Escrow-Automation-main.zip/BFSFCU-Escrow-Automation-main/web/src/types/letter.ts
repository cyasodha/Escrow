/** Shared types for the escrow web app. Mirrors the API's letter row shape. */

export type AppRole = "admin" | "user";

export type LetterStatus =
  | "queued"
  | "processing"
  | "high_confidence"
  | "low_confidence"
  | "task"
  | "approved"
  | "rejected";

export type LetterType = "modification" | "cancellation";
export type CancellationSubtype = "nonpayment" | "provider_switch" | "non_renewal";
export type MatchStatus = "matched_by_loan" | "matched_by_name_address" | "no_match";
export type ConfidenceTier = "high" | "low";
export type LetterSource = "manual_upload" | "email_ingest" | "api_ingest";

/** Relative capacity weight for auto-distribution (not a hard cap). */
export type Capacity = "light" | "regular" | "heavy";

/** One row of the comparison table (letter vs insurance on file). */
export interface CompareRow {
  field: string;
  onFile: string | null;
  letter: string | null;
  result: "match" | "changed" | "new" | "missing";
}

/** Snapshot of the matched Oracle loan + insurance on file. */
export interface OracleMatchRaw {
  matchStatus: MatchStatus;
  oracleAvailable: boolean;
  note: string | null;
  loan: {
    loanNumber: string;
    memberName: string;
    propertyAddress: string;
    mortgageStatus: string;
    escrowBalance: number;
  } | null;
  insuranceOnFile: {
    loanNumber: string;
    carrier: string;
    policyNumber: string;
    policyType: string | null;
    dwellingCoverage: number | null;
    premium: number | null;
    periodStart: string | null;
    periodEnd: string | null;
  } | null;
}

/** A letter as returned by GET /api/letters and /api/letters/{id}. */
export interface Letter {
  id: string;
  letter_type: LetterType | null;
  cancellation_subtype: CancellationSubtype | null;
  cancellation_effective_date: string | null;

  carrier: string | null;
  policy_number: string | null;
  property_address: string | null;
  insured_name: string | null;
  loan_number: string | null;
  dwelling_coverage: string | null;
  total_premium: string | null;
  policy_period_start: string | null;
  policy_period_end: string | null;
  policy_type: string | null;
  reason: string | null;

  due_date: string | null;
  due_date_defaulted: boolean;
  due_date_default_source: string | null;

  status: LetterStatus;
  source: string;

  match_status: MatchStatus | null;
  matched_loan_number: string | null;
  oracle_match_raw: OracleMatchRaw | null;

  compare_result: CompareRow[] | null;
  premium_delta: string | null;
  premium_delta_pct: string | null;
  compare_flags: string[];

  confidence_tier: ConfidenceTier | null;
  pii_match: boolean | null;
  account_match: boolean | null;
  tier_reason: string | null;

  confidence_score: string | null;
  extraction_flags: string[];
  extraction_provider: string | null;
  reasoning_provider: string | null;
  processing_error: string | null;

  original_filename: string | null;
  duplicate_of: string | null;
  duplicate_type: string | null;

  submitted_by: string | null;
  approved_by: string | null;
  approved_at: string | null;
  declined_by: string | null;
  declined_at: string | null;
  checker_comment: string | null;

  assigned_to: string | null;
  assigned_to_name: string | null;
  assigned_at: string | null;
  escalated: boolean;
  escalated_at: string | null;
  escalated_to: string | null;
  escalated_to_name: string | null;
  priority: "normal" | "high";
  task_date: string | null;
  task_note: string | null;

  /** Multi-letter split provenance (null when the file was a single letter). */
  batch_id: string | null;
  source_pages: string | null;
  split_index: number | null;
  split_total: number | null;
  doc_type: string | null;

  created_at: string;
  updated_at: string;
}

/** A manager (role 'admin') — the escalate "assign to" picker. */
export interface Manager {
  id: string;
  fullName: string | null;
  email: string | null;
}

export interface StatusCounts {
  queued: number;
  processing: number;
  high_confidence: number;
  low_confidence: number;
  task: number;
  approved: number;
  rejected: number;
  total: number;
}

export interface AppUserRow {
  id: string;
  email: string | null;
  fullName: string | null;
  role: AppRole;
  isActive: boolean;
  authProvider: string;
  capacity: Capacity;
  autoAssignEnabled: boolean;
}

/** Role-appropriate sidebar counts (GET /api/nav-counts). */
export interface NavCounts {
  role: "manager" | "escrow_admin";
  myTasks?: number;
  accepted?: number;
  declined?: number;
  teamOpen?: number;
  escalations?: number;
  inbox?: number;
}

/** One row of the Team Workload screen. */
export interface TeamMember {
  id: string;
  fullName: string | null;
  email: string | null;
  capacity: Capacity;
  weight: number;
  autoAssignEnabled: boolean;
  /** Nightly Graph sync result: out for the next working day. */
  oooAuto: boolean;
  /** "Is out" per the nightly sync — excluded from auto-assign. */
  effectiveOut: boolean;
  openCount: number;
  urgentCount: number;
  escalatedCount: number;
  noActionCount: number;
  actionCount: number;
  fairShare: number;
}

export interface TeamWorkload {
  members: TeamMember[];
  totalOpen: number;
  weights: Record<Capacity, number>;
}

/** Task-timing metrics for the Metrics page (Manager). */
export interface TaskMetrics {
  meanTimeToCloseSeconds: number | null;
  closedTotal: number;
  trend: {
    month: string;
    meanSeconds: number | null;
    teamMeanSeconds: number | null;
    closed: number;
    openBacklog: number;
  }[];
  ranking: { adminId: string; name: string; meanSeconds: number | null }[];
  topOpen: {
    id: string;
    insuredName: string | null;
    policyNumber: string | null;
    adminId: string | null;
    assignedToName: string | null;
    openSeconds: number;
    createdAt: string;
  }[];
}

/** Inbox Monitor health tiles. */
export interface InboxTiles {
  processing: number;
  stuck: number;
  failed: number;
  inReview: number;
  resolved: number;
  total: number;
}

export interface AuditEntry {
  id: string;
  entity_type: string;
  entity_id: string | null;
  action: string;
  actor_name: string | null;
  metadata: Record<string, unknown>;
  created_at: string;
}

export interface NoteEntry {
  id: string;
  letter_id: string;
  author_name: string | null;
  body: string;
  created_at: string;
}
