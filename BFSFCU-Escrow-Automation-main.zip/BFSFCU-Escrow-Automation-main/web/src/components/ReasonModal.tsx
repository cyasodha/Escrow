import { useEffect, useState } from "react";
import { AlertTriangle, X } from "lucide-react";

interface SelectField {
  label: string;
  placeholder?: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (value: string) => void;
  required?: boolean;
}

interface Props {
  open: boolean;
  title: string;
  description?: string;
  confirmLabel: string;
  confirmTone?: "primary" | "success" | "destructive";
  placeholder?: string;
  busy?: boolean;
  error?: string | null;
  /** Optional dropdown shown above the note (e.g. choose a manager to escalate to). */
  select?: SelectField;
  onConfirm: (note: string) => void;
  onCancel: () => void;
}

const TONE_CLASS: Record<string, string> = {
  primary: "btn-primary",
  success: "btn-success",
  destructive: "btn-destructive-outline",
};

/**
 * A small modal that requires a note before confirming an action (e.g.
 * escalate / de-escalate). Confirm is disabled until the note has ≥ 3 chars.
 */
export default function ReasonModal({
  open,
  title,
  description,
  confirmLabel,
  confirmTone = "primary",
  placeholder = "Add a note (required)…",
  busy = false,
  error = null,
  select,
  onConfirm,
  onCancel,
}: Props) {
  const [note, setNote] = useState("");

  // Reset the note each time the modal is (re)opened.
  useEffect(() => {
    if (open) setNote("");
  }, [open]);

  if (!open) return null;

  const selectOk = !select?.required || !!select.value;
  const valid = note.trim().length >= 3 && selectOk;

  return (
    <div className="modal-overlay" onClick={() => !busy && onCancel()}>
      <div className="modal" style={{ maxWidth: 460 }} onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2 className="card-title">{title}</h2>
          <button className="modal-close" onClick={() => !busy && onCancel()} aria-label="Close">
            <X style={{ width: 15, height: 15 }} />
          </button>
        </div>
        <div className="modal-body">
          {description && (
            <p style={{ fontSize: ".85rem", marginTop: 0, color: "var(--muted-foreground)" }}>{description}</p>
          )}
          {select && (
            <div className="field-group" style={{ marginBottom: ".7rem" }}>
              <label>{select.label}</label>
              <select
                className="select"
                value={select.value}
                onChange={(e) => select.onChange(e.target.value)}
              >
                <option value="">{select.placeholder ?? "Select…"}</option>
                {select.options.map((o) => (
                  <option key={o.value} value={o.value}>{o.label}</option>
                ))}
              </select>
            </div>
          )}
          <textarea
            className="textarea"
            rows={3}
            autoFocus
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={placeholder}
          />
          {error && (
            <div className="banner error" style={{ marginTop: ".6rem" }}>
              <AlertTriangle className="ic" />
              {error}
            </div>
          )}
          <div className="row" style={{ justifyContent: "flex-end", marginTop: "1rem" }}>
            <button className="btn btn-ghost" onClick={onCancel} disabled={busy}>
              Cancel
            </button>
            <button
              className={`btn ${TONE_CLASS[confirmTone]}`}
              onClick={() => valid && onConfirm(note.trim())}
              disabled={busy || !valid}
            >
              {busy ? "Working…" : confirmLabel}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
