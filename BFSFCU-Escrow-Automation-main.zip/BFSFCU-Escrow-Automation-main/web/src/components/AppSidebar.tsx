import { useState } from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  BarChart3,
  CheckCheck,
  XCircle,
  Upload,
  Inbox,
  UserCog,
  Database,
  Cable,
  CalendarClock,
  Trash2,
  AlertTriangle,
  X,
} from "lucide-react";
import type { NavCounts } from "@/types/letter";
import { useAuth } from "@/hooks/useAuth";
import { demoApi } from "@/services";

interface Props {
  counts: NavCounts | null;
  demoEnabled: boolean;
}

function badge(n: number | undefined): string | undefined {
  return n ? String(n) : undefined;
}

export default function AppSidebar({ counts, demoEnabled }: Props) {
  const { isManager } = useAuth();

  const item = (to: string, Icon: typeof LayoutDashboard, label: string, count?: string) => (
    <NavLink to={to} className={({ isActive }) => `nav-link${isActive ? " active" : ""}`}>
      <Icon className="ic" />
      <span>{label}</span>
      {count ? <span className="nav-count">{count}</span> : null}
    </NavLink>
  );

  return (
    <aside className="sidebar">
      <div className="sidebar-nav">
        <div className="nav-group">
          <span className="nav-label">Overview</span>
          {item("/tasks", LayoutDashboard, "Tasks")}
          {isManager && item("/metrics", BarChart3, "Metrics")}
        </div>

        {isManager ? (
          <>
            <div className="nav-group">
              <span className="nav-label">Action History</span>
              {item("/accepted", CheckCheck, "Accepted", badge(counts?.accepted))}
              {item("/declined", XCircle, "Declined", badge(counts?.declined))}
            </div>
            <div className="nav-group">
              <span className="nav-label">Intake</span>
              {item("/upload", Upload, "Upload Letters")}
            </div>
            <div className="nav-group">
              <span className="nav-label">Management</span>
              {item("/inbox", Inbox, "Inbox Monitor", badge(counts?.inbox))}
              {item("/user-management", UserCog, "User Management")}
              {item("/scheduling", CalendarClock, "Scheduling")}
              {item("/connections", Cable, "Connections")}
            </div>
          </>
        ) : (
          <>
            <div className="nav-group">
              <span className="nav-label">Action History</span>
              {item("/accepted", CheckCheck, "Accepted", badge(counts?.accepted))}
              {item("/declined", XCircle, "Declined", badge(counts?.declined))}
            </div>
            <div className="nav-group">
              <span className="nav-label">Intake</span>
              {item("/upload", Upload, "Upload Letters")}
            </div>
          </>
        )}
      </div>

      {demoEnabled && isManager && (
        <div className="sidebar-footer">
          <DemoReset />
        </div>
      )}
    </aside>
  );
}

function DemoReset() {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const reset = async () => {
    setBusy(true);
    setError(null);
    try {
      await demoApi.reset();
      window.location.assign("/tasks");
    } catch (err) {
      setBusy(false);
      setError(err instanceof Error ? err.message : "Reset failed");
    }
  };

  return (
    <>
      <button className="reset-btn" onClick={() => setOpen(true)}>
        <Database className="ic" />
        <span>Reset Demo Data</span>
      </button>

      {open && (
        <div className="modal-overlay" onClick={() => !busy && setOpen(false)}>
          <div className="modal" style={{ maxWidth: 460 }} onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2 className="card-title">
                <Trash2 style={{ width: 16, height: 16, color: "var(--destructive)" }} /> Reset the demo database?
              </h2>
              <button className="modal-close" onClick={() => !busy && setOpen(false)} aria-label="Close">
                <X style={{ width: 15, height: 15 }} />
              </button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: ".88rem", marginTop: 0 }}>
                This permanently deletes <strong>all letters, notes, and the audit trail</strong> so you can start a
                fresh demo. User accounts, SSO/Oracle settings, and the Power Automate key are kept. The Oracle
                sample data is a separate database and is not affected.
              </p>
              {error && (
                <div className="banner error">
                  <AlertTriangle className="ic" />
                  {error}
                </div>
              )}
              <div className="row" style={{ justifyContent: "flex-end", marginTop: "1rem" }}>
                <button className="btn btn-ghost" onClick={() => setOpen(false)} disabled={busy}>
                  Cancel
                </button>
                <button className="btn btn-destructive-outline" onClick={reset} disabled={busy}>
                  <Trash2 className="ic" /> {busy ? "Resetting…" : "Delete all data"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
