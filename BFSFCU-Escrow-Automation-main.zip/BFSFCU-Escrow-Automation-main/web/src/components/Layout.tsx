import { useEffect, useState, useCallback } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import { LogOut, Shield, Menu } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { roleLabel } from "@/lib/roles";
import { lettersApi, demoApi } from "@/services";
import type { NavCounts } from "@/types/letter";
import AppSidebar from "./AppSidebar";

export default function Layout() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [counts, setCounts] = useState<NavCounts | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [demoEnabled, setDemoEnabled] = useState(false);

  useEffect(() => {
    demoApi.config().then((c) => setDemoEnabled(c.enabled)).catch(() => setDemoEnabled(false));
  }, []);

  const refresh = useCallback(() => {
    lettersApi.navCounts().then(setCounts).catch(() => {
      /* keep last known counts on a transient failure */
    });
  }, []);

  useEffect(() => {
    refresh();
    const t = setInterval(refresh, 15_000);
    return () => clearInterval(t);
  }, [refresh]);

  const handleSignOut = async () => {
    await signOut();
    navigate("/login");
  };

  return (
    <>
      <div className="topbar">
        <div className="topbar-left">
          <button className="menu-btn" title="Toggle sidebar" onClick={() => setSidebarOpen((v) => !v)}>
            <Menu style={{ width: 18, height: 18 }} />
          </button>
          <img
            className="header-logo"
            src="/bfsfcu-logo.svg"
            alt="Bank Fund Credit Union"
            onClick={() => navigate("/tasks")}
          />
        </div>
        <div className="topbar-right">
          <span className="role-badge">
            <Shield style={{ width: 14, height: 14 }} />
            {roleLabel(user?.role)}
          </span>
          <span className="user-email">{user?.email}</span>
          <button className="btn-signout" onClick={handleSignOut}>
            <LogOut style={{ width: 14, height: 14 }} />
            Sign Out
          </button>
        </div>
      </div>

      <div className={`shell${sidebarOpen ? "" : " sidebar-hidden"}`}>
        <AppSidebar counts={counts} demoEnabled={demoEnabled} />
        <main className="content">
          <Outlet context={{ refreshCounts: refresh }} />
        </main>
      </div>
    </>
  );
}
