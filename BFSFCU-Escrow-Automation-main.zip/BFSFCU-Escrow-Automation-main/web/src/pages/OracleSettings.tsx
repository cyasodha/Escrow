import { useEffect, useState } from "react";
import { Database, CheckCircle2, AlertTriangle } from "lucide-react";
import { settingsApi, type OracleConfig } from "@/services";

export default function OracleSettings({ embedded = false }: { embedded?: boolean }) {
  const [cfg, setCfg] = useState<OracleConfig>({
    enabled: false,
    host: "",
    port: 1521,
    serviceName: "",
    user: "",
    passwordConfigured: false,
  });
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    settingsApi.getOracle().then(setCfg).catch(() => undefined);
  }, []);

  const save = async () => {
    setError(null);
    setSaved(false);
    setTestResult(null);
    try {
      const updated = await settingsApi.putOracle({
        enabled: cfg.enabled,
        host: cfg.host?.trim() || null,
        port: Number(cfg.port) || 1521,
        serviceName: cfg.serviceName?.trim() || null,
        user: cfg.user?.trim() || null,
        ...(password.trim() ? { password } : {}),
      });
      setCfg(updated);
      setPassword(""); // never keep the secret in component state after saving
      setSaved(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save");
    }
  };

  const test = async () => {
    setTesting(true);
    setTestResult(null);
    setError(null);
    try {
      const r = await settingsApi.testOracle();
      setTestResult(`Connected — ${r.loanCount} loan record(s) readable.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Connection test failed");
    } finally {
      setTesting(false);
    }
  };

  return (
    <>
      {!embedded && (
        <h1 className="page-title">
          <Database style={{ width: 24, height: 24 }} /> Oracle Connection
        </h1>
      )}
      <p className="page-sub">
        Read-only connector for loan lookup and insurance-on-file. The password is set via Key Vault
        (<code>ORACLE_PASSWORD</code>), never stored here.
      </p>

      <div className="card" style={{ maxWidth: 720 }}>
        <div className="card-content">
          {error && <div className="banner error"><AlertTriangle className="ic" />{error}</div>}
          {saved && <div className="banner info"><CheckCircle2 className="ic" />Saved.</div>}
          {testResult && <div className="banner info"><CheckCircle2 className="ic" />{testResult}</div>}

          <label className="row" style={{ marginBottom: ".8rem", cursor: "pointer" }}>
            <input
              className="checkbox"
              type="checkbox"
              checked={cfg.enabled}
              onChange={(e) => setCfg({ ...cfg, enabled: e.target.checked })}
            />
            Enable live Oracle loan lookups
          </label>

          <div className="grid grid-2">
            <div className="field-group">
              <label>Host</label>
              <input className="input" value={cfg.host ?? ""} onChange={(e) => setCfg({ ...cfg, host: e.target.value })} placeholder="oracle.internal" />
            </div>
            <div className="field-group">
              <label>Port</label>
              <input className="input" type="number" value={cfg.port} onChange={(e) => setCfg({ ...cfg, port: Number(e.target.value) })} />
            </div>
            <div className="field-group">
              <label>Service name</label>
              <input className="input" value={cfg.serviceName ?? ""} onChange={(e) => setCfg({ ...cfg, serviceName: e.target.value })} placeholder="XEPDB1" />
            </div>
            <div className="field-group">
              <label>User (read-only account)</label>
              <input className="input" value={cfg.user ?? ""} onChange={(e) => setCfg({ ...cfg, user: e.target.value })} placeholder="ESCROW_RO" />
            </div>
            <div className="field-group">
              <label>Password</label>
              <input
                className="input"
                type="password"
                value={password}
                autoComplete="new-password"
                onChange={(e) => setPassword(e.target.value)}
                placeholder={cfg.passwordConfigured ? "•••••••• (leave blank to keep current)" : "Enter the account password"}
              />
            </div>
          </div>

          <div className="banner" style={{ background: cfg.passwordConfigured ? "hsl(142 76% 36% / .08)" : "hsl(25 95% 53% / .08)", borderColor: cfg.passwordConfigured ? "hsl(142 76% 36% / .3)" : "hsl(25 95% 53% / .35)", color: cfg.passwordConfigured ? "hsl(142 40% 30%)" : "hsl(25 70% 30%)" }}>
            {cfg.passwordConfigured ? <CheckCircle2 className="ic" style={{ color: "var(--success)" }} /> : <AlertTriangle className="ic" />}
            {cfg.passwordConfigured
              ? "A connection password is configured (entered here, or via ORACLE_PASSWORD)."
              : "No password set — enter one above (or set ORACLE_PASSWORD) before the connector can authenticate."}
          </div>

          <div className="row">
            <button className="btn btn-primary" onClick={save}>Save connection</button>
            <button className="btn btn-outline" onClick={test} disabled={testing}>
              {testing ? "Testing…" : "Test connection"}
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
