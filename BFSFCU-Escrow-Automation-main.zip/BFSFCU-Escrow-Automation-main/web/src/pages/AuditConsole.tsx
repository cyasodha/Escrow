import { useCallback, useEffect, useState } from "react";
import { ScrollText, Search, X, FileText } from "lucide-react";
import { lettersApi } from "@/services";
import type { Letter, AuditEntry, LetterStatus } from "@/types/letter";
import { statusLabel, auditStatusLabel, statusBadgeClass, letterTypeLabel, matchStatusLabel, reviewFlag } from "@/lib/letterStatus";
import { date, dateTime, text, money } from "@/lib/format";

const STATUS_OPTIONS: { value: "" | LetterStatus; label: string }[] = [
  { value: "", label: "All statuses" },
  { value: "high_confidence", label: "No Action Required" },
  { value: "low_confidence", label: "In Review" },
  { value: "task", label: "Action Required" },
  { value: "approved", label: "Accepted" },
  { value: "rejected", label: "Declined" },
];

/** Map an audit action to a label + badge style. */
function actionBadge(a: AuditEntry): { label: string; cls: string } {
  const m = a.metadata ?? {};
  switch (a.action) {
    case "uploaded":
      return { label: "Uploaded", cls: "badge-success" };
    case "processed": {
      // Show the review category the letter was routed into (No action required /
      // In review / Action required), not the internal confidence tier.
      const routed = (m["status"] as LetterStatus) ?? "low_confidence";
      const flag = reviewFlag({ status: routed });
      return {
        label: `Routed to ${flag?.label ?? auditStatusLabel(routed)}`,
        cls: "badge-accent",
      };
    }
    case "approved":
      return { label: "Accepted", cls: "badge-success" };
    case "declined":
      return { label: "Declined", cls: "badge-destructive" };
    case "moved_to_task":
      return { label: "Moved to Action Required", cls: "badge-navy" };
    case "returned_to_review":
      return { label: "Returned to Review", cls: "badge-outline" };
    case "note_added":
      return { label: "Note added", cls: "badge-muted" };
    default:
      return { label: a.action.replace(/_/g, " "), cls: "badge-muted" };
  }
}

/** A one-line detail drawn from the audit metadata. */
function actionDetail(a: AuditEntry): string | null {
  const m = a.metadata ?? {};
  switch (a.action) {
    case "uploaded":
      return typeof m["filename"] === "string" ? m["filename"] : null;
    case "processed": {
      const parts: string[] = [];
      if (m["tier"]) parts.push(`Tier: ${String(m["tier"]).toUpperCase() === "HIGH" ? "High" : "Low"}`);
      if (m["matchStatus"]) parts.push(matchStatusLabel(String(m["matchStatus"])));
      const flags = Array.isArray(m["compareFlags"]) ? (m["compareFlags"] as string[]) : [];
      if (flags.length) parts.push(`${flags.length} compare flag${flags.length > 1 ? "s" : ""}`);
      return parts.join(" · ") || null;
    }
    case "approved":
      return (m["self_approved"] ? "Self-approved. " : "") + (typeof m["note"] === "string" ? m["note"] : "") || null;
    case "declined":
      return typeof m["reason"] === "string" ? m["reason"] : null;
    case "moved_to_task":
      return typeof m["reason"] === "string" ? m["reason"] : null;
    case "returned_to_review":
      return `To ${statusLabel((m["to"] as LetterStatus) ?? "low_confidence")}${m["reason"] ? ` — ${m["reason"]}` : ""}`;
    default:
      return null;
  }
}

export default function AuditConsole() {
  const [letters, setLetters] = useState<Letter[]>([]);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<"" | LetterStatus>("");
  const [loaded, setLoaded] = useState(false);

  const [selected, setSelected] = useState<Letter | null>(null);
  const [entries, setEntries] = useState<AuditEntry[]>([]);
  const [entriesLoading, setEntriesLoading] = useState(false);

  const load = useCallback(() => {
    lettersApi
      .list({ ...(status ? { status } : {}), ...(search.trim() ? { search: search.trim() } : {}), limit: 200 })
      .then((r) => {
        setLetters(r.letters);
        setLoaded(true);
      })
      .catch(() => undefined);
  }, [search, status]);

  useEffect(() => {
    load();
  }, [load]);

  const open = (l: Letter) => {
    setSelected(l);
    setEntries([]);
    setEntriesLoading(true);
    lettersApi
      .audit(l.id)
      .then((r) => setEntries(r.entries))
      .catch(() => undefined)
      .finally(() => setEntriesLoading(false));
  };

  return (
    <>
      <h1 className="page-title">
        <ScrollText style={{ width: 24, height: 24 }} /> Audit Trail
      </h1>
      <p className="page-sub">
        Select a letter to see who uploaded it, how it was tiered, who reviewed it, and every action taken.
        The trail is append-only and cannot be edited.
      </p>

      <div className="toolbar">
        <div className="search-wrap">
          <Search className="ic" />
          <input
            className="input"
            placeholder="Search insured, carrier, policy #, loan #, address"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="toolbar-actions">
          <select className="select" style={{ width: "auto" }} value={status} onChange={(e) => setStatus(e.target.value as "" | LetterStatus)}>
            {STATUS_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="card">
        <div className="card-content flush">
          {!loaded ? (
            <div className="loading-wrap"><div className="spinner" /></div>
          ) : letters.length === 0 ? (
            <div className="empty-state">No letters match.</div>
          ) : (
            <div className="table-wrap">
              <table className="data">
                <thead>
                  <tr>
                    <th>Insured</th>
                    <th>Type</th>
                    <th>Carrier</th>
                    <th>Policy #</th>
                    <th>Premium</th>
                    <th>Status</th>
                    <th>Received</th>
                  </tr>
                </thead>
                <tbody>
                  {letters.map((l) => (
                    <tr key={l.id} onClick={() => open(l)}>
                      <td className="cell-strong">{text(l.insured_name)}</td>
                      <td>{letterTypeLabel(l.letter_type)}</td>
                      <td>{text(l.carrier)}</td>
                      <td className="cell-muted">{text(l.policy_number)}</td>
                      <td>{money(l.total_premium)}</td>
                      <td><span className={`badge ${statusBadgeClass(l.status)}`}>{auditStatusLabel(l.status)}</span></td>
                      <td className="cell-muted">{dateTime(l.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Per-letter history modal */}
      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <div>
                <h2 className="card-title">
                  <FileText style={{ width: 16, height: 16 }} /> {text(selected.insured_name)} — history
                </h2>
                <p className="card-desc">
                  {[letterTypeLabel(selected.letter_type), text(selected.carrier), text(selected.policy_number)]
                    .filter((s) => s && s !== "—")
                    .join(" · ")}
                </p>
              </div>
              <button className="modal-close" onClick={() => setSelected(null)} aria-label="Close">
                <X style={{ width: 15, height: 15 }} />
              </button>
            </div>
            <div className="modal-body">
              {entriesLoading ? (
                <div className="loading-wrap"><div className="spinner" /></div>
              ) : entries.length === 0 ? (
                <p className="muted" style={{ fontSize: ".85rem" }}>No activity recorded.</p>
              ) : (
                <div className="timeline">
                  {entries.map((e) => {
                    const b = actionBadge(e);
                    const d = actionDetail(e);
                    return (
                      <div key={e.id} className="timeline-item">
                        <span className="timeline-dot" />
                        <div className="timeline-head">
                          <span className={`badge ${b.cls}`}>{b.label}</span>
                          <span className="timeline-actor">{e.actor_name ?? "System"}</span>
                          <span className="timeline-time">{dateTime(e.created_at)}</span>
                        </div>
                        {d && <p className="timeline-detail">{d}</p>}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
