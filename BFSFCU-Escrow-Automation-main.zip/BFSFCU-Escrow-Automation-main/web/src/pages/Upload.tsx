import { useRef, useState, useEffect, useCallback } from "react";
import { useNavigate, useOutletContext } from "react-router-dom";
import { UploadCloud, FileText, CheckCircle2, AlertTriangle, UserCheck, Shuffle, RefreshCw } from "lucide-react";
import { lettersApi } from "@/services";
import { useAuth } from "@/hooks/useAuth";
import type { Letter } from "@/types/letter";
import { letterTypeLabel, pipelineCategory, PIPELINE_BADGE } from "@/lib/letterStatus";
import { dateTime, text } from "@/lib/format";

interface OutletCtx {
  refreshCounts: () => void;
}

interface Item {
  key: string;
  name: string;
  state: "uploading" | "done" | "error";
  letterId?: string;
  error?: string;
}

let seq = 0;

export default function Upload() {
  const navigate = useNavigate();
  const { refreshCounts } = useOutletContext<OutletCtx>();
  const { isEscrowAdmin } = useAuth();
  const inputRef = useRef<HTMLInputElement>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [dragging, setDragging] = useState(false);

  // Previously uploaded letters (source = manual_upload). A Manager sees them all;
  // an Escrow Admin sees the ones assigned to them (enforced server-side).
  const [uploaded, setUploaded] = useState<Letter[]>([]);
  const [loadingList, setLoadingList] = useState(true);

  const loadUploaded = useCallback(() => {
    lettersApi
      .list({ source: "manual_upload", limit: 200 })
      .then((r) => setUploaded(r.letters))
      .catch(() => undefined)
      .finally(() => setLoadingList(false));
  }, []);

  // Load on mount and poll, so processing letters update their status here too.
  useEffect(() => {
    loadUploaded();
    const t = setInterval(loadUploaded, 10_000);
    return () => clearInterval(t);
  }, [loadUploaded]);

  const update = (key: string, patch: Partial<Item>) =>
    setItems((prev) => prev.map((it) => (it.key === key ? { ...it, ...patch } : it)));

  const upload = async (files: FileList | File[]) => {
    const entries = Array.from(files).map((file) => ({ file, key: `u${++seq}` }));
    setItems((prev) => [...prev, ...entries.map((e) => ({ key: e.key, name: e.file.name, state: "uploading" as const }))]);

    for (const { file, key } of entries) {
      try {
        const res = await lettersApi.upload(file);
        update(key, { state: "done", letterId: res.letterId });
      } catch (err) {
        update(key, { state: "error", error: err instanceof Error ? err.message : "Upload failed" });
      }
    }
    refreshCounts();
    loadUploaded();
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    if (e.dataTransfer.files.length) upload(e.dataTransfer.files);
  };

  return (
    <>
      <h1 className="page-title">
        <UploadCloud style={{ width: 24, height: 24 }} /> Upload Letters
      </h1>
      <p className="page-sub">
        Scan or drop escrow insurance letters (PDF, PNG, JPEG). Each is extracted, matched to Core DNA,
        compared to the record on file, and categorized.
      </p>

      {isEscrowAdmin ? (
        <div className="banner info">
          <UserCheck className="ic" />
          Letters you upload are assigned to you.
        </div>
      ) : (
        <div className="banner info">
          <Shuffle className="ic" />
          Uploaded letters are auto-distributed across the team by capacity.
        </div>
      )}

      <div
        className="card"
        style={{
          border: dragging ? "2px dashed var(--accent)" : "2px dashed var(--border)",
          background: dragging ? "hsl(218 89% 60% / .04)" : "var(--card)",
          textAlign: "center",
          padding: "2.5rem",
          cursor: "pointer",
        }}
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={onDrop}
      >
        <UploadCloud style={{ width: 34, height: 34, color: "var(--muted-foreground)" }} />
        <p style={{ fontWeight: 600, margin: ".6rem 0 .2rem" }}>Drop letters here or click to browse</p>
        <p className="muted" style={{ fontSize: ".82rem", margin: 0 }}>Up to 20 MB each</p>
        <input
          ref={inputRef}
          type="file"
          accept=".pdf,.png,.jpg,.jpeg,.tif,.tiff,application/pdf,image/png,image/jpeg,image/tiff"
          multiple
          style={{ display: "none" }}
          onChange={(e) => e.target.files && upload(e.target.files)}
        />
      </div>

      {items.length > 0 && (
        <div className="card" style={{ marginTop: "1.25rem" }}>
          <div className="card-header">
            <h2 className="card-title">Uploads</h2>
          </div>
          <div className="card-content flush">
            <div className="table-wrap">
              <table className="data">
                <tbody>
                  {items.map((it) => (
                    <tr
                      key={it.key}
                      onClick={() => it.letterId && navigate(`/letters/${it.letterId}`)}
                      style={{ cursor: it.letterId ? "pointer" : "default" }}
                    >
                      <td style={{ width: 30 }}>
                        <FileText style={{ width: 16, height: 16, color: "var(--muted-foreground)" }} />
                      </td>
                      <td className="cell-strong">{it.name}</td>
                      <td style={{ textAlign: "right" }}>
                        {it.state === "uploading" && <span className="muted">Queued…</span>}
                        {it.state === "done" && (
                          <span className="badge badge-success">
                            <CheckCircle2 style={{ width: 13, height: 13 }} /> Queued — view
                          </span>
                        )}
                        {it.state === "error" && (
                          <span className="badge badge-destructive" title={it.error}>
                            <AlertTriangle style={{ width: 13, height: 13 }} /> {it.error}
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      <div className="card" style={{ marginTop: "1.25rem" }}>
        <div className="card-header">
          <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
            <h2 className="card-title">Uploaded letters ({uploaded.length})</h2>
            <button className="btn btn-outline btn-sm" onClick={loadUploaded}>
              <RefreshCw className="ic" /> Refresh
            </button>
          </div>
        </div>
        <div className="card-content flush">
          {loadingList ? (
            <div className="loading-wrap">
              <div className="spinner" />
            </div>
          ) : uploaded.length === 0 ? (
            <div className="empty-state">No uploaded letters yet.</div>
          ) : (
            <div className="table-wrap">
              <table className="data">
                <thead>
                  <tr>
                    <th>Policy #</th>
                    <th>Insured / File</th>
                    <th>Status</th>
                    <th>Type</th>
                    <th>Carrier</th>
                    <th>Assigned to</th>
                    <th>Received</th>
                  </tr>
                </thead>
                <tbody>
                  {uploaded.map((l) => {
                    const cat = PIPELINE_BADGE[pipelineCategory(l)];
                    return (
                      <tr key={l.id} onClick={() => navigate(`/letters/${l.id}`)} style={{ cursor: "pointer" }}>
                        <td className="cell-muted">{text(l.policy_number)}</td>
                        <td className="cell-strong">
                          {text(l.insured_name) !== "—" ? text(l.insured_name) : text(l.original_filename)}
                        </td>
                        <td>
                          <span className={`badge ${cat.cls}`}>{cat.label}</span>
                        </td>
                        <td>{letterTypeLabel(l.letter_type)}</td>
                        <td>{text(l.carrier)}</td>
                        <td className="cell-muted">{text(l.assigned_to_name)}</td>
                        <td className="cell-muted">{dateTime(l.created_at)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <p className="footer-note">
        Processing runs in the background — a letter appears in its queue within a few seconds.
      </p>
    </>
  );
}
