import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Inbox, RefreshCw, Search } from "lucide-react";
import { inboxApi } from "@/services";
import type { Letter, InboxTiles } from "@/types/letter";
import { letterTypeLabel, pipelineCategory, PIPELINE_BADGE, type PipelineCategory } from "@/lib/letterStatus";
import { date, dateTime, text } from "@/lib/format";

type Filter = "all" | PipelineCategory;

export default function InboxMonitor() {
  const navigate = useNavigate();
  const [letters, setLetters] = useState<Letter[]>([]);
  const [tiles, setTiles] = useState<InboxTiles | null>(null);
  const [filter, setFilter] = useState<Filter>("all");
  const [search, setSearch] = useState("");
  const [updatedAt, setUpdatedAt] = useState<Date | null>(null);
  const [hasLoaded, setHasLoaded] = useState(false);

  const load = useCallback(() => {
    inboxApi
      .list(search.trim() || undefined)
      .then((r) => {
        setLetters(r.letters);
        setTiles(r.tiles);
        setUpdatedAt(new Date());
        setHasLoaded(true);
      })
      .catch(() => undefined);
  }, [search]);

  useEffect(() => {
    load();
    const t = setInterval(load, 10_000);
    return () => clearInterval(t);
  }, [load]);

  const visible = letters.filter((l) => filter === "all" || pipelineCategory(l) === filter);

  const chip = (id: Filter, label: string, count: number | undefined, tone: string) => (
    <button
      className={`inbox-chip ${tone}${filter === id ? " active" : ""}`}
      onClick={() => setFilter(id)}
    >
      <strong>{count ?? 0}</strong> {label}
    </button>
  );

  return (
    <>
      <div className="row" style={{ justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <h1 className="page-title">
            <Inbox style={{ width: 24, height: 24 }} /> Inbox Monitor
          </h1>
          <p className="page-sub">
            Letters from the email / Power Automate pipeline and their real processing status — spot
            stuck or failed deliveries at a glance. Auto-refreshes every 10s.
          </p>
        </div>
        <div className="row" style={{ gap: ".6rem" }}>
          {updatedAt && <span className="cell-muted">Updated {updatedAt.toLocaleTimeString()}</span>}
          <button className="btn btn-outline btn-sm" onClick={load}>
            <RefreshCw className="ic" /> Refresh
          </button>
        </div>
      </div>

      <div className="inbox-chips">
        {chip("all", "All", tiles?.total, "chip-muted")}
        {chip("processing", "Processing", tiles?.processing, "chip-accent")}
        {chip("stuck", "Stuck", tiles?.stuck, "chip-warning")}
        {chip("failed", "Failed / Exception", tiles?.failed, "chip-danger")}
        {chip("inReview", "In Progress", tiles?.inReview, "chip-navy")}
        {chip("resolved", "Approved / Declined", tiles?.resolved, "chip-success")}
      </div>

      <div className="toolbar">
        <div className="search-wrap">
          <Search className="ic" />
          <input
            className="input"
            placeholder="Search insured, carrier, policy #, sender, file…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="card">
        <div className="card-header">
          <h2 className="card-title">Inbox letters ({visible.length})</h2>
        </div>
        <div className="card-content flush">
          {!hasLoaded ? (
            <div className="loading-wrap">
              <div className="spinner" />
            </div>
          ) : visible.length === 0 ? (
            <div className="empty-state">No inbox letters yet.</div>
          ) : (
            <div className="table-wrap">
              <table className="data">
                <thead>
                  <tr>
                    <th>Policy #</th>
                    <th>Insured / File</th>
                    <th>Status</th>
                    <th>Type</th>
                    <th>Carrier</th>
                    <th>Assigned to</th>
                    <th>Received</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map((l) => {
                    const cat = PIPELINE_BADGE[pipelineCategory(l)];
                    return (
                      <tr key={l.id} onClick={() => navigate(`/letters/${l.id}`)}>
                        <td className="cell-muted">{text(l.policy_number)}</td>
                        <td className="cell-strong">
                          {text(l.insured_name) !== "—" ? text(l.insured_name) : text(l.original_filename)}
                        </td>
                        <td>
                          <span className={`badge ${cat.cls}`}>{cat.label}</span>
                        </td>
                        <td>{letterTypeLabel(l.letter_type)}</td>
                        <td>{text(l.carrier)}</td>
                        <td className="cell-muted">{text(l.assigned_to_name)}</td>
                        <td className="cell-muted">{dateTime(l.created_at) || date(l.created_at)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
