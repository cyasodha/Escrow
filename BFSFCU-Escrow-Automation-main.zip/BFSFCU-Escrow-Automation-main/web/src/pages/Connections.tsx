import { Cable } from "lucide-react";
import OracleSettings from "@/pages/OracleSettings";

/**
 * Connections hub — external systems the escrow app integrates with.
 *
 * Oracle is the only editable connection today. Email notifications are env-only
 * (NOTIFICATIONS_ENABLED / LOGIC_APP_URL — nothing to set in the UI), so they are
 * not shown here. When OOO sync (Graph) is built it gets its own tab here.
 */
export default function Connections() {
  return (
    <>
      <h1 className="page-title">
        <Cable style={{ width: 24, height: 24 }} /> Connections
      </h1>
      <p className="page-sub">External systems the escrow app integrates with.</p>
      <OracleSettings embedded />
    </>
  );
}
