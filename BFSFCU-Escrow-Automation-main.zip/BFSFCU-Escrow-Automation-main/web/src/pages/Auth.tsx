import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Loader2, LogIn } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { authApi } from "@/lib/api";
import { signInWithMicrosoft } from "@/lib/entra";

export default function Auth() {
  const { signIn, signInWithEntra, isAuthenticated, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  // Where to go after sign-in: the deep-linked path the user was headed to
  // (captured by ProtectedLayout), else the dashboard. Never bounce to /login.
  const fromState = (location.state as { from?: string } | null)?.from;
  const from = fromState && fromState !== "/login" ? fromState : "/tasks";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [ssoSubmitting, setSsoSubmitting] = useState(false);
  const [sso, setSso] = useState<{ enabled: boolean; tenantId?: string | null; clientId?: string | null }>({
    enabled: false,
  });

  useEffect(() => {
    if (isAuthenticated) navigate(from, { replace: true });
  }, [isAuthenticated, navigate, from]);

  useEffect(() => {
    authApi.ssoConfig().then(setSso).catch(() => setSso({ enabled: false }));
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      await signIn(email.trim(), password);
      navigate(from, { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Invalid email or password.");
    } finally {
      setSubmitting(false);
    }
  };

  const handleEntra = async () => {
    if (!sso.tenantId || !sso.clientId) return;
    setError(null);
    setSsoSubmitting(true);
    try {
      const idToken = await signInWithMicrosoft(sso.tenantId, sso.clientId);
      await signInWithEntra(idToken);
      navigate(from, { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Microsoft sign-in did not complete.");
    } finally {
      setSsoSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="auth-page">
        <Loader2 className="spin" style={{ width: 24, height: 24, color: "var(--muted-foreground)" }} />
      </div>
    );
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-brand">
          <img src="/bfsfcu-logo.svg" alt="Bank Fund Credit Union" />
        </div>
        <div className="auth-body">
          <h1 className="auth-title">EVA</h1>

          <form onSubmit={handleSubmit}>
            <div className="field-group">
              <label htmlFor="email">Email</label>
              <input
                id="email"
                className="input"
                type="email"
                autoComplete="username"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoFocus
              />
            </div>
            <div className="field-group">
              <label htmlFor="password">Password</label>
              <input
                id="password"
                className="input"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            {error && <p className="auth-error">{error}</p>}

            <button className="btn btn-primary btn-block" type="submit" disabled={submitting} style={{ marginTop: ".4rem" }}>
              {submitting ? (
                <>
                  <Loader2 className="spin ic" /> Signing in…
                </>
              ) : (
                <>
                  <LogIn className="ic" /> Sign in
                </>
              )}
            </button>
          </form>

          {sso.enabled && (
            <>
              <div className="auth-divider">
                <span>or</span>
              </div>
              <button className="btn btn-outline btn-block" onClick={handleEntra} disabled={ssoSubmitting}>
                {ssoSubmitting ? (
                  <>
                    <Loader2 className="spin ic" /> Connecting…
                  </>
                ) : (
                  "Sign in with Microsoft"
                )}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
