import { useCallback, useEffect, useState } from "react";
import { useParams, useNavigate, useOutletContext } from "react-router-dom";
import {
  ArrowLeft,
  CheckCircle2,
  XCircle,
  ListTodo,
  FileText,
  Check,
  AlertTriangle,
  Building2,
  CalendarClock,
  UserRound,
  Flag,
  FlagOff,
  ArrowUp,
  Pencil,
  Save,
  X,
  Scissors,
} from "lucide-react";
import { lettersApi, teamApi, managersApi } from "@/services";
import ReasonModal from "@/components/ReasonModal";
import { useAuth } from "@/hooks/useAuth";
import type { Letter, AuditEntry, NoteEntry, CompareRow, TeamMember, Manager } from "@/types/letter";
import {
  statusLabel,
  statusBadgeClass,
  letterTypeLabel,
  subtypeLabel,
  matchStatusLabel,
  reviewFlag,
} from "@/lib/letterStatus";
import { reasonLabel, reasonTone } from "@/lib/letterReasons";
import { coverageGap } from "@/lib/coverageGap";
import { money, date, dateTime, text } from "@/lib/format";

interface OutletCtx {
  refreshCounts: () => void;
}

const REVIEWABLE = new Set(["high_confidence", "low_confidence", "task"]);

export default function LetterDetail() {
  const { id = "" } = useParams();
  const navigate = useNavigate();
  const { refreshCounts } = useOutletContext<OutletCtx>();
  const { isManager } = useAuth();

  const [letter, setLetter] = useState<Letter | null>(null);
  const [fileUrl, setFileUrl] = useState<string | null>(null);
  const [audit, setAudit] = useState<AuditEntry[]>([]);
  const [notes, setNotes] = useState<NoteEntry[]>([]);
  const [reason, setReason] = useState("");
  // Closure note left blank on an action that requires one (Move / Decline).
  const [reasonMissing, setReasonMissing] = useState(false);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [escalating, setEscalating] = useState(false);
  const [escalateOpen, setEscalateOpen] = useState(false);
  const [escalateError, setEscalateError] = useState<string | null>(null);
  // Escalate → choose which manager it goes to.
  const [managers, setManagers] = useState<Manager[]>([]);
  const [escalateManager, setEscalateManager] = useState("");
  const [error, setError] = useState<string | null>(null);

  // Which tab of the Insurance Details card is showing.
  const [detailTab, setDetailTab] = useState<"details" | "notes" | "activity">("details");

  // Inline edit of the extracted insurance details.
  const [editing, setEditing] = useState(false);
  const [savingDetails, setSavingDetails] = useState(false);
  const [form, setForm] = useState<Record<string, string>>({});

  // Reschedule the task date (Escrow Admin).
  const [taskDate, setTaskDate] = useState("");
  const [taskNote, setTaskNote] = useState("");
  const [movingDate, setMovingDate] = useState(false);
  const [naTab, setNaTab] = useState<"current" | "history">("current");
  const [naFlash, setNaFlash] = useState<string | null>(null);

  // Reassign from the "Assigned" badge (Manager only).
  const [admins, setAdmins] = useState<TeamMember[]>([]);
  const [reassigning, setReassigning] = useState(false);
  const [assignBusy, setAssignBusy] = useState(false);
  const [assignError, setAssignError] = useState<string | null>(null);

  const load = useCallback(() => {
    lettersApi.get(id).then(setLetter).catch(() => setError("Letter not found"));
    lettersApi.audit(id).then((r) => setAudit(r.entries)).catch(() => undefined);
    lettersApi.notes(id).then((r) => setNotes(r.notes)).catch(() => undefined);
    lettersApi.fileUrl(id).then((r) => setFileUrl(r.url)).catch(() => setFileUrl(null));
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  // Managers available to escalate to (picked in the escalate modal).
  useEffect(() => {
    managersApi.list().then((r) => setManagers(r.managers)).catch(() => undefined);
  }, []);

  // A Manager can reassign from the Assigned badge — load the assignable Escrow
  // Admins (same set as Team Workload: active, and excluding the integration account).
  useEffect(() => {
    if (!isManager) return;
    teamApi
      .workload()
      .then((r) => setAdmins(r.members))
      .catch(() => undefined);
  }, [isManager]);

  // Keep the reschedule input in sync with the letter's current task date.
  useEffect(() => {
    if (letter?.task_date) setTaskDate(letter.task_date);
  }, [letter?.task_date]);

  const moveTaskDate = async () => {
    if (taskNote.trim().length < 3) {
      setError("A note is required to move the task date.");
      return;
    }
    setMovingDate(true);
    setError(null);
    try {
      await lettersApi.moveTaskDate(id, taskDate, taskNote.trim());
      setNaFlash(`Next action updated to ${date(taskDate)}.`);
      setTaskNote("");
      load();
      refreshCounts();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not move the task date");
    } finally {
      setMovingDate(false);
    }
  };

  const reassign = async (to: string) => {
    setAssignBusy(true);
    setAssignError(null);
    try {
      await lettersApi.assign(id, to);
      setReassigning(false);
      load();
      refreshCounts();
    } catch (err) {
      setAssignError(err instanceof Error ? err.message : "Could not reassign this letter");
    } finally {
      setAssignBusy(false);
    }
  };

  const submitEscalate = async (note: string) => {
    if (!letter) return;
    const willEscalate = !letter.escalated;
    setEscalating(true);
    setEscalateError(null);
    try {
      await lettersApi.escalate(id, willEscalate, note, willEscalate ? escalateManager : undefined);
      setEscalateOpen(false);
      setEscalateManager("");
      load();
      refreshCounts();
    } catch (err) {
      setEscalateError(err instanceof Error ? err.message : "Could not update escalation");
    } finally {
      setEscalating(false);
    }
  };

  const act = async (fn: () => Promise<unknown>, needsReason = false) => {
    if (needsReason && reason.trim().length < 3) {
      setReasonMissing(true);
      document.getElementById("closure-note")?.focus();
      return;
    }
    setReasonMissing(false);
    setBusy(true);
    setError(null);
    try {
      await fn();
      setReason("");
      load();
      refreshCounts();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Action failed");
    } finally {
      setBusy(false);
    }
  };

  const startEdit = () => {
    if (!letter) return;
    setError(null);
    setForm({
      letterType: letter.letter_type ?? "",
      cancellationSubtype: letter.cancellation_subtype ?? "",
      cancellationEffectiveDate: letter.cancellation_effective_date ?? "",
      insuredName: letter.insured_name ?? "",
      carrier: letter.carrier ?? "",
      policyNumber: letter.policy_number ?? "",
      policyType: letter.policy_type ?? "",
      loanNumber: letter.loan_number ?? "",
      dwellingCoverage: letter.dwelling_coverage ?? "",
      totalPremium: letter.total_premium ?? "",
      policyPeriodStart: letter.policy_period_start ?? "",
      policyPeriodEnd: letter.policy_period_end ?? "",
      propertyAddress: letter.property_address ?? "",
      reason: letter.reason ?? "",
    });
    setEditing(true);
  };

  const saveDetails = async () => {
    setSavingDetails(true);
    setError(null);
    try {
      await lettersApi.updateDetails(id, form);
      setEditing(false);
      load();
      refreshCounts();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save changes");
    } finally {
      setSavingDetails(false);
    }
  };

  const setField = (key: string, value: string) => setForm((f) => ({ ...f, [key]: value }));

  const addNote = async () => {
    if (!note.trim()) return;
    await lettersApi.addNote(id, note.trim());
    setNote("");
    lettersApi.notes(id).then((r) => setNotes(r.notes)).catch(() => undefined);
  };

  if (!letter) {
    return (
      <div className="loading-wrap">
        {error ? <div className="banner error"><AlertTriangle className="ic" />{error}</div> : <div className="spinner" />}
      </div>
    );
  }

  const l = letter;
  // Every reschedule is recorded in the audit trail as `task_date_moved` with the
  // note + target date — the letter's task history, newest first.
  const taskHistory = audit.filter((a) => a.action === "task_date_moved").slice().reverse();
  // The Next-action module: latest move is the "current activity"; the History tab
  // is the move + escalation timeline (newest first).
  const currentActivity = taskHistory[0];
  const ACTIVITY_ACTIONS = new Set(["task_date_moved", "escalated", "de_escalated"]);
  const activityTimeline = audit.filter((a) => ACTIVITY_ACTIONS.has(a.action)).slice().reverse();
  const activityLabel = (a: AuditEntry): string => {
    const n = a.metadata?.["note"] ? String(a.metadata["note"]) : "";
    if (a.action === "task_date_moved") {
      const to = a.metadata?.["to"] ? date(String(a.metadata["to"])) : "";
      return `Next action moved to ${to}${n ? ` — ${n}` : ""}`;
    }
    if (a.action === "escalated") return `Escalated${n ? ` — ${n}` : ""}`;
    if (a.action === "de_escalated") return `De-escalated${n ? ` — ${n}` : ""}`;
    return a.action;
  };
  const oracle = l.oracle_match_raw;
  const compare: CompareRow[] = Array.isArray(l.compare_result) ? l.compare_result : [];
  const reviewable = REVIEWABLE.has(l.status);
  const isCancellation = l.letter_type === "cancellation";
  const allFlags = [...(l.extraction_flags ?? []), ...(l.compare_flags ?? [])];
  // When the letter's policy number is not on file, there is no matching
  // insurance to compare against — hide the comparison rather than compare the
  // new policy against a different one on file.
  const noMatchingInsurance = (l.compare_flags ?? []).includes("no_matching_insurance");

  // Time Period Gaps — the previous coverage end (insurance on file) vs. the new
  // policy's start date. Computed client-side from data already in the payload.
  const prevCoverageEnd = oracle?.insuranceOnFile?.periodEnd ?? null;
  const gap = coverageGap(prevCoverageEnd, l.policy_period_start);
  const gapPanelClass =
    gap.kind === "gap" || gap.kind === "overlap" ? "lookup-panel no-match" : "lookup-panel";

  const field = (label: string, value: string, mono = false) => (
    <div className="field-group" style={{ marginBottom: ".7rem" }}>
      <p className="field-label">{label}</p>
      <p className={`field-value${mono ? " mono" : ""}`}>{value}</p>
    </div>
  );

  const editText = (label: string, key: string, type: "text" | "number" | "date" = "text") => (
    <div className="field-group" style={{ marginBottom: ".7rem" }}>
      <label>{label}</label>
      <input
        className="input"
        type={type}
        {...(type === "number" ? { step: "0.01" } : {})}
        value={form[key] ?? ""}
        onChange={(e) => setField(key, e.target.value)}
      />
    </div>
  );

  return (
    <>
      <button className="btn btn-ghost btn-sm" onClick={() => navigate("/tasks")} style={{ marginBottom: ".6rem" }}>
        <ArrowLeft className="ic" /> Back to list
      </button>

      <div className="row" style={{ justifyContent: "space-between", flexWrap: "wrap", gap: ".6rem" }}>
        <h1 className="page-title" style={{ marginBottom: 0 }}>
          {text(l.insured_name)}
        </h1>
        <div className="row" style={{ flexWrap: "wrap", justifyContent: "flex-end", gap: ".4rem" }}>
          {isManager && reassigning ? (
            <>
              <select
                className="select"
                style={{ width: "auto" }}
                value=""
                autoFocus
                disabled={assignBusy}
                onChange={(e) => e.target.value && reassign(e.target.value)}
              >
                <option value="">{assignBusy ? "Reassigning…" : "Reassign to…"}</option>
                <option value="auto">Auto (balance)</option>
                {admins
                  .filter((a) => a.id !== l.assigned_to)
                  .map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.fullName ?? a.email}
                    </option>
                  ))}
              </select>
              <button
                className="btn btn-ghost btn-sm"
                onClick={() => setReassigning(false)}
                disabled={assignBusy}
                title="Cancel reassignment"
              >
                <X className="ic" />
              </button>
            </>
          ) : isManager ? (
            <span
              className="badge badge-outline"
              role="button"
              tabIndex={0}
              style={{ cursor: "pointer" }}
              title="Click to reassign"
              onClick={() => {
                setAssignError(null);
                setReassigning(true);
              }}
              onKeyDown={(e) => {
                if (e.key === "Enter" || e.key === " ") {
                  setAssignError(null);
                  setReassigning(true);
                }
              }}
            >
              <UserRound style={{ width: 12, height: 12 }} /> Assigned: {l.assigned_to_name ?? "Unassigned"}
              <Pencil style={{ width: 11, height: 11, marginLeft: ".35rem", opacity: 0.7 }} />
            </span>
          ) : (
            <span className="badge badge-outline">
              <UserRound style={{ width: 12, height: 12 }} /> Assigned: {l.assigned_to_name ?? "Unassigned"}
            </span>
          )}
          {assignError && (
            <span className="cell-muted" style={{ color: "var(--destructive)", fontSize: ".8rem" }}>
              {assignError}
            </span>
          )}
        </div>
      </div>
      <div className="row" style={{ flexWrap: "wrap", gap: ".4rem", marginTop: ".55rem", marginBottom: "1.1rem" }}>
        <span className="badge badge-outline">{letterTypeLabel(l.letter_type)}</span>
        {(() => {
          const rf = reviewFlag(l);
          return rf ? (
            <span className={`badge ${rf.badgeClass}`}>{rf.label}</span>
          ) : (
            <span className={`badge ${statusBadgeClass(l.status)}`}>{statusLabel(l.status)}</span>
          );
        })()}
        {l.priority === "high" && (
          <span className="badge badge-priority">
            <ArrowUp style={{ width: 12, height: 12 }} /> High priority
          </span>
        )}
        {l.escalated && (
          <span className="badge badge-destructive">
            <Flag style={{ width: 12, height: 12 }} /> Escalated
            {l.escalated_to_name ? ` → ${l.escalated_to_name}` : ""}
          </span>
        )}
        {l.source_pages && (
          <span
            className="badge badge-outline"
            title="This letter was split out of a file that contained more than one letter."
          >
            <Scissors style={{ width: 12, height: 12 }} /> From a multi-letter upload · pages {l.source_pages}
            {l.split_total ? ` · letter ${(l.split_index ?? 0) + 1} of ${l.split_total}` : ""}
          </span>
        )}
      </div>

      {error && (
        <div className="banner error">
          <AlertTriangle className="ic" />
          {error}
        </div>
      )}

      <div className="grid grid-2-detail">
        {/* -------- Left: source document -------- */}
        <div className="stack">
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">
                <FileText style={{ width: 16, height: 16 }} /> Source letter
              </h2>
              <p className="card-desc">{text(l.original_filename)}</p>
            </div>
            <div className="card-content">
              <div className="doc-preview">
                {fileUrl ? (
                  <iframe title="Source letter" src={fileUrl} />
                ) : (
                  <div className="doc-empty">
                    <FileText style={{ width: 28, height: 28 }} />
                    Document preview unavailable
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* -------- Right: extraction, match, comparison, actions -------- */}
        <div className="stack">
          {/* Next activity — reschedule with a note (owner Escrow Admin or Manager).
              Escalate / De-escalate lives in this card's header. */}
          {reviewable && (
            <div className="card">
              <div className="card-header">
                <div className="row" style={{ justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <h2 className="card-title">
                      <CalendarClock style={{ width: 16, height: 16 }} /> Next action
                    </h2>
                  </div>
                  <button
                    className={`btn btn-sm ${l.escalated ? "btn-destructive-outline" : "btn-outline"}`}
                    disabled={escalating}
                    onClick={() => {
                      setEscalateError(null);
                      setEscalateOpen(true);
                    }}
                    title={
                      l.escalated
                        ? "De-escalate this letter"
                        : isManager
                          ? "Escalate this letter for review"
                          : "Escalate this letter to your manager"
                    }
                  >
                    {l.escalated ? (
                      <><FlagOff className="ic" /> {escalating ? "…" : "De-escalate"}</>
                    ) : (
                      <><Flag className="ic" /> {escalating ? "…" : "Escalate"}</>
                    )}
                  </button>
                </div>
              </div>
              <div className="card-content">
                <div className="tabbar" style={{ marginBottom: "1rem" }}>
                  <button
                    className={`tab${naTab === "current" ? " active" : ""}`}
                    onClick={() => setNaTab("current")}
                  >
                    Current &amp; Next
                  </button>
                  <button
                    className={`tab${naTab === "history" ? " active" : ""}`}
                    onClick={() => setNaTab("history")}
                  >
                    History{activityTimeline.length ? ` (${activityTimeline.length})` : ""}
                  </button>
                </div>

                {naTab === "current" ? (
                  <div className="grid grid-2" style={{ alignItems: "start" }}>
                    {/* Current activity — the latest move + its note. */}
                    <div>
                      <p className="field-label">Current activity</p>
                      {currentActivity ? (
                        <div style={{ background: "var(--muted)", borderRadius: 8, padding: ".8rem .95rem" }}>
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              gap: ".5rem",
                              marginBottom: ".25rem",
                            }}
                          >
                            <strong style={{ fontSize: ".84rem" }}>
                              {currentActivity.actor_name ?? "System"}
                            </strong>
                            <span className="muted" style={{ fontSize: ".76rem", whiteSpace: "nowrap" }}>
                              {currentActivity.metadata?.["to"]
                                ? date(String(currentActivity.metadata["to"]))
                                : ""}
                            </span>
                          </div>
                          {/* Long notes scroll inside the box instead of stretching the card. */}
                          <p
                            className="wrap-text"
                            style={{
                              margin: 0,
                              fontSize: ".84rem",
                              color: "var(--muted-foreground)",
                              maxHeight: "10rem",
                              overflowY: "auto",
                              paddingRight: ".25rem",
                            }}
                          >
                            {currentActivity.metadata?.["note"]
                              ? String(currentActivity.metadata["note"])
                              : "—"}
                          </p>
                        </div>
                      ) : (
                        <p className="muted" style={{ fontSize: ".85rem" }}>
                          No activity yet — set the next action to start.
                        </p>
                      )}
                    </div>

                    {/* Next action — reschedule with a note. */}
                    <div>
                      <p className="field-label">Next action</p>
                      <div className="field-group" style={{ marginBottom: 0 }}>
                        <label>Next-action date</label>
                        <input
                          className="input"
                          type="date"
                          value={taskDate}
                          onChange={(e) => setTaskDate(e.target.value)}
                        />
                      </div>
                      <div className="field-group" style={{ marginTop: ".7rem" }}>
                        <label>Note</label>
                        <input
                          className="input"
                          value={taskNote}
                          onChange={(e) => setTaskNote(e.target.value)}
                          placeholder="e.g. Waiting on carrier callback"
                        />
                      </div>
                      <button
                        className="btn btn-primary btn-sm"
                        style={{ marginTop: ".7rem" }}
                        disabled={movingDate || taskNote.trim().length < 3}
                        onClick={moveTaskDate}
                      >
                        <CalendarClock className="ic" /> {movingDate ? "Moving…" : "Move date"}
                      </button>
                      {naFlash && (
                        <p
                          style={{
                            margin: ".55rem 0 0",
                            fontSize: ".78rem",
                            color: "var(--success)",
                            display: "flex",
                            alignItems: "center",
                            gap: ".35rem",
                          }}
                        >
                          <CheckCircle2 className="ic" /> {naFlash}
                        </p>
                      )}
                    </div>
                  </div>
                ) : activityTimeline.length === 0 ? (
                  <p className="muted" style={{ fontSize: ".85rem" }}>No history yet.</p>
                ) : (
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      gap: ".75rem",
                      maxHeight: 300,
                      overflowY: "auto",
                    }}
                  >
                    {activityTimeline.map((a) => (
                      <div
                        key={a.id}
                        style={{
                          borderLeft: `2px solid ${a.action === "escalated" ? "var(--secondary)" : "var(--border)"}`,
                          paddingLeft: ".7rem",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            gap: ".5rem",
                            flexWrap: "wrap",
                          }}
                        >
                          <span className="wrap-text" style={{ fontSize: ".82rem", fontWeight: 500, minWidth: 0 }}>
                            {activityLabel(a)}
                          </span>
                          <span className="muted" style={{ fontSize: ".74rem", whiteSpace: "nowrap" }}>
                            {dateTime(a.created_at)}
                          </span>
                        </div>
                        <p className="muted" style={{ margin: ".1rem 0 0", fontSize: ".78rem" }}>
                          {a.actor_name ?? "System"}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Insurance details */}
          <div className="card">
            <div className="card-header" style={{ paddingBottom: 0 }}>
              <div className="row" style={{ justifyContent: "space-between", alignItems: "flex-start" }}>
                <div>
                  <h2 className="card-title" style={{ fontSize: "1.2rem" }}>Insurance Details</h2>
                  <p className="card-desc" style={{ marginTop: ".15rem" }}>{text(l.policy_number)}</p>
                </div>
                <div className="row" style={{ gap: ".4rem" }}>
                  {editing ? (
                    <>
                      <button className="btn btn-success btn-sm" onClick={saveDetails} disabled={savingDetails}>
                        <Save className="ic" /> {savingDetails ? "Saving…" : "Save"}
                      </button>
                      <button className="btn btn-ghost btn-sm" onClick={() => setEditing(false)} disabled={savingDetails}>
                        <X className="ic" /> Cancel
                      </button>
                    </>
                  ) : (
                    reviewable && (
                      <button
                        className="btn btn-outline btn-sm"
                        onClick={() => {
                          setDetailTab("details");
                          startEdit();
                        }}
                      >
                        <Pencil className="ic" /> Edit
                      </button>
                    )
                  )}
                </div>
              </div>
              <div className="tabbar tabbar-full" style={{ marginTop: ".9rem" }}>
                <button
                  className={`tab${detailTab === "details" ? " active" : ""}`}
                  onClick={() => setDetailTab("details")}
                >
                  Review
                </button>
                <button
                  className={`tab${detailTab === "notes" ? " active" : ""}`}
                  onClick={() => setDetailTab("notes")}
                >
                  Notes
                </button>
                <button
                  className={`tab${detailTab === "activity" ? " active" : ""}`}
                  onClick={() => setDetailTab("activity")}
                >
                  Audit Trail
                </button>
              </div>
            </div>
            <div className="card-content">
              {detailTab === "details" && (
              <>
              {editing && (
                <p className="card-desc" style={{ margin: "0 0 .8rem" }}>
                  Correct any field the extraction got wrong, then Save.
                </p>
              )}
              {l.letter_type === "cancellation" && (
                <div className="banner info" style={{ marginBottom: "1rem" }}>
                  <AlertTriangle className="ic" />
                  Cancellation — {subtypeLabel(l.cancellation_subtype) || "subtype not detected"}
                  {l.cancellation_effective_date ? ` · effective ${date(l.cancellation_effective_date)}` : ""}
                </div>
              )}

              {editing ? (
                <>
                  <div className="grid grid-2">
                    <div className="field-group" style={{ marginBottom: ".7rem" }}>
                      <label>Letter type</label>
                      <select
                        className="select"
                        value={form.letterType ?? ""}
                        onChange={(e) => setField("letterType", e.target.value)}
                      >
                        <option value="">Unknown / needs review</option>
                        <option value="modification">Modification / renewal</option>
                        <option value="cancellation">Cancellation</option>
                      </select>
                    </div>
                    {form.letterType === "cancellation" && (
                      <div className="field-group" style={{ marginBottom: ".7rem" }}>
                        <label>Cancellation subtype</label>
                        <select
                          className="select"
                          value={form.cancellationSubtype ?? ""}
                          onChange={(e) => setField("cancellationSubtype", e.target.value)}
                        >
                          <option value="">Not specified</option>
                          <option value="nonpayment">Nonpayment of premium</option>
                          <option value="provider_switch">Replacement coverage (provider switch)</option>
                          <option value="non_renewal">Non-renewal at expiration</option>
                        </select>
                      </div>
                    )}
                    {form.letterType === "cancellation" &&
                      editText("Cancellation effective date", "cancellationEffectiveDate", "date")}
                  </div>
                  <div className="grid grid-2">
                    {editText("Policy #", "policyNumber")}
                    {editText("Insured name", "insuredName")}
                    {editText("Carrier", "carrier")}
                    {editText("Policy type", "policyType")}
                    {editText("Loan #", "loanNumber")}
                    {editText("Dwelling coverage", "dwellingCoverage", "number")}
                    {editText("Total premium", "totalPremium", "number")}
                    {editText("Policy period start", "policyPeriodStart", "date")}
                    {editText("Policy period end", "policyPeriodEnd", "date")}
                  </div>
                  <div className="field-group">
                    <label>Property address</label>
                    <input className="input" value={form.propertyAddress ?? ""} onChange={(e) => setField("propertyAddress", e.target.value)} />
                  </div>
                  <div className="field-group" style={{ marginBottom: 0 }}>
                    <label>Reason</label>
                    <textarea className="textarea" rows={2} value={form.reason ?? ""} onChange={(e) => setField("reason", e.target.value)} />
                  </div>
                </>
              ) : (
                <>
                  <div className="grid grid-2">
                    {field("Policy #", text(l.policy_number), true)}
                    {field("Insured name", text(l.insured_name))}
                    {field("Carrier", text(l.carrier))}
                    {field("Policy type", text(l.policy_type))}
                    {field("Loan #", text(l.loan_number), true)}
                    {field("Dwelling coverage", money(l.dwelling_coverage))}
                    {field("Total premium", money(l.total_premium))}
                    {field("Policy period", `${date(l.policy_period_start)} – ${date(l.policy_period_end)}`)}
                    {field("Due date (derived)", date(l.due_date))}
                  </div>
                  {field("Property address", text(l.property_address))}
                  {field("Reason", text(l.reason))}
                </>
              )}
              </>
              )}

              {detailTab === "notes" && (
                // Fixed to the Review tab's height: the list scrolls, the add-note
                // input stays pinned at the bottom.
                <div style={{ display: "flex", flexDirection: "column", height: 370 }}>
                  <div style={{ flex: 1, minHeight: 0, overflowY: "auto", paddingRight: ".25rem" }}>
                    {notes.length === 0 ? (
                      <p className="muted" style={{ fontSize: ".85rem" }}>No notes yet.</p>
                    ) : (
                      notes.map((n) => (
                        <div key={n.id} style={{ padding: ".4rem 0", borderBottom: "1px solid var(--border)" }}>
                          <div className="row" style={{ justifyContent: "space-between" }}>
                            <strong style={{ fontSize: ".82rem" }}>{n.author_name ?? "User"}</strong>
                            <span className="cell-muted">{dateTime(n.created_at)}</span>
                          </div>
                          <p className="wrap-text" style={{ margin: ".2rem 0 0", fontSize: ".85rem" }}>{n.body}</p>
                        </div>
                      ))
                    )}
                  </div>
                  <div className="row" style={{ marginTop: ".8rem" }}>
                    <input
                      className="input"
                      placeholder="Add a note…"
                      value={note}
                      onChange={(e) => setNote(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && addNote()}
                    />
                    <button className="btn btn-outline btn-sm" onClick={addNote} disabled={!note.trim()}>
                      Add
                    </button>
                  </div>
                </div>
              )}

              {detailTab === "activity" && (
                // Capped to the Review tab's height; scrolls when the trail is long.
                <div style={{ maxHeight: 370, overflowY: "auto", paddingRight: ".25rem" }}>
                  {audit.length === 0 ? (
                    <p className="muted" style={{ fontSize: ".85rem" }}>No activity recorded yet.</p>
                  ) : (
                    audit.map((a) => (
                      <div
                        key={a.id}
                        className="row"
                        style={{ justifyContent: "space-between", padding: ".3rem 0", fontSize: ".8rem", borderBottom: "1px solid var(--border)" }}
                      >
                        <span>
                          <strong>{a.action.replace(/_/g, " ")}</strong>
                          <span className="muted"> · {a.actor_name ?? "System"}</span>
                        </span>
                        <span className="cell-muted">{dateTime(a.created_at)}</span>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Oracle match */}
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">
                <Building2 style={{ width: 16, height: 16 }} /> Loan match
              </h2>
              <p className="card-desc">{matchStatusLabel(l.match_status)}</p>
            </div>
            <div className="card-content">
              {oracle?.loan ? (
                <div className="lookup-panel">
                  <div className="lookup-row">
                    <span className="muted">Member</span>
                    <strong>{oracle.loan.memberName}</strong>
                  </div>
                  <div className="lookup-row">
                    <span className="muted">Property</span>
                    <strong>{oracle.loan.propertyAddress}</strong>
                  </div>
                  <div className="lookup-row">
                    <span className="muted">Loan #</span>
                    <strong>{oracle.loan.loanNumber}</strong>
                  </div>
                  <div className="lookup-row">
                    <span className="muted">Mortgage status</span>
                    <strong>{oracle.loan.mortgageStatus}</strong>
                  </div>
                  <div className="lookup-row">
                    <span className="muted">Escrow balance</span>
                    <strong>{money(oracle.loan.escrowBalance)}</strong>
                  </div>
                  <hr className="sep" style={{ margin: ".3rem 0" }} />
                  <div className="lookup-row">
                    <span className="muted">PII match (name + address)</span>
                    <span className={l.pii_match ? "ok" : "muted"}>
                      {l.pii_match ? <><Check style={{ width: 14, height: 14 }} /> Match</> : "Partial"}
                    </span>
                  </div>
                  <div className="lookup-row">
                    <span className="muted">Account match (loan # + policy #)</span>
                    <span className={l.account_match ? "ok" : "muted"}>
                      {l.account_match ? <><Check style={{ width: 14, height: 14 }} /> Match</> : "Partial"}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="lookup-panel no-match">
                  <div className="row">
                    <AlertTriangle style={{ width: 16, height: 16, color: "var(--destructive)" }} />
                    <strong>{matchStatusLabel(l.match_status)}</strong>
                  </div>
                  {oracle?.note && <p className="muted" style={{ margin: 0, fontSize: ".82rem" }}>{oracle.note}</p>}
                </div>
              )}
            </div>
          </div>

          {/* Comparison table — hidden for cancellations (nothing to renew/compare)
              and when there is no matching insurance on file. */}
          {!noMatchingInsurance && !isCancellation && (
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">Comparison — letter vs. on file</h2>
              <p className="card-desc">
                {l.premium_delta_pct
                  ? `Premium change ${Number(l.premium_delta_pct) > 0 ? "+" : ""}${l.premium_delta_pct}% (${money(l.premium_delta)})`
                  : "Field-by-field against the insurance record on file."}
              </p>
            </div>
            <div className="card-content">
              {compare.length === 0 ? (
                <p className="muted" style={{ fontSize: ".85rem" }}>No insurance on file to compare against.</p>
              ) : (
                <table className="compare-table">
                  <thead>
                    <tr>
                      <th>Field</th>
                      <th>On File</th>
                      <th>New Letter</th>
                      <th>Result</th>
                    </tr>
                  </thead>
                  <tbody>
                    {compare.map((r, idx) => (
                      <tr key={idx}>
                        <td className="cell-strong">{r.field}</td>
                        <td>{r.onFile ?? "—"}</td>
                        <td>{r.letter ?? "—"}</td>
                        <td>
                          {r.result === "match" ? (
                            <span className="match-ok"><Check style={{ width: 13, height: 13 }} /> Match</span>
                          ) : r.result === "changed" ? (
                            <span className="match-changed"><AlertTriangle style={{ width: 13, height: 13 }} /> Changed</span>
                          ) : (
                            <span className="match-new">{r.result === "new" ? "New" : "—"}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
          )}

          {/* Time Period Gaps — previous coverage end vs. new coverage start.
              Its own container (like Flags / Comparison). Not shown for
              cancellations, which have no incoming coverage start to compare. */}
          {!isCancellation && (
            <div className="card">
              <div className="card-header">
                <h2 className="card-title">
                  <CalendarClock style={{ width: 16, height: 16 }} /> Time Period Gaps
                </h2>
                <p className="card-desc">Previous coverage end vs. the new policy's start date.</p>
              </div>
              <div className="card-content">
                {gap.kind === "unknown" ? (
                  <p className="muted" style={{ fontSize: ".85rem" }}>
                    No prior coverage on file to compare against.
                  </p>
                ) : (
                  <div className={gapPanelClass}>
                    <div className="lookup-row">
                      <span className="muted">Previous coverage ends</span>
                      <strong>{date(prevCoverageEnd)}</strong>
                    </div>
                    <div className="lookup-row">
                      <span className="muted">New coverage starts</span>
                      <strong>{date(l.policy_period_start)}</strong>
                    </div>
                    <hr className="sep" style={{ margin: ".3rem 0" }} />
                    <div className="lookup-row">
                      <span className="muted">Result</span>
                      {gap.kind === "gap" ? (
                        <span
                          className="badge badge-destructive"
                          style={{ display: "inline-flex", alignItems: "center", gap: ".3rem" }}
                        >
                          <AlertTriangle style={{ width: 13, height: 13 }} /> Gap Detected · {gap.days}-day gap
                        </span>
                      ) : gap.kind === "overlap" ? (
                        <span
                          className="badge badge-destructive"
                          style={{ display: "inline-flex", alignItems: "center", gap: ".3rem" }}
                        >
                          <AlertTriangle style={{ width: 13, height: 13 }} /> Overlap Detected · {gap.days}-day overlap
                        </span>
                      ) : (
                        <span className="ok">
                          <Check style={{ width: 14, height: 14 }} /> Continuous coverage
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Flags */}
          {allFlags.length > 0 && (
            <div className="card">
              <div className="card-header">
                <h2 className="card-title">Flags</h2>
                <p className="card-desc">Shown to help you decide — they do not auto-route.</p>
              </div>
              <div className="card-content">
                <div className="row" style={{ flexWrap: "wrap", gap: ".4rem" }}>
                  {allFlags.map((f) => (
                    <span key={f} className={`badge ${reasonTone(f) === "warning" ? "badge-warning" : "badge-muted"}`}>
                      {reasonLabel(f)}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Review actions — the assigned Escrow Admin, or a Manager working an
              escalation, can accept / decline / move to Action Required. */}
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">Closure</h2>
              {!reviewable && (
                <p className="card-desc wrap-text">
                  {l.status === "approved"
                    ? `Approved ${dateTime(l.approved_at)}`
                    : l.status === "rejected"
                      ? `Declined ${dateTime(l.declined_at)}${l.checker_comment ? ` — ${l.checker_comment}` : ""}`
                      : "This letter is being processed."}
                </p>
              )}
            </div>
            {reviewable && (
              <div className="card-content">
                <div className="field-group">
                  <label htmlFor="closure-note">Note</label>
                  <textarea
                    id="closure-note"
                    className={`textarea${reasonMissing ? " invalid" : ""}`}
                    rows={2}
                    value={reason}
                    aria-invalid={reasonMissing}
                    aria-describedby={reasonMissing ? "closure-note-error" : undefined}
                    onChange={(e) => {
                      setReason(e.target.value);
                      if (reasonMissing && e.target.value.trim().length >= 3) setReasonMissing(false);
                    }}
                    placeholder="e.g. Provider-switch cancellation — needs policy alignment before payment."
                  />
                  {reasonMissing && (
                    <p id="closure-note-error" className="field-error">
                      A note (at least 3 characters) is required to Move to Action Required or Decline.
                    </p>
                  )}
                </div>
                <div className="row" style={{ flexWrap: "wrap", gap: ".5rem" }}>
                  <button
                    className="btn btn-success"
                    disabled={busy}
                    onClick={() => act(() => lettersApi.approve(id, reason.trim() || undefined))}
                  >
                    <CheckCircle2 className="ic" /> Accept
                  </button>
                  {l.status !== "task" && (
                    <button
                      className="btn btn-primary"
                      disabled={busy}
                      onClick={() => act(() => lettersApi.moveToTask(id, reason.trim()), true)}
                    >
                      <ListTodo className="ic" /> Move to Action Required
                    </button>
                  )}
                  <button
                    className="btn btn-destructive-outline"
                    disabled={busy}
                    onClick={() => act(() => lettersApi.decline(id, reason.trim()), true)}
                  >
                    <XCircle className="ic" /> Decline
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <ReasonModal
        open={escalateOpen}
        title={l.escalated ? "De-escalate letter" : "Escalate letter"}
        description={
          l.escalated
            ? "Clearing the escalation — add a note explaining why this no longer needs a manager's attention."
            : "Escalating for a manager's attention — add a note explaining why."
        }
        confirmLabel={l.escalated ? "De-escalate" : "Escalate"}
        confirmTone={l.escalated ? "destructive" : "primary"}
        placeholder={
          l.escalated
            ? "e.g. Reviewed and resolved with the carrier — no longer needs escalation."
            : "e.g. Carrier lapse risk — needs manager attention today."
        }
        busy={escalating}
        error={escalateError}
        select={
          l.escalated
            ? undefined
            : {
                label: "Escalate to (manager)",
                placeholder: "Choose a manager…",
                value: escalateManager,
                options: managers.map((m) => ({ value: m.id, label: m.fullName ?? m.email ?? "Manager" })),
                onChange: setEscalateManager,
                required: true,
              }
        }
        onConfirm={submitEscalate}
        onCancel={() => setEscalateOpen(false)}
      />
    </>
  );
}
