import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Flag, Search, UserRound } from "lucide-react";
import { lettersApi } from "@/services";
import type { Letter } from "@/types/letter";
import { letterTypeLabel, reviewFlag } from "@/lib/letterStatus";
import { money, date, text } from "@/lib/format";

const FLAG_BADGE: Record<string, string> = {
  success: "badge-success",
  warning: "badge-warning",
  destructive: "badge-destructive",
  muted: "badge-muted",
};

// Open, owner-actionable work — the same set that counts as "open" everywhere.
const OPEN_STATUSES = ["high_confidence", "task", "low_confidence"] as const;

/**
 * Manager Escalations — every letter an Escrow Admin has escalated for the
 * manager's attention. Open a letter to review, act, and de-escalate it (the
 * de-escalate control lives on the letter page).
 */
export default function Escalations({ embedded = false }: { embedded?: boolean }) {
  const navigate = useNavigate();

  const [letters, setLetters] = useState<Letter[]>([]);
  const [hasLoaded, setHasLoaded] = useState(false);
  const [search, setSearch] = useState("");

  const load = useCallback(() => {
    lettersApi
      .list({ status: OPEN_STATUSES, escalatedOnly: true, escalatedFirst: true, limit: 200 })
      .then((r) => {
        setLetters(r.letters);
        setHasLoaded(true);
      })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    load();
    const t = setInterval(load, 15_000);
    return () => clearInterval(t);
  }, [load]);

  const q = search.trim().toLowerCase();
  const rows = q
    ? letters.filter((l) =>
        [l.policy_number, l.insured_name, l.carrier, l.loan_number, l.assigned_to_name].some((v) =>
          (v ?? "").toLowerCase().includes(q)
        )
      )
    : letters;

  return (
    <>
      {!embedded && (
        <>
          <h1 className="page-title">
            <Flag style={{ width: 24, height: 24 }} /> Escalations
          </h1>
          <p className="page-sub">
            Letters your escrow admins escalated for your attention. Open one to review, act, and
            de-escalate it.
          </p>
        </>
      )}

      <div className="toolbar">
        <div className="search-wrap">
          <Search className="ic" />
          <input
            className="input"
            placeholder="Search insured, carrier, policy #, loan #, assignee"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="card">
        <div className="card-content flush">
          {!hasLoaded ? (
            <div className="loading-wrap">
              <div className="spinner" />
            </div>
          ) : rows.length === 0 ? (
            <div className="empty-state">
              {letters.length === 0 ? "No escalations right now. Nothing needs your attention." : `No escalations match “${search}”.`}
            </div>
          ) : (
            <div className="table-wrap">
              <table className="data">
                <thead>
                  <tr>
                    <th>Next action</th>
                    <th>Insured</th>
                    <th>Status</th>
                    <th>Type</th>
                    <th>Carrier</th>
                    <th>Premium</th>
                    <th>Assigned to</th>
                    <th>Escalated to</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((l) => {
                    const flag = reviewFlag(l);
                    return (
                      <tr
                        key={l.id}
                        className="row-escalated"
                        style={{ cursor: "pointer" }}
                        onClick={() => navigate(`/letters/${l.id}`)}
                      >
                        <td className="cell-muted">{date(l.task_date)}</td>
                        <td className="cell-strong">
                          {text(l.insured_name)}
                          <div className="cell-muted">{text(l.policy_number)}</div>
                        </td>
                        <td>{flag && <span className={`badge ${FLAG_BADGE[flag.tone]}`}>{flag.label}</span>}</td>
                        <td>{letterTypeLabel(l.letter_type)}</td>
                        <td>{text(l.carrier)}</td>
                        <td>{money(l.total_premium)}</td>
                        <td>
                          <span className="row" style={{ gap: ".35rem", fontSize: ".85rem" }}>
                            <UserRound style={{ width: 13, height: 13, opacity: 0.6 }} />
                            {l.assigned_to_name ?? "Unassigned"}
                          </span>
                        </td>
                        <td className="cell-muted">{l.escalated_to_name ?? "Unassigned"}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
