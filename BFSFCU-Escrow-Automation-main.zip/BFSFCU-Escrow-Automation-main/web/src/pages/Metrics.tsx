import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { BarChart3, AlarmClock, TrendingUp } from "lucide-react";
import { metricsApi, teamApi } from "@/services";
import type { TaskMetrics, TeamMember } from "@/types/letter";

/** Seconds → a short human duration, e.g. "2d 6h", "5h 12m", "45m". */
function humanDuration(seconds: number | null | undefined): string {
  if (seconds == null || !isFinite(seconds)) return "—";
  const s = Math.max(0, Math.round(seconds));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m`;
  return `${s}s`;
}

/** "YYYY-MM" → "Sep". */
function monthShort(ym: string): string {
  const [y, m] = ym.split("-").map(Number);
  return new Date(y ?? 1970, (m ?? 1) - 1, 1).toLocaleDateString("en-US", { month: "short" });
}

/**
 * Metrics — task-timing & lifecycle metrics (Manager), scopable to one Escrow
 * Admin.
 */
export default function Metrics() {
  const navigate = useNavigate();
  const [admins, setAdmins] = useState<TeamMember[]>([]);
  const [admin, setAdmin] = useState<string>("all");
  const [metrics, setMetrics] = useState<TaskMetrics | null>(null);

  useEffect(() => {
    teamApi.workload().then((r) => setAdmins(r.members)).catch(() => undefined);
  }, []);

  useEffect(() => {
    setMetrics(null);
    metricsApi.get(admin).then((r) => setMetrics(r.metrics)).catch(() => undefined);
  }, [admin]);

  const isAll = admin === "all";
  const adminName = isAll
    ? "the team"
    : admins.find((a) => a.id === admin)?.fullName ?? admins.find((a) => a.id === admin)?.email ?? "admin";

  return (
    <>
      <h1 className="page-title">Metrics</h1>
      <p className="page-sub">Task timing &amp; lifecycle — where work slows down.</p>

      <div className="toolbar" style={{ marginBottom: "1.25rem" }}>
        <div className="row" style={{ gap: ".5rem", alignItems: "center", flexWrap: "wrap" }}>
          <span className="field-label" style={{ margin: 0 }}>Filter by Escrow Admin</span>
          <select className="select" style={{ width: "auto" }} value={admin} onChange={(e) => setAdmin(e.target.value)}>
            <option value="all">All Escrow Admins</option>
            {admins.map((a) => (
              <option key={a.id} value={a.id}>{a.fullName ?? a.email}</option>
            ))}
          </select>
        </div>
      </div>

      {!metrics ? (
        <div className="loading-wrap"><div className="spinner" /></div>
      ) : (
        <div className="grid grid-2" style={{ gap: "1.5rem" }}>
          <MeanTrendCard metrics={metrics} isAll={isAll} adminName={adminName} />
          <RankingCard metrics={metrics} selected={admin} />
          <TopOpenCard metrics={metrics} selected={admin} onOpen={(id) => navigate(`/letters/${id}`)} />
          <ClosedOpenCard metrics={metrics} />
        </div>
      )}
    </>
  );
}

// ---------------------------------------------------------------------------
// Widget 1a — Mean time to close: 6-month trend
// ---------------------------------------------------------------------------
function MeanTrendCard({ metrics, isAll, adminName }: { metrics: TaskMetrics; isAll: boolean; adminName: string }) {
  const trend = metrics.trend;
  const latest = trend[trend.length - 1]?.meanSeconds ?? metrics.meanTimeToCloseSeconds;
  const hasData = trend.some((t) => t.meanSeconds != null);

  const chart = useMemo(() => {
    const W = 300, H = 90, padL = 6, padR = 6, padT = 10, padB = 6;
    const scope = trend.map((t) => (t.meanSeconds == null ? null : t.meanSeconds / 3600));
    const team = trend.map((t) => (t.teamMeanSeconds == null ? null : t.teamMeanSeconds / 3600));
    const all = [...scope, ...(isAll ? [] : team)].filter((v): v is number => v != null);
    if (all.length === 0) return null;
    const min = Math.min(...all) * 0.9;
    const max = Math.max(...all) * 1.1 || 1;
    const x = (i: number) => padL + (i * (W - padL - padR)) / (trend.length - 1 || 1);
    const y = (v: number) => H - padB - ((v - min) / (max - min || 1)) * (H - padT - padB);
    const line = (vals: (number | null)[]) => {
      const pts = vals.map((v, i) => ({ i, v })).filter((p): p is { i: number; v: number } => p.v != null);
      return { d: pts.map((p, k) => `${k === 0 ? "M" : "L"}${x(p.i).toFixed(1)},${y(p.v).toFixed(1)}`).join(" "), pts };
    };
    return { x, y, scope: line(scope), team: line(team) };
  }, [trend, isAll]);

  return (
    <div className="card">
      <div className="card-header">
        <h2 className="card-title"><TrendingUp style={{ width: 18, height: 18 }} /> Mean time to close</h2>
        <p className="card-desc">6-month trend for {adminName}{isAll ? "" : ", with the team average dashed behind"}.</p>
      </div>
      <div className="card-content">
        <p style={{ fontSize: "1.9rem", fontWeight: 700, margin: 0 }}>{humanDuration(latest)}</p>
        <p className="muted" style={{ fontSize: ".8rem", margin: ".2rem 0 .6rem" }}>latest month</p>
        {!hasData ? (
          <p className="muted" style={{ fontSize: ".85rem" }}>No closed tickets yet.</p>
        ) : (
          <>
            <svg viewBox="0 0 300 90" style={{ width: "100%", height: "auto", display: "block" }}>
              {!isAll && chart?.team && (
                <path d={chart.team.d} fill="none" stroke="var(--muted-foreground)" strokeWidth="1.5" strokeDasharray="3 3" />
              )}
              {chart?.scope && <path d={chart.scope.d} fill="none" stroke="var(--accent)" strokeWidth="2" />}
              {chart?.scope.pts.map((p) => (
                <circle key={p.i} cx={chart.x(p.i)} cy={chart.y(p.v)} r={p.i === trend.length - 1 ? 3.5 : 2.5} fill="var(--accent)">
                  <title>{`${monthShort(trend[p.i]!.month)}: ${humanDuration(trend[p.i]!.meanSeconds)}`}</title>
                </circle>
              ))}
            </svg>
            <div style={{ display: "flex", justifyContent: "space-between", fontSize: ".62rem", color: "var(--muted-foreground)", marginTop: ".2rem" }}>
              {trend.map((t, i) => (
                <span key={t.month} style={i === trend.length - 1 ? { fontStyle: "italic" } : undefined}>{monthShort(t.month)}</span>
              ))}
            </div>
            <div style={{ display: "flex", gap: "1rem", fontSize: ".72rem", color: "var(--muted-foreground)", marginTop: ".55rem", flexWrap: "wrap" }}>
              <span><i style={{ display: "inline-block", width: 12, height: 2, background: "var(--accent)", marginRight: ".35rem", verticalAlign: "middle" }} />{isAll ? "Team avg" : adminName}</span>
              {!isAll && <span><i style={{ display: "inline-block", width: 14, height: 2, background: "repeating-linear-gradient(to right, var(--muted-foreground) 0 3px, transparent 3px 6px)", marginRight: ".35rem", verticalAlign: "middle" }} />Team avg</span>}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Widget 1b — Mean time to close: team ranking
// ---------------------------------------------------------------------------
function RankingCard({ metrics, selected }: { metrics: TaskMetrics; selected: string }) {
  const withData = metrics.ranking.filter((r) => r.meanSeconds != null);
  const max = Math.max(1, ...withData.map((r) => r.meanSeconds ?? 0)) * 1.15;
  const teamMean = withData.length
    ? withData.reduce((s, r) => s + (r.meanSeconds ?? 0), 0) / withData.length
    : null;

  return (
    <div className="card">
      <div className="card-header">
        <h2 className="card-title"><BarChart3 style={{ width: 18, height: 18 }} /> Team ranking</h2>
        <p className="card-desc">Every admin's mean close time, fastest to slowest.</p>
      </div>
      <div className="card-content">
        {metrics.ranking.length === 0 ? (
          <p className="muted" style={{ fontSize: ".85rem" }}>No Escrow Admins yet.</p>
        ) : (
          <>
            {metrics.ranking.map((r) => {
              const hl = selected !== "all" && r.adminId === selected;
              const pct = r.meanSeconds == null ? 0 : (r.meanSeconds / max) * 100;
              return (
                <div key={r.adminId} style={{ display: "flex", alignItems: "center", gap: ".55rem", marginBottom: ".5rem", fontSize: ".76rem" }}>
                  <span style={{ width: 92, flexShrink: 0, color: hl ? "var(--foreground)" : "var(--muted-foreground)", fontWeight: hl ? 700 : 400, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{r.name}</span>
                  <span style={{ flex: 1, height: 9, background: "var(--muted)", borderRadius: 999, overflow: "hidden" }}>
                    <span style={{ display: "block", height: "100%", borderRadius: 999, width: `${pct}%`, background: hl ? "var(--accent)" : "var(--muted-foreground)", opacity: hl ? 1 : 0.4 }} />
                  </span>
                  <span style={{ width: 46, textAlign: "right", fontWeight: 600, flexShrink: 0 }}>{r.meanSeconds == null ? "—" : humanDuration(r.meanSeconds)}</span>
                </div>
              );
            })}
            <p className="muted" style={{ fontSize: ".74rem", margin: ".6rem 0 0" }}>Team avg: <strong>{humanDuration(teamMean)}</strong></p>
          </>
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Widget 2 — Longest open: top-5 backlog leaderboard
// ---------------------------------------------------------------------------
function TopOpenCard({ metrics, selected, onOpen }: { metrics: TaskMetrics; selected: string; onOpen: (id: string) => void }) {
  return (
    <div className="card">
      <div className="card-header">
        <h2 className="card-title"><AlarmClock style={{ width: 18, height: 18 }} /> Oldest open tickets</h2>
        <p className="card-desc">The 5 open tickets sitting the longest, team-wide.</p>
      </div>
      <div className="card-content">
        {metrics.topOpen.length === 0 ? (
          <p className="muted" style={{ fontSize: ".85rem" }}>No open tickets.</p>
        ) : (
          metrics.topOpen.map((t, i) => {
            const mine = selected !== "all" && t.adminId === selected;
            return (
              <div key={t.id} onClick={() => onOpen(t.id)} title="Open this letter"
                style={{ display: "flex", alignItems: "center", gap: ".55rem", padding: ".45rem .5rem", borderRadius: 6, fontSize: ".82rem", cursor: "pointer", background: mine ? "hsl(218 89% 60% / .09)" : undefined }}>
                <span style={{ width: 14, color: "var(--muted-foreground)", fontWeight: 700, fontSize: ".72rem" }}>{i + 1}</span>
                <span style={{ flex: 1, fontWeight: 600 }}>{t.insuredName ?? t.policyNumber ?? "Ticket"}</span>
                <span className="muted" style={{ fontSize: ".72rem" }}>{t.assignedToName ?? "Unassigned"}</span>
                <span style={{ fontWeight: 700, width: 52, textAlign: "right" }}>{humanDuration(t.openSeconds)}</span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Widget 3 — Closed (bars) vs. open backlog (burndown line) per month
// ---------------------------------------------------------------------------
function ClosedOpenCard({ metrics }: { metrics: TaskMetrics }) {
  const trend = metrics.trend;
  const chart = useMemo(() => {
    const W = 300, H = 150, padL = 8, padR = 8, padT = 12, padB = 20;
    const closed = trend.map((t) => t.closed);
    const open = trend.map((t) => t.openBacklog);
    const max = Math.max(10, Math.ceil((Math.max(...closed, ...open) * 1.15) / 10) * 10);
    const x = (i: number) => padL + (i * (W - padL - padR)) / (trend.length - 1 || 1);
    const y = (v: number) => H - padB - (v / max) * (H - padT - padB);
    const baseline = H - padB;
    const barW = ((W - padL - padR) / trend.length) * 0.42;
    const openPath = open.map((v, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(" ");
    return { W, H, x, y, baseline, barW, max, closed, open, openPath };
  }, [trend]);

  return (
    <div className="card">
      <div className="card-header">
        <h2 className="card-title"><BarChart3 style={{ width: 18, height: 18 }} /> Closed vs. open per month</h2>
        <p className="card-desc">Closed as monthly bars, open backlog as a burndown line.</p>
      </div>
      <div className="card-content">
        <svg viewBox={`0 0 ${chart.W} ${chart.H}`} style={{ width: "100%", height: "auto", display: "block" }}>
          {[0.33, 0.66, 1].map((f) => (
            <line key={f} x1={8} y1={chart.y(chart.max * f)} x2={chart.W - 8} y2={chart.y(chart.max * f)} stroke="var(--border)" strokeWidth="1" />
          ))}
          {chart.closed.map((v, i) => {
            const bx = chart.x(i) - chart.barW / 2;
            const by = chart.y(v);
            return <rect key={i} x={bx} y={by} width={chart.barW} height={Math.max(0, chart.baseline - by)} rx="2" fill="var(--success)"><title>{`Closed — ${monthShort(trend[i]!.month)}: ${v}`}</title></rect>;
          })}
          <path d={chart.openPath} fill="none" stroke="var(--accent)" strokeWidth="2.5" />
          {chart.open.map((v, i) => (
            <circle key={i} cx={chart.x(i)} cy={chart.y(v)} r="4.5" fill="var(--card)" stroke="var(--accent)" strokeWidth="2"><title>{`Open — ${monthShort(trend[i]!.month)}: ${v}`}</title></circle>
          ))}
          {trend.map((t, i) => (
            <text key={t.month} x={chart.x(i)} y={chart.H - 4} fontSize="8" fill="var(--muted-foreground)" textAnchor="middle" fontStyle={i === trend.length - 1 ? "italic" : "normal"}>{monthShort(t.month)}</text>
          ))}
        </svg>
        <div style={{ display: "flex", gap: "1rem", fontSize: ".72rem", color: "var(--muted-foreground)", marginTop: ".55rem", flexWrap: "wrap" }}>
          <span><i style={{ display: "inline-block", width: 8, height: 8, borderRadius: 2, background: "var(--success)", marginRight: ".35rem", verticalAlign: "-1px" }} />Closed (bars)</span>
          <span><i style={{ display: "inline-block", width: 12, height: 2, background: "var(--accent)", marginRight: ".35rem", verticalAlign: "middle" }} />Still open (line)</span>
        </div>
      </div>
    </div>
  );
}
