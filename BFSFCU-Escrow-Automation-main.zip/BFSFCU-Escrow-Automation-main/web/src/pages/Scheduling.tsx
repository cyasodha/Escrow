import { useEffect, useState } from "react";
import { CalendarClock, CheckCircle2, AlertTriangle, Plus, Trash2 } from "lucide-react";
import { settingsApi, type ScheduleConfig, type Holiday, type OooSyncResult } from "@/services";
import { date as fmtDate } from "@/lib/format";

const DAYS: { iso: number; label: string }[] = [
  { iso: 1, label: "Mon" },
  { iso: 2, label: "Tue" },
  { iso: 3, label: "Wed" },
  { iso: 4, label: "Thu" },
  { iso: 5, label: "Fri" },
  { iso: 6, label: "Sat" },
  { iso: 7, label: "Sun" },
];

// A few common US zones for convenience; any IANA zone is accepted.
const ZONES = [
  "America/New_York",
  "America/Chicago",
  "America/Denver",
  "America/Los_Angeles",
  "America/Phoenix",
  "UTC",
];

/** 'YYYY-MM-DD' → 'Mon D' (no year) — for recurring holidays. */
function monthDay(d: string): string {
  const [y, m, day] = d.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, day)).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  });
}

export default function Scheduling() {
  const [cfg, setCfg] = useState<ScheduleConfig | null>(null);
  const [holidays, setHolidays] = useState<Holiday[]>([]);
  const [newDate, setNewDate] = useState("");
  const [newLabel, setNewLabel] = useState("");
  const [newAnnual, setNewAnnual] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const [syncResult, setSyncResult] = useState<OooSyncResult | null>(null);
  const [running, setRunning] = useState(false);

  const loadHolidays = () => settingsApi.listHolidays().then((r) => setHolidays(r.holidays)).catch(() => undefined);

  useEffect(() => {
    settingsApi.getSchedule().then(setCfg).catch(() => undefined);
    loadHolidays();
  }, []);

  const toggleDay = (iso: number) => {
    if (!cfg) return;
    const has = cfg.workDays.includes(iso);
    const workDays = has ? cfg.workDays.filter((d) => d !== iso) : [...cfg.workDays, iso].sort();
    setCfg({ ...cfg, workDays });
  };

  const save = async () => {
    if (!cfg) return;
    setError(null);
    setSaved(false);
    try {
      const updated = await settingsApi.putSchedule(cfg);
      setCfg(updated);
      setSaved(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save");
    }
  };

  const addHoliday = async () => {
    setError(null);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(newDate)) {
      setError("Enter the holiday date as YYYY-MM-DD.");
      return;
    }
    try {
      await settingsApi.addHoliday(newDate, newLabel.trim() || null, newAnnual);
      setNewDate("");
      setNewLabel("");
      setNewAnnual(false);
      loadHolidays();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not add holiday");
    }
  };

  const removeHoliday = async (id: string) => {
    await settingsApi.deleteHoliday(id).catch(() => undefined);
    loadHolidays();
  };

  const runNow = async () => {
    setRunning(true);
    setSyncResult(null);
    setError(null);
    try {
      const r = await settingsApi.runOooSync();
      setSyncResult(r);
      settingsApi.getSchedule().then(setCfg).catch(() => undefined); // refresh last-run
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not run the sync");
    } finally {
      setRunning(false);
    }
  };

  return (
    <>
      <h1 className="page-title">
        <CalendarClock style={{ width: 24, height: 24 }} /> Scheduling
      </h1>
      <p className="page-sub">
        Working days &amp; hours drive the next-action date: letters received after the end of the
        day, on a weekend, or on a holiday are worked the next working day at the start time.
      </p>

      <div className="card" style={{ maxWidth: 720 }}>
        <div className="card-content">
          {error && <div className="banner error"><AlertTriangle className="ic" />{error}</div>}
          {saved && <div className="banner info"><CheckCircle2 className="ic" />Saved.</div>}

          {!cfg ? (
            <div className="loading-wrap"><div className="spinner" /></div>
          ) : (
            <>
              <div className="field-group" style={{ marginBottom: ".8rem" }}>
                <label>Working days</label>
                <div className="row" style={{ flexWrap: "wrap", gap: ".4rem" }}>
                  {DAYS.map((d) => (
                    <button
                      key={d.iso}
                      className={`tag-pill ${cfg.workDays.includes(d.iso) ? "high" : "normal"}`}
                      onClick={() => toggleDay(d.iso)}
                      type="button"
                    >
                      {d.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-2">
                <div className="field-group">
                  <label>Start of day</label>
                  <input className="input" type="time" value={cfg.workStart}
                    onChange={(e) => setCfg({ ...cfg, workStart: e.target.value })} />
                </div>
                <div className="field-group">
                  <label>End of the day</label>
                  <input className="input" type="time" value={cfg.workCutoff}
                    onChange={(e) => setCfg({ ...cfg, workCutoff: e.target.value })} />
                </div>
                <div className="field-group">
                  <label>Timezone</label>
                  <input className="input" list="tz-list" value={cfg.timezone}
                    onChange={(e) => setCfg({ ...cfg, timezone: e.target.value })} placeholder="America/New_York" />
                  <datalist id="tz-list">
                    {ZONES.map((z) => <option key={z} value={z} />)}
                  </datalist>
                </div>
              </div>

              <div className="row">
                <button className="btn btn-primary" onClick={save}>Save calendar</button>
              </div>

              <hr style={{ border: "none", borderTop: "1px solid var(--border)", margin: "1.1rem 0" }} />

              <h2 className="card-title" style={{ marginTop: 0 }}>Out-of-office sync</h2>
              <p className="muted" style={{ fontSize: ".85rem", marginTop: 0 }}>
                At the end of the day, reads each admin's Outlook out-of-office for the next working day and
                drops those who are out from auto-assignment (Microsoft Graph).
              </p>

              <label className="row" style={{ margin: ".4rem 0 .8rem", cursor: "pointer" }}>
                <input className="checkbox" type="checkbox" checked={cfg.oooSyncEnabled}
                  onChange={(e) => setCfg({ ...cfg, oooSyncEnabled: e.target.checked })} />
                Enable auto sync
              </label>

              {syncResult && (
                <div className="banner info" style={{ display: "block" }}>
                  {!syncResult.ran ? (
                    `Did not run (${syncResult.reason}).`
                  ) : (syncResult.markedOut?.length ?? 0) === 0 ? (
                    `No one is out of office ${syncResult.targetDate ? fmtDate(syncResult.targetDate) : ""}.`
                  ) : (
                    <>
                      <div style={{ fontWeight: 600, marginBottom: ".3rem" }}>
                        Out of office {syncResult.targetDate ? fmtDate(syncResult.targetDate) : ""}
                      </div>
                      <ol style={{ margin: 0, paddingLeft: "1.4rem" }}>
                        {syncResult.markedOut!.map((name, i) => (
                          <li key={i}>{name}</li>
                        ))}
                      </ol>
                    </>
                  )}
                </div>
              )}

              <div className="row">
                <button
                  className="btn btn-primary"
                  onClick={save}
                  disabled={!cfg.graphConfigured}
                  title={!cfg.graphConfigured ? "Microsoft Graph is not enabled (GRAPH_ENABLED)" : "Save"}
                >
                  Save
                </button>
                <button
                  className="btn btn-outline"
                  onClick={runNow}
                  disabled={running || !cfg.graphConfigured}
                  title={!cfg.graphConfigured ? "Microsoft Graph is not enabled (GRAPH_ENABLED)" : "Run the OOO sync now"}
                >
                  {running ? "Running…" : "Run sync now"}
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="card" style={{ maxWidth: 720, marginTop: "1rem" }}>
        <div className="card-content">
          <h2 className="card-title">Holidays</h2>
          <p className="muted" style={{ fontSize: ".85rem", marginTop: 0 }}>
            Non-working days on top of weekends.
          </p>

          <div className="row" style={{ gap: ".5rem", marginBottom: ".8rem", flexWrap: "wrap" }}>
            <input className="input" type="date" style={{ width: "auto" }} value={newDate}
              onChange={(e) => setNewDate(e.target.value)} />
            <input className="input" style={{ width: "auto", flex: 1 }} placeholder="Label (optional)"
              value={newLabel} onChange={(e) => setNewLabel(e.target.value)} />
            <label className="row" style={{ cursor: "pointer", whiteSpace: "nowrap" }}
              title="Recurs every year on this month/day">
              <input className="checkbox" type="checkbox" checked={newAnnual}
                onChange={(e) => setNewAnnual(e.target.checked)} />
              Every year
            </label>
            <button className="btn btn-outline" onClick={addHoliday}><Plus className="ic" /> Add</button>
          </div>

          {holidays.length === 0 ? (
            <p className="muted" style={{ fontSize: ".85rem" }}>No holidays configured.</p>
          ) : (
            <table className="data">
              <thead><tr><th>Date</th><th>Label</th><th></th></tr></thead>
              <tbody>
                {holidays.map((h) => (
                  <tr key={h.id}>
                    <td className="cell-strong">
                      {h.annual ? monthDay(h.date) : fmtDate(h.date)}
                      {h.annual && (
                        <span
                          style={{
                            marginLeft: 8,
                            fontSize: ".68rem",
                            fontWeight: 700,
                            textTransform: "uppercase",
                            letterSpacing: ".03em",
                            padding: "2px 7px",
                            borderRadius: 999,
                            background: "hsl(221 83% 53% / .12)",
                            color: "hsl(221 70% 42%)",
                            border: "1px solid hsl(221 83% 53% / .3)",
                          }}
                        >
                          Every year
                        </span>
                      )}
                    </td>
                    <td>{h.label ?? <span className="muted">—</span>}</td>
                    <td style={{ textAlign: "right" }}>
                      <button className="btn btn-ghost" onClick={() => removeHoliday(h.id)} title="Remove holiday">
                        <Trash2 className="ic" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </>
  );
}
