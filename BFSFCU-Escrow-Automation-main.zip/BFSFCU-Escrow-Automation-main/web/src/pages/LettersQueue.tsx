import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Search, ShieldCheck, AlertTriangle, ListTodo, CheckCheck, XCircle } from "lucide-react";
import { lettersApi } from "@/services";
import type { Letter, LetterStatus } from "@/types/letter";
import { letterTypeLabel } from "@/lib/letterStatus";
import { money, date, text } from "@/lib/format";

interface Props {
  status: LetterStatus;
  title: string;
  subtitle: string;
  icon: "high" | "low" | "task" | "approved" | "declined";
}

const ICONS = {
  high: ShieldCheck,
  low: AlertTriangle,
  task: ListTodo,
  approved: CheckCheck,
  declined: XCircle,
};

export default function LettersQueue({ status, title, subtitle, icon }: Props) {
  const navigate = useNavigate();
  const [letters, setLetters] = useState<Letter[]>([]);
  const [hasLoaded, setHasLoaded] = useState(false);
  const [search, setSearch] = useState("");
  // Type/Carrier sorting is client-side over the loaded page. null = the API's
  // default order (newest first); clicking a sortable header toggles asc/desc.
  const [sort, setSort] = useState<{ key: "type" | "carrier"; dir: "asc" | "desc" } | null>(null);
  const Icon = ICONS[icon];

  const toggleSort = (key: "type" | "carrier") =>
    setSort((prev) =>
      prev?.key === key ? { key, dir: prev.dir === "asc" ? "desc" : "asc" } : { key, dir: "asc" }
    );

  const sortValue = (l: Letter, key: "type" | "carrier") =>
    key === "type" ? letterTypeLabel(l.letter_type) : l.carrier ?? "";

  const sorted = sort
    ? [...letters].sort((a, b) => {
        const c = sortValue(a, sort.key).localeCompare(sortValue(b, sort.key), undefined, {
          sensitivity: "base",
        });
        return sort.dir === "asc" ? c : -c;
      })
    : letters;

  const sortableTh = (label: string, key: "type" | "carrier") => (
    <th
      onClick={() => toggleSort(key)}
      style={{ cursor: "pointer", userSelect: "none", whiteSpace: "nowrap" }}
      title={`Sort by ${label.toLowerCase()}`}
    >
      {label}
      <span className="cell-muted" style={{ marginLeft: ".25rem" }}>
        {sort?.key === key ? (sort.dir === "asc" ? "▲" : "▼") : "↕"}
      </span>
    </th>
  );

  const load = useCallback(() => {
    lettersApi
      .list({ status, search: search.trim() || undefined, limit: 200 })
      .then((r) => {
        setLetters(r.letters);
        setHasLoaded(true);
      })
      .catch(() => {
        /* keep spinner / last list on a transient failure */
      });
  }, [status, search]);

  useEffect(() => {
    setHasLoaded(false);
    load();
    const t = setInterval(load, 10_000);
    return () => clearInterval(t);
  }, [load]);

  return (
    <>
      <h1 className="page-title">
        <Icon style={{ width: 24, height: 24 }} /> {title}
      </h1>
      <p className="page-sub">{subtitle}</p>

      <div className="toolbar">
        <div className="search-wrap" style={{ maxWidth: "25rem" }}>
          <Search className="ic" />
          <input
            className="input"
            placeholder="Search insured, carrier, policy #, loan #, address"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="card">
        <div className="card-content flush">
          {!hasLoaded ? (
            <div className="loading-wrap">
              <div className="spinner" />
            </div>
          ) : letters.length === 0 ? (
            <div className="empty-state">No letters in this queue.</div>
          ) : (
            <div className="table-wrap">
              <table className="data">
                <thead>
                  <tr>
                    <th>Policy #</th>
                    <th>Insured</th>
                    {sortableTh("Type", "type")}
                    {sortableTh("Carrier", "carrier")}
                    <th>Loan #</th>
                    <th>Premium</th>
                    <th>Received</th>
                  </tr>
                </thead>
                <tbody>
                  {sorted.map((l) => (
                    <tr key={l.id} onClick={() => navigate(`/letters/${l.id}`)}>
                      <td className="cell-muted">{text(l.policy_number)}</td>
                      <td className="cell-strong">{text(l.insured_name)}</td>
                      <td>{letterTypeLabel(l.letter_type)}</td>
                      <td>{text(l.carrier)}</td>
                      <td className="cell-muted">{text(l.loan_number)}</td>
                      <td>{money(l.total_premium)}</td>
                      <td className="cell-muted">{date(l.created_at)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
