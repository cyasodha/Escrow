import { useCallback, useEffect, useState } from "react";
import { useNavigate, useOutletContext } from "react-router-dom";
import { Users, ChevronDown, ChevronRight, Search } from "lucide-react";
import { teamApi, lettersApi, usersApi } from "@/services";
import type { TeamMember, TeamWorkload as TW, Letter, Capacity } from "@/types/letter";
import { letterTypeLabel, reviewFlag } from "@/lib/letterStatus";
import { money, date, text } from "@/lib/format";

interface OutletCtx {
  refreshCounts: () => void;
}

function initials(name: string | null, email: string | null): string {
  const base = (name || email || "?").trim();
  const parts = base.split(/\s+/);
  if (parts.length >= 2) return (parts[0]![0]! + parts[1]![0]!).toUpperCase();
  return base.slice(0, 2).toUpperCase();
}

/** An amber "Out" pill when the admin is effectively out (skipped by auto-assign). */
function OutBadge({ member }: { member: TeamMember }) {
  if (!member.effectiveOut) return null;
  return (
    <span
      title="Out of office (nightly sync)"
      style={{
        marginLeft: 8,
        fontSize: ".68rem",
        fontWeight: 700,
        textTransform: "uppercase",
        letterSpacing: ".03em",
        padding: "2px 7px",
        borderRadius: 999,
        background: "hsl(38 92% 50% / .14)",
        color: "hsl(30 80% 34%)",
        border: "1px solid hsl(38 92% 50% / .35)",
        whiteSpace: "nowrap",
      }}
    >
      Out
    </span>
  );
}

export default function TeamWorkload({ embedded = false }: { embedded?: boolean }) {
  const navigate = useNavigate();
  const { refreshCounts } = useOutletContext<OutletCtx>();
  const [data, setData] = useState<TW | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [memberLetters, setMemberLetters] = useState<Letter[]>([]);
  const [drillSearch, setDrillSearch] = useState("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(() => {
    teamApi.workload().then(setData).catch(() => undefined);
  }, []);

  useEffect(() => {
    load();
    const t = setInterval(load, 15_000);
    return () => clearInterval(t);
  }, [load]);

  const loadMember = useCallback((id: string) => {
    lettersApi
      .list({ assigned: id, status: ["high_confidence", "task", "low_confidence"], escalatedFirst: true, limit: 200 })
      .then((r) => setMemberLetters(r.letters))
      .catch(() => setMemberLetters([]));
  }, []);

  const toggleExpand = (id: string) => {
    setDrillSearch("");
    if (expanded === id) {
      setExpanded(null);
      setMemberLetters([]);
    } else {
      setExpanded(id);
      setMemberLetters([]);
      loadMember(id);
    }
  };

  const refreshAll = () => {
    load();
    refreshCounts();
    if (expanded) loadMember(expanded);
  };

  const setCapacity = async (m: TeamMember, capacity: Capacity) => {
    await usersApi.update(m.id, { capacity });
    load();
  };
  const toggleAuto = async (m: TeamMember) => {
    await usersApi.update(m.id, { autoAssignEnabled: !m.autoAssignEnabled });
    load();
  };
  const togglePriority = async (l: Letter) => {
    setBusy(true);
    try {
      await lettersApi.setPriority(l.id, l.priority === "high" ? "normal" : "high");
      refreshAll();
    } finally {
      setBusy(false);
    }
  };
  const reassign = async (l: Letter, to: string) => {
    setBusy(true);
    try {
      await lettersApi.assign(l.id, to);
      refreshAll();
    } finally {
      setBusy(false);
    }
  };

  const members = data?.members ?? [];
  const activeCount = members.length;

  return (
    <>
      {!embedded && (
        <>
          <h1 className="page-title">
            <Users style={{ width: 24, height: 24 }} /> Team Workload
          </h1>
          <p className="page-sub">
            {activeCount} escrow admin{activeCount === 1 ? "" : "s"} · {data?.totalOpen ?? 0} letters open.
            Open a row to set priority or reassign individual letters.
          </p>
        </>
      )}

      {!data ? (
        <div className="loading-wrap">
          <div className="spinner" />
        </div>
      ) : members.length === 0 ? (
        <div className="empty-state">No active escrow admins yet. Add some in User Management.</div>
      ) : (
        <div className="stack" style={{ gap: ".75rem" }}>
          {members.map((m) => {
            const isOpen = expanded === m.id;
            return (
              <div key={m.id} className="card wl-card">
                <div className="wl-row" onClick={() => toggleExpand(m.id)} style={{ cursor: "pointer" }}>
                  <button
                    className="wl-expand"
                    onClick={(e) => { e.stopPropagation(); toggleExpand(m.id); }}
                    title={isOpen ? "Hide assigned letters" : "Show assigned letters"}
                    aria-expanded={isOpen}
                  >
                    {isOpen ? <ChevronDown className="ic" /> : <ChevronRight className="ic" />}
                  </button>
                  <div className="wl-avatar">{initials(m.fullName, m.email)}</div>
                  <div className="wl-who">
                    <div className="wl-name">
                      {m.fullName ?? m.email}
                      <OutBadge member={m} />
                    </div>
                    <div className="wl-sub">
                      {m.openCount} open
                      {m.urgentCount > 0 && <span className="wl-urgent"> · {m.urgentCount} priority</span>}
                      {m.escalatedCount > 0 && <span className="wl-escalated"> · {m.escalatedCount} escalated</span>}
                      {!m.autoAssignEnabled && <span className="wl-paused"> · Paused (out)</span>}
                    </div>
                  </div>

                  <div className="spacer" />

                  <div className="wl-controls" onClick={(e) => e.stopPropagation()}>
                    <div className="wl-control">
                      <span className="wl-control-label">Capacity</span>
                      <select
                        className="select wl-cap"
                        value={m.capacity}
                        onChange={(e) => setCapacity(m, e.target.value as Capacity)}
                        title="Relative weight for auto-distribution"
                      >
                        <option value="light">Light</option>
                        <option value="regular">Regular</option>
                        <option value="heavy">Heavy</option>
                      </select>
                    </div>
                    <div className="wl-control">
                      <span className="wl-control-label">Auto-assign</span>
                      <button
                        className={`switch${m.autoAssignEnabled ? " on" : ""}`}
                        onClick={() => !m.effectiveOut && toggleAuto(m)}
                        disabled={m.effectiveOut}
                        title={
                          m.effectiveOut
                            ? "Out of office — overrides auto-assign"
                            : m.autoAssignEnabled
                              ? "Auto-assign ON — click to pause"
                              : "Auto-assign OFF — click to resume"
                        }
                        style={m.effectiveOut ? { opacity: 0.4, cursor: "not-allowed" } : undefined}
                      >
                        <span className="switch-knob" />
                      </button>
                    </div>
                  </div>
                </div>

                {isOpen && (
                  <div className="wl-drill">
                    {memberLetters.length === 0 ? (
                      <p className="muted" style={{ fontSize: ".85rem", margin: ".4rem 0 .2rem" }}>
                        No open letters assigned.
                      </p>
                    ) : (
                      <>
                        <div className="search-wrap" style={{ maxWidth: "100%", marginBottom: ".6rem" }}>
                          <Search className="ic" />
                          <input
                            className="input"
                            placeholder="Search policy #, insured, carrier, loan #"
                            value={drillSearch}
                            onChange={(e) => setDrillSearch(e.target.value)}
                          />
                        </div>
                        {(() => {
                          const q = drillSearch.trim().toLowerCase();
                          const rows = q
                            ? memberLetters.filter((l) =>
                                [l.policy_number, l.insured_name, l.carrier, l.loan_number].some((v) =>
                                  (v ?? "").toLowerCase().includes(q)
                                )
                              )
                            : memberLetters;
                          if (rows.length === 0) {
                            return (
                              <p className="muted" style={{ fontSize: ".85rem", margin: ".4rem 0 .2rem" }}>
                                No letters match “{drillSearch}”.
                              </p>
                            );
                          }
                          return (
                            <div className="wl-drill-scroll">
                              <table className="data">
                                <thead>
                                  <tr>
                                    <th>Next action</th>
                                    <th>Policy #</th>
                                    <th>Insured</th>
                                    <th>Status</th>
                                    <th>Carrier</th>
                                    <th>Premium</th>
                                    <th>Priority</th>
                                    <th>Reassign to</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {rows.map((l) => {
                                    const flag = reviewFlag(l);
                                    return (
                                      <tr key={l.id} className={l.escalated ? "row-escalated" : undefined}>
                                        <td className="cell-muted" style={{ cursor: "pointer" }} onClick={() => navigate(`/letters/${l.id}`)}>
                                          {date(l.task_date)}
                                        </td>
                                        <td className="cell-muted" style={{ cursor: "pointer" }} onClick={() => navigate(`/letters/${l.id}`)}>
                                          {text(l.policy_number)}
                                        </td>
                                        <td className="cell-strong" style={{ cursor: "pointer" }} onClick={() => navigate(`/letters/${l.id}`)}>
                                          {text(l.insured_name)}
                                          <div className="cell-muted">{letterTypeLabel(l.letter_type)}</div>
                                        </td>
                                        <td>{flag && <span className={`badge ${flag.badgeClass}`}>{flag.label}</span>}</td>
                                        <td>{text(l.carrier)}</td>
                                        <td>{money(l.total_premium)}</td>
                                        <td onClick={(e) => e.stopPropagation()}>
                                          <button
                                            className={`tag-pill ${l.priority === "high" ? "high" : "normal"}`}
                                            disabled={busy}
                                            title={
                                              l.priority === "high"
                                                ? "Priority: High — click to set Normal"
                                                : "Priority: Normal — click to set High"
                                            }
                                            onClick={() => togglePriority(l)}
                                          >
                                            {l.priority === "high" ? "High" : "Normal"}
                                          </button>
                                        </td>
                                        <td onClick={(e) => e.stopPropagation()}>
                                          <select
                                            className="select"
                                            style={{ width: "auto" }}
                                            value=""
                                            disabled={busy}
                                            onChange={(e) => e.target.value && reassign(l, e.target.value)}
                                          >
                                            <option value="">Move to…</option>
                                            <option value="auto">Auto (balance)</option>
                                            {members
                                              .filter((o) => o.id !== m.id)
                                              .map((o) => (
                                                <option key={o.id} value={o.id}>
                                                  {o.fullName ?? o.email}
                                                </option>
                                              ))}
                                          </select>
                                        </td>
                                      </tr>
                                    );
                                  })}
                                </tbody>
                              </table>
                            </div>
                          );
                        })()}
                      </>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </>
  );
}
