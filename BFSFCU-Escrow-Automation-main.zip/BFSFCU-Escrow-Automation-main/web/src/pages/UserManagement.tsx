import { useEffect, useState } from "react";
import { Users, ShieldCheck, CheckCircle2, AlertTriangle, Plus, KeyRound, RefreshCw, Copy, Trash2, X } from "lucide-react";
import { usersApi, settingsApi, integrationsApi, type SsoConfig, type ApiKeyStatus } from "@/services";
import type { AppUserRow, AppRole } from "@/types/letter";
import { roleLabel } from "@/lib/roles";

type Tab = "users" | "sso" | "api";

export default function UserManagement() {
  const [tab, setTab] = useState<Tab>("users");

  const tabBtn = (id: Tab, Icon: typeof Users, label: string) => (
    <button className={`tab${tab === id ? " active" : ""}`} onClick={() => setTab(id)}>
      <Icon className="ic" /> {label}
    </button>
  );

  return (
    <>
      <h1 className="page-title">
        <Users style={{ width: 24, height: 24 }} /> User Management
      </h1>
      <p className="page-sub">Manage accounts, single sign-on, and machine access.</p>

      <div className="tabbar">
        {tabBtn("users", Users, "Users")}
        {tabBtn("sso", ShieldCheck, "Single Sign-On")}
        {tabBtn("api", KeyRound, "API Access")}
      </div>

      {tab === "users" && <UsersCard />}
      {tab === "sso" && <SsoCard />}
      {tab === "api" && <ApiAccessCard />}
    </>
  );
}

// ---------------------------------------------------------------------------
function UsersCard() {
  const [users, setUsers] = useState<AppUserRow[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [role, setRole] = useState<AppRole>("user");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  // Soft-delete confirmation (delete = deactivate + redistribute their letters).
  const [confirmUser, setConfirmUser] = useState<AppUserRow | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  // Only show active accounts — deactivated users are hidden from the list.
  const load = () =>
    usersApi.list().then((r) => setUsers(r.users.filter((u) => u.isActive))).catch(() => undefined);
  useEffect(() => {
    load();
  }, []);

  // The app must always keep at least one manager — the last one can't be deleted.
  const activeManagers = users.filter((u) => u.role === "admin").length;

  const openAdd = () => {
    setError(null);
    setEmail("");
    setFullName("");
    setPassword("");
    setRole("user");
    setShowAdd(true);
  };

  const add = async () => {
    setError(null);
    setBusy(true);
    try {
      await usersApi.create({ email: email.trim(), fullName: fullName.trim(), role, password });
      setShowAdd(false);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not create user");
    } finally {
      setBusy(false);
    }
  };

  const changeRole = async (id: string, r: AppRole) => {
    await usersApi.update(id, { role: r });
    load();
  };
  // "Delete" is a soft delete — deactivate the account and auto-distribute its
  // open letters. The backend refuses to remove the last active manager.
  const remove = async () => {
    if (!confirmUser) return;
    setDeleting(true);
    setDeleteError(null);
    try {
      await usersApi.remove(confirmUser.id);
      setConfirmUser(null);
      load();
    } catch (err) {
      setDeleteError(err instanceof Error ? err.message : "Could not delete user");
    } finally {
      setDeleting(false);
    }
  };

  return (
    <>
    <div className="card">
      <div
        className="card-header"
        style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: "1rem" }}
      >
        <div>
          <h2 className="card-title">Users</h2>
          <p className="card-desc">
            Managers oversee the team and settings; Escrow Admins review and accept the letters assigned to
            them. Capacity and auto-assignment are managed in Team Workload.
          </p>
        </div>
        <button className="btn btn-primary btn-sm" onClick={openAdd} style={{ flexShrink: 0, whiteSpace: "nowrap" }}>
          <Plus className="ic" /> Add user
        </button>
      </div>
      <div className="card-content flush">
        <div className="table-wrap">
          <table className="data">
            <thead>
              <tr>
                <th>Email</th>
                <th>Name</th>
                <th>Sign-in</th>
                <th>Role</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => {
                const lastManager = u.role === "admin" && activeManagers <= 1;
                return (
                  <tr key={u.id} style={{ cursor: "default" }}>
                    <td className="cell-strong">{u.email}</td>
                    <td>{u.fullName ?? "—"}</td>
                    <td className="cell-muted">{u.authProvider}</td>
                    <td onClick={(e) => e.stopPropagation()}>
                      <select
                        className="select"
                        style={{ width: "auto" }}
                        value={u.role}
                        onChange={(e) => changeRole(u.id, e.target.value as AppRole)}
                      >
                        <option value="user">{roleLabel("user")}</option>
                        <option value="admin">{roleLabel("admin")}</option>
                      </select>
                    </td>
                    <td onClick={(e) => e.stopPropagation()} style={{ textAlign: "right" }}>
                      <button
                        className="btn btn-ghost btn-sm"
                        title={lastManager ? "At least one manager is required" : "Delete user"}
                        aria-label="Delete user"
                        disabled={lastManager}
                        style={{
                          color: lastManager ? "var(--muted-foreground)" : "var(--destructive)",
                          opacity: lastManager ? 0.45 : 1,
                        }}
                        onClick={() => {
                          setDeleteError(null);
                          setConfirmUser(u);
                        }}
                      >
                        <Trash2 style={{ width: 16, height: 16 }} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>

    {confirmUser && (
      <div className="modal-overlay" onClick={() => !deleting && setConfirmUser(null)}>
        <div className="modal" style={{ maxWidth: 440 }} onClick={(e) => e.stopPropagation()}>
          <div className="modal-header">
            <h2 className="card-title">Delete user?</h2>
            <button className="modal-close" onClick={() => !deleting && setConfirmUser(null)} aria-label="Close">
              <X style={{ width: 15, height: 15 }} />
            </button>
          </div>
          <div className="modal-body">
            <p style={{ fontSize: ".9rem", marginTop: 0 }}>
              This deactivates <strong>{confirmUser.email}</strong> — they can no longer sign in and are
              removed from this list. Any open letters assigned to them are auto-distributed to the rest of
              the team; their history is kept.
            </p>
            {deleteError && (
              <div className="banner error" style={{ marginTop: ".6rem" }}>
                <AlertTriangle className="ic" />
                {deleteError}
              </div>
            )}
            <div className="row" style={{ justifyContent: "flex-end", marginTop: "1rem" }}>
              <button className="btn btn-ghost" onClick={() => setConfirmUser(null)} disabled={deleting}>
                Cancel
              </button>
              <button className="btn btn-destructive-outline" onClick={remove} disabled={deleting}>
                <Trash2 className="ic" /> {deleting ? "Deleting…" : "Delete user"}
              </button>
            </div>
          </div>
        </div>
      </div>
    )}

    {showAdd && (
      <div className="modal-overlay">
        <div className="modal" style={{ maxWidth: 460 }}>
          <div className="modal-header">
            <h2 className="card-title">Add user</h2>
            <button className="modal-close" onClick={() => !busy && setShowAdd(false)} aria-label="Close">
              <X style={{ width: 15, height: 15 }} />
            </button>
          </div>
          <div className="modal-body">
            {error && (
              <div className="banner error" style={{ marginBottom: ".8rem" }}>
                <AlertTriangle className="ic" />
                {error}
              </div>
            )}
            <div className="field-group">
              <label>Email</label>
              <input className="input" value={email} onChange={(e) => setEmail(e.target.value)} autoFocus />
            </div>
            <div className="field-group">
              <label>Full name</label>
              <input className="input" value={fullName} onChange={(e) => setFullName(e.target.value)} />
            </div>
            <div className="field-group">
              <label>Role</label>
              <select className="select" value={role} onChange={(e) => setRole(e.target.value as AppRole)}>
                <option value="user">{roleLabel("user")}</option>
                <option value="admin">{roleLabel("admin")}</option>
              </select>
            </div>
            <div className="field-group">
              <label>Temp password</label>
              <input
                className="input"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <div className="row" style={{ justifyContent: "flex-end", marginTop: "1rem" }}>
              <button className="btn btn-ghost" onClick={() => setShowAdd(false)} disabled={busy}>
                Cancel
              </button>
              <button className="btn btn-primary" onClick={add} disabled={busy}>
                <Plus className="ic" /> {busy ? "Adding…" : "Add user"}
              </button>
            </div>
          </div>
        </div>
      </div>
    )}
    </>
  );
}

// ---------------------------------------------------------------------------
function SsoCard() {
  const [cfg, setCfg] = useState<SsoConfig>({ enabled: false, tenantId: "", clientId: "" });
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    settingsApi.getSso().then(setCfg).catch(() => undefined);
  }, []);

  const save = async () => {
    setError(null);
    setSaved(false);
    try {
      const updated = await settingsApi.putSso({
        enabled: cfg.enabled,
        tenantId: cfg.tenantId?.trim() || null,
        clientId: cfg.clientId?.trim() || null,
      });
      setCfg(updated);
      setSaved(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save");
    }
  };

  return (
    <div className="card">
      <div className="card-header">
        <h2 className="card-title">
          <ShieldCheck style={{ width: 16, height: 16 }} /> Single Sign-On (Microsoft Entra)
        </h2>
        <p className="card-desc">
          Public client (PKCE) — no secret is stored. Users must already have an account (match-existing-only).
        </p>
      </div>
      <div className="card-content">
        {error && <div className="banner error"><AlertTriangle className="ic" />{error}</div>}
        {saved && <div className="banner info"><CheckCircle2 className="ic" />Saved.</div>}
        <label className="row" style={{ marginBottom: ".8rem", cursor: "pointer" }}>
          <input
            className="checkbox"
            type="checkbox"
            checked={cfg.enabled}
            onChange={(e) => setCfg({ ...cfg, enabled: e.target.checked })}
          />
          Offer "Sign in with Microsoft" on the login page
        </label>
        <div className="grid grid-2">
          <div className="field-group">
            <label>Directory (tenant) ID</label>
            <input className="input" value={cfg.tenantId ?? ""} onChange={(e) => setCfg({ ...cfg, tenantId: e.target.value })} />
          </div>
          <div className="field-group">
            <label>Application (client) ID</label>
            <input className="input" value={cfg.clientId ?? ""} onChange={(e) => setCfg({ ...cfg, clientId: e.target.value })} />
          </div>
        </div>
        <button className="btn btn-primary" onClick={save}>Save SSO settings</button>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
function ApiAccessCard() {
  const [status, setStatus] = useState<ApiKeyStatus | null>(null);
  const [rawKey, setRawKey] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = () => integrationsApi.getKey().then(setStatus).catch(() => undefined);
  useEffect(() => {
    load();
  }, []);

  const rotate = async () => {
    setBusy(true);
    setError(null);
    setRawKey(null);
    try {
      const r = await integrationsApi.rotateKey();
      setRawKey(r.key);
      setConfirming(false);
      load();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not rotate the key");
    } finally {
      setBusy(false);
    }
  };

  const copy = async () => {
    if (!rawKey) return;
    try {
      await navigator.clipboard.writeText(rawKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* clipboard may be unavailable */
    }
  };

  return (
    <div className="card">
      <div className="card-header">
        <h2 className="card-title">
          <KeyRound style={{ width: 16, height: 16 }} /> Power Automate API Key
        </h2>
        <p className="card-desc">
          A machine key for the Power Automate flow that forwards emailed letters. Send it as the{" "}
          <code>X-Api-Key</code> header when posting to <code>/api/letters</code>. Only a hash is stored —
          the key is shown once, here, at rotation.
        </p>
      </div>
      <div className="card-content">
        {error && <div className="banner error"><AlertTriangle className="ic" />{error}</div>}

        {status && !status.accountExists ? (
          <div className="banner"><AlertTriangle className="ic" />Service account not found — apply database migrations.</div>
        ) : (
          <>
            <div className="grid grid-2" style={{ marginBottom: "1rem" }}>
              <div className="field-group" style={{ marginBottom: 0 }}>
                <p className="field-label">Status</p>
                <p className="field-value">
                  {status?.configured ? (
                    <span className="badge badge-success">Active</span>
                  ) : (
                    <span className="badge badge-muted">No key yet</span>
                  )}
                </p>
              </div>
              <div className="field-group" style={{ marginBottom: 0 }}>
                <p className="field-label">Key prefix</p>
                <p className="field-value mono">{status?.prefix ? `${status.prefix}…` : "—"}</p>
              </div>
            </div>

            {rawKey && (
              <div className="banner info" style={{ display: "block" }}>
                <div className="row" style={{ marginBottom: ".4rem" }}>
                  <CheckCircle2 className="ic" />
                  <strong>New key — copy it now. It will not be shown again.</strong>
                </div>
                <div className="key-box">
                  <code>{rawKey}</code>
                  <button className="btn btn-outline btn-sm" onClick={copy}>
                    <Copy className="ic" /> {copied ? "Copied" : "Copy"}
                  </button>
                </div>
              </div>
            )}

            {confirming ? (
              <div className="banner">
                <AlertTriangle className="ic" />
                <span>
                  Rotating revokes the current key immediately — any flow using it stops working until updated.
                </span>
                <button className="btn btn-primary btn-sm" onClick={rotate} disabled={busy} style={{ marginLeft: "auto" }}>
                  {busy ? "Rotating…" : "Confirm rotate"}
                </button>
                <button className="btn btn-ghost btn-sm" onClick={() => setConfirming(false)} disabled={busy}>
                  Cancel
                </button>
              </div>
            ) : (
              <button className="btn btn-primary" onClick={() => setConfirming(true)}>
                <RefreshCw className="ic" /> {status?.configured ? "Rotate key" : "Generate key"}
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
}
