import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ShieldCheck,
  ListTodo,
  Flag,
  ArrowUp,
  Users,
  FileWarning,
  FileSearch,
  Search,
} from "lucide-react";
import { lettersApi } from "@/services";
import type { Letter, NavCounts } from "@/types/letter";
import { useAuth } from "@/hooks/useAuth";
import { letterTypeLabel, reviewCategory, pipelineCategory, PIPELINE_BADGE } from "@/lib/letterStatus";
import { money, date, dateTime, text } from "@/lib/format";
import TeamWorkload from "@/pages/TeamWorkload";
import Escalations from "@/pages/Escalations";

/** The Escrow Admin's queue filter — one per stat tile. */
type QueueFilter = "no_action" | "action" | "in_review" | "escalated";
/** The Manager's in-page view — one per stat tile. */
type ManagerView = "workload" | "escalations" | "attention";
const FILTER_LABEL: Record<QueueFilter, string> = {
  no_action: "No Action Required",
  action: "Action Required",
  in_review: "In Review",
  escalated: "Escalated",
};

export default function Dashboard() {
  const navigate = useNavigate();
  const { isManager, user } = useAuth();
  const [counts, setCounts] = useState<NavCounts | null>(null);

  // Escrow Admin
  const [myLetters, setMyLetters] = useState<Letter[]>([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<QueueFilter>("action");
  // Manager — which in-page view the tiles select + all letters (both sources)
  // to bucket into Tasks Need Attention.
  const [managerView, setManagerView] = useState<ManagerView>("workload");
  const [allLetters, setAllLetters] = useState<Letter[]>([]);

  useEffect(() => {
    lettersApi.navCounts().then(setCounts).catch(() => undefined);
    if (isManager) {
      lettersApi.list({ limit: 200 }).then((r) => setAllLetters(r.letters)).catch(() => undefined);
    } else {
      lettersApi
        .list({ status: ["high_confidence", "task", "low_confidence"], escalatedFirst: true, limit: 200 })
        .then((r) => setMyLetters(r.letters))
        .catch(() => undefined);
    }
  }, [isManager]);

  // ---- Escrow Admin view ----
  if (!isManager) {
    const noAction = myLetters.filter((l) => reviewCategory(l) === "no_action").length;
    const actionRequired = myLetters.filter((l) => reviewCategory(l) === "action").length;
    const inReview = myLetters.filter((l) => reviewCategory(l) === "in_review").length;
    const escalated = myLetters.filter((l) => l.escalated).length;

    // A stat tile that filters the queue below (instead of navigating).
    const filterTile = (
      key: QueueFilter,
      tone: string,
      Icon: typeof ShieldCheck,
      label: string,
      caption: string,
      value: number
    ) => (
      <div
        className={`card stat-tile ${tone}${filter === key ? " selected" : ""}`}
        onClick={() => setFilter(key)}
        role="button"
        aria-pressed={filter === key}
      >
        <div className="tile-top">
          <div>
            <p className="tile-label">{label}</p>
            <p className="tile-caption">{caption}</p>
          </div>
          <Icon className="ic" />
        </div>
        <p className="tile-value">{value}</p>
      </div>
    );

    const q = search.trim().toLowerCase();
    const queue = myLetters
      .filter((l) => (filter === "escalated" ? l.escalated : reviewCategory(l) === filter))
      .filter(
        (l) =>
          !q ||
          [l.insured_name, l.carrier, l.policy_number, l.loan_number, l.property_address].some((v) =>
            (v ?? "").toLowerCase().includes(q)
          )
      );

    return (
      <>
        <h1 className="page-title">Tasks</h1>
        <p className="page-sub">
          Welcome{user?.fullName ? `, ${user.fullName.split(" ")[0]}` : ""} — here's what's assigned to you.
        </p>

        <div className="grid grid-4" style={{ marginBottom: "1.5rem" }}>
          {filterTile("no_action", "tone-success", ShieldCheck, "No Action Required", "Clean matches to accept", noAction)}
          {filterTile("action", "tone-warning", ListTodo, "Action Required", "Scanned — data needs a check", actionRequired)}
          {filterTile("in_review", "", FileSearch, "In Review", "Scan / match not confirmed", inReview)}
          {filterTile("escalated", escalated ? "tone-destructive" : "", Flag, "Escalated", "Flagged to your manager", escalated)}
        </div>

        <div className="card">
          <div className="card-header">
            <div className="row" style={{ justifyContent: "space-between", alignItems: "flex-start", gap: "1rem", flexWrap: "wrap" }}>
              <div>
                <h2 className="card-title">
                  <ListTodo style={{ width: 18, height: 18 }} /> {FILTER_LABEL[filter]}
                </h2>
                <p className="card-desc">
                  Showing {FILTER_LABEL[filter].toLowerCase()} letters assigned to you. Pick a tile above to switch.
                </p>
              </div>
              <div className="search-wrap" style={{ maxWidth: 320 }}>
                <Search className="ic" />
                <input
                  className="input"
                  placeholder="Search insured, carrier, policy #, loan #, address"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </div>
          </div>
          <div className="card-content flush">
            {myLetters.length === 0 ? (
              <div className="empty-state">Nothing assigned to you. Enjoy the quiet.</div>
            ) : queue.length === 0 ? (
              <div className="empty-state">
                {q ? `No matches in ${FILTER_LABEL[filter]} for “${search}”.` : `Nothing in ${FILTER_LABEL[filter]} right now.`}
              </div>
            ) : (
              <div className="table-wrap">
                <table className="data">
                  <thead>
                    <tr>
                      <th>Next action</th>
                      <th>Insured</th>
                      <th>Policy #</th>
                      <th>Type</th>
                      <th>Carrier</th>
                      <th>Premium</th>
                    </tr>
                  </thead>
                  <tbody>
                    {queue.map((l) => (
                      <tr
                        key={l.id}
                        className={l.escalated ? "row-escalated" : undefined}
                        onClick={() => navigate(`/letters/${l.id}`)}
                      >
                        <td className="cell-muted">{date(l.task_date)}</td>
                        <td className="cell-strong">
                          {l.priority === "high" && (
                            <span className="badge badge-priority" style={{ marginRight: ".4rem" }}>
                              <ArrowUp style={{ width: 12, height: 12 }} /> High
                            </span>
                          )}
                          {l.escalated && (
                            <span className="badge badge-destructive" style={{ marginRight: ".4rem" }}>
                              <Flag style={{ width: 12, height: 12 }} /> Escalated
                            </span>
                          )}
                          {text(l.insured_name)}
                        </td>
                        <td className="cell-muted">{text(l.policy_number)}</td>
                        <td>{letterTypeLabel(l.letter_type)}</td>
                        <td>{text(l.carrier)}</td>
                        <td>{money(l.total_premium)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </>
    );
  }

  // ---- Manager view ----
  const escalations = counts?.escalations ?? 0;
  // Both intake sources land in one `letters` table — bucket every letter by its
  // pipeline status so Tasks Need Attention covers inbox + upload.
  const needAttention = allLetters.filter((l) => {
    const c = pipelineCategory(l);
    return c === "stuck" || c === "failed";
  });

  // A stat tile that selects an in-page view instead of navigating — the same
  // pattern as the Escrow Admin queue.
  const viewTile = (
    key: ManagerView,
    tone: string,
    Icon: typeof ShieldCheck,
    label: string,
    caption: string,
    value: number | undefined
  ) => (
    <div
      className={`card stat-tile ${tone}${managerView === key ? " selected" : ""}`}
      onClick={() => setManagerView(key)}
      role="button"
      aria-pressed={managerView === key}
    >
      <div className="tile-top">
        <div>
          <p className="tile-label">{label}</p>
          <p className="tile-caption">{caption}</p>
        </div>
        <Icon className="ic" />
      </div>
      <p className="tile-value">{value ?? "—"}</p>
    </div>
  );

  // An in-page table of letters (used by Tasks Need Attention) —
  // shows both inbox and upload files, with the shared pipeline status.
  const filesTable = (rows: Letter[], emptyMsg: string) => (
    <div className="card">
      <div className="card-content flush">
        {rows.length === 0 ? (
          <div className="empty-state">{emptyMsg}</div>
        ) : (
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th>Policy #</th>
                  <th>Insured / File</th>
                  <th>Status</th>
                  <th>Type</th>
                  <th>Carrier</th>
                  <th>Assigned to</th>
                  <th>Received</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((l) => {
                  const cat = PIPELINE_BADGE[pipelineCategory(l)];
                  return (
                    <tr key={l.id} onClick={() => navigate(`/letters/${l.id}`)} style={{ cursor: "pointer" }}>
                      <td className="cell-muted">{text(l.policy_number)}</td>
                      <td className="cell-strong">
                        {text(l.insured_name) !== "—" ? text(l.insured_name) : text(l.original_filename)}
                      </td>
                      <td><span className={`badge ${cat.cls}`}>{cat.label}</span></td>
                      <td>{letterTypeLabel(l.letter_type)}</td>
                      <td>{text(l.carrier)}</td>
                      <td className="cell-muted">{text(l.assigned_to_name)}</td>
                      <td className="cell-muted">{dateTime(l.created_at)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <>
      <h1 className="page-title">Tasks</h1>
      <p className="page-sub">Team oversight — workload balance and the automated intake pipeline.</p>

      <div className="grid grid-3" style={{ marginBottom: "1.5rem" }}>
        {viewTile("workload", "", Users, "Team Workload", "Tasks in Progress", counts?.teamOpen)}
        {viewTile("escalations", escalations > 0 ? "tone-destructive" : "", Flag, "Escalations", "Escalated by your team", escalations)}
        {viewTile("attention", needAttention.length > 0 ? "tone-warning" : "", FileWarning, "Tasks Need Attention", "Stuck or failed", needAttention.length)}
      </div>

      {managerView === "workload" && <TeamWorkload embedded />}
      {managerView === "escalations" && <Escalations embedded />}
      {managerView === "attention" && filesTable(needAttention, "Nothing needs attention right now.")}
    </>
  );
}
