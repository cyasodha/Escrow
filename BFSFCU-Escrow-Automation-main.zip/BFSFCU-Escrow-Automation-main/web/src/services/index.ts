/** Typed API calls for the escrow domain. Built on the low-level client. */

import { api } from "@/lib/api";
import type { SessionUser } from "@/lib/api";
import type {
  Letter,
  StatusCounts,
  LetterStatus,
  LetterSource,
  AppUserRow,
  AppRole,
  Capacity,
  AuditEntry,
  NoteEntry,
  NavCounts,
  TeamWorkload,
  InboxTiles,
  TaskMetrics,
  Manager,
} from "@/types/letter";

function joinList(v?: string | readonly string[]): string | undefined {
  if (!v) return undefined;
  return Array.isArray(v) ? v.join(",") : (v as string);
}

export const lettersApi = {
  list: (
    params: {
      status?: LetterStatus | readonly LetterStatus[];
      source?: LetterSource | readonly LetterSource[];
      assigned?: string; // 'me' or a user id (Manager only)
      escalatedFirst?: boolean;
      escalatedOnly?: boolean; // Manager only — priority/escalation queue
      search?: string;
      limit?: number;
      offset?: number;
    } = {}
  ) =>
    api.get<{ letters: Letter[] }>("/letters", {
      ...(joinList(params.status) ? { status: joinList(params.status) } : {}),
      ...(joinList(params.source) ? { source: joinList(params.source) } : {}),
      ...(params.assigned ? { assigned: params.assigned } : {}),
      ...(params.escalatedFirst ? { escalatedFirst: "1" } : {}),
      ...(params.escalatedOnly ? { escalated: "1" } : {}),
      ...(params.search ? { search: params.search } : {}),
      ...(params.limit ? { limit: params.limit } : {}),
      ...(params.offset ? { offset: params.offset } : {}),
    }),
  get: (id: string) => api.get<Letter>(`/letters/${id}`),
  fileUrl: (id: string) => api.get<{ url: string; expiresInMinutes: number }>(`/letters/${id}/file`),
  stats: () => api.get<StatusCounts>("/letters-stats"),
  navCounts: () => api.get<NavCounts>("/nav-counts"),

  upload: (file: File, onProgress?: (pct: number) => void, signal?: AbortSignal) => {
    const fd = new FormData();
    fd.append("file", file);
    return api.uploadWithProgress<{ letterId: string; status: string }>("/letters", fd, onProgress, signal);
  },

  updateDetails: (id: string, fields: Record<string, string>) =>
    api.patch<{ id: string }>(`/letters/${id}/details`, fields),

  moveTaskDate: (id: string, taskDate: string, note: string) =>
    api.patch<{ id: string; taskDate: string }>(`/letters/${id}/task-date`, { taskDate, note }),

  approve: (id: string, note?: string) => api.post<{ id: string; status: string }>(`/letters/${id}/approve`, { note }),
  decline: (id: string, reason: string) => api.post<{ id: string; status: string }>(`/letters/${id}/decline`, { reason }),
  moveToTask: (id: string, reason: string) => api.post<{ id: string; status: string }>(`/letters/${id}/move-to-task`, { reason }),
  returnToReview: (id: string, reason?: string, target?: "high_confidence" | "low_confidence") =>
    api.post<{ id: string; status: string }>(`/letters/${id}/return-to-review`, { target, reason }),

  // Manager-only
  assign: (id: string, to: string | "auto") =>
    api.post<{ id: string; assignedTo: string | null }>(`/letters/${id}/assign`, { to }),
  escalate: (id: string, escalated: boolean, note: string, escalatedTo?: string) =>
    api.post<{ id: string; escalated: boolean }>(`/letters/${id}/escalate`, { escalated, note, escalatedTo }),
  setPriority: (id: string, priority: "normal" | "high") =>
    api.post<{ id: string; priority: "normal" | "high" }>(`/letters/${id}/priority`, { priority }),

  notes: (id: string) => api.get<{ notes: NoteEntry[] }>(`/letters/${id}/notes`),
  addNote: (id: string, body: string) => api.post<NoteEntry>(`/letters/${id}/notes`, { body }),
  audit: (id: string) => api.get<{ entries: AuditEntry[] }>(`/letters/${id}/audit`),
};

export const teamApi = {
  workload: () => api.get<TeamWorkload>("/team-workload"),
};

export const managersApi = {
  // Active managers, for the escalate "assign to" picker (any authenticated user).
  list: () => api.get<{ managers: Manager[] }>("/managers"),
};

export const metricsApi = {
  // assigned: an Escrow Admin's user id to scope by, or omit / "all" for everyone.
  get: (assigned?: string) =>
    api.get<{ metrics: TaskMetrics }>("/metrics", assigned && assigned !== "all" ? { assigned } : undefined),
};

export const inboxApi = {
  list: (search?: string) =>
    api.get<{ letters: Letter[]; tiles: InboxTiles }>("/inbox", search ? { search } : undefined),
};

export const meApi = {
  setAvailability: (autoAssignEnabled: boolean) =>
    api.patch<SessionUser>("/me/availability", { autoAssignEnabled }),
};

export const usersApi = {
  list: () => api.get<{ users: AppUserRow[] }>("/users"),
  create: (input: {
    email: string;
    fullName: string;
    role: AppRole;
    password: string;
    capacity?: Capacity;
  }) => api.post<AppUserRow>("/users", input),
  update: (
    id: string,
    fields: {
      role?: AppRole;
      isActive?: boolean;
      capacity?: Capacity;
      autoAssignEnabled?: boolean;
    }
  ) => api.patch<AppUserRow>(`/users/${id}`, fields),
  /** Soft delete: deactivate + redistribute the user's open letters. */
  remove: (id: string) =>
    api.delete<{ ok: boolean; redistributed: number; unassigned: number }>(`/users/${id}`),
};

export const auditApi = {
  recent: (limit = 100) => api.get<{ entries: AuditEntry[] }>("/audit", { limit }),
};

// ---- Machine access (Power Automate API key) ----
export interface ApiKeyStatus {
  accountExists: boolean;
  configured: boolean;
  prefix?: string | null;
  createdAt?: string | null;
  lastUsedAt?: string | null;
}

export const integrationsApi = {
  getKey: () => api.get<ApiKeyStatus>("/integrations/power-automate/key"),
  rotateKey: () => api.post<{ key: string; prefix: string }>("/integrations/power-automate/key"),
};

// ---- Demo mode ----
export const demoApi = {
  config: () => api.get<{ enabled: boolean }>("/demo/config"),
  reset: () => api.post<{ ok: boolean }>("/demo/reset"),
};

// ---- Admin settings ----
export interface SsoConfig {
  enabled: boolean;
  tenantId: string | null;
  clientId: string | null;
}
export interface OracleConfig {
  enabled: boolean;
  host: string | null;
  port: number;
  serviceName: string | null;
  user: string | null;
  passwordConfigured?: boolean;
}

/** Business calendar (working days/hours + timezone). */
export interface ScheduleConfig {
  workDays: number[]; // ISO 1=Mon..7=Sun
  workStart: string; // 'HH:MM'
  workCutoff: string; // 'HH:MM'
  timezone: string;
  oooSyncEnabled: boolean;
  /** GET only: last OOO-sync date, and whether Graph is enabled. */
  lastRun?: string | null;
  graphConfigured?: boolean;
}

export interface OooSyncResult {
  ran: boolean;
  reason?: string;
  targetDate?: string;
  markedOut?: string[];
  totalAdmins?: number;
}
export interface Holiday {
  id: string;
  date: string; // YYYY-MM-DD
  label: string | null;
  annual: boolean; // recurs every year on this date's month/day
}

export const settingsApi = {
  getSso: () => api.get<SsoConfig>("/settings/sso"),
  putSso: (cfg: SsoConfig) => api.put<SsoConfig>("/settings/sso", cfg),
  getOracle: () => api.get<OracleConfig>("/settings/oracle"),
  putOracle: (cfg: Omit<OracleConfig, "passwordConfigured"> & { password?: string }) =>
    api.put<OracleConfig>("/settings/oracle", cfg),
  testOracle: () => api.post<{ ok: boolean; loanCount: number }>("/settings/oracle/test"),

  getSchedule: () => api.get<ScheduleConfig>("/settings/schedule"),
  putSchedule: (cfg: ScheduleConfig) => api.put<ScheduleConfig>("/settings/schedule", cfg),
  listHolidays: () => api.get<{ holidays: Holiday[] }>("/settings/holidays"),
  addHoliday: (date: string, label: string | null, annual: boolean) =>
    api.post<Holiday>("/settings/holidays", { date, label, annual }),
  deleteHoliday: (id: string) => api.delete<{ id: string }>(`/settings/holidays/${id}`),
  runOooSync: () => api.post<OooSyncResult>("/settings/ooo-sync/run"),
};
