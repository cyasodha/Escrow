/** Human labels for extraction flags and compare flags. */

const LABELS: Record<string, string> = {
  // extraction flags
  letter_type_uncertain: "Letter type uncertain",
  cancellation_subtype_missing: "Cancellation subtype not detected",
  loan_number_missing: "Loan # missing",
  policy_number_missing: "Policy # missing",
  insured_name_missing: "Insured name missing",
  property_address_missing: "Property address missing",
  carrier_missing: "Carrier missing",
  dwelling_coverage_missing: "Dwelling coverage missing",
  total_premium_missing: "Total premium missing",
  policy_period_missing: "Policy period missing",
  non_escrow_document: "Not an escrow letter",
  low_ocr_quality: "Low scan quality",
  possible_duplicate: "Possible duplicate",
  multiple_policies: "One of several policies on this document",
  // compare flags
  premium_change_gt_5pct: "Premium change > 5%",
  coverage_change: "Coverage amount changed",
  carrier_change: "Carrier changed",
  policy_change: "Policy # changed",
  no_insurance_on_file: "No insurance on file",
  no_matching_insurance: "No matching insurance found",
};

export function reasonLabel(flag: string): string {
  return LABELS[flag] ?? flag.replace(/_/g, " ");
}

/** Compare flags that warrant reviewer attention render as warnings. */
export function reasonTone(flag: string): "warning" | "muted" {
  const warn = new Set([
    "premium_change_gt_5pct",
    "carrier_change",
    "policy_change",
    "no_matching_insurance",
    "non_escrow_document",
    "possible_duplicate",
  ]);
  return warn.has(flag) ? "warning" : "muted";
}
