import type { LetterStatus, LetterType, CancellationSubtype, ConfidenceTier } from "@/types/letter";

/** Queue label + badge style for a letter status. */
export function statusLabel(status: LetterStatus): string {
  switch (status) {
    case "queued":
    case "processing":
      return "In Queue";
    case "high_confidence":
      return "No Action Required";
    case "low_confidence":
      return "Action Required";
    case "task":
      return "Action Required";
    case "approved":
      return "Accepted";
    case "rejected":
      return "Declined";
  }
}

/**
 * The status shown in the Audit Trail: the meaningful review outcome, with the
 * exact decision for closed letters. Open letters read as their review category
 * (No Action Required / In Review / Action Required) rather than the internal
 * status name (high_confidence / low_confidence / task), and a closed letter
 * reads as its real decision ("Approved" / "Rejected", not "Accepted").
 */
export function auditStatusLabel(status: LetterStatus): string {
  switch (status) {
    case "queued":
    case "processing":
      return "In Queue";
    case "high_confidence":
      return "No Action Required";
    case "low_confidence":
      return "In Review";
    case "task":
      return "Action Required";
    case "approved":
      return "Accepted";
    case "rejected":
      return "Declined";
  }
}

export function statusBadgeClass(status: LetterStatus): string {
  switch (status) {
    case "high_confidence":
      return "badge-success";
    case "low_confidence":
      return "badge-warning";
    case "task":
      return "badge-warning";
    case "approved":
      return "badge-success";
    case "rejected":
      return "badge-destructive";
    default:
      return "badge-muted";
  }
}

/**
 * The action flag shown on each My Tasks row — whether the letter needs a human
 * or is a clean match the owner can simply accept.
 */
export type FlagTone = "success" | "warning" | "destructive" | "muted";

export function actionFlag(status: LetterStatus): { label: string; tone: FlagTone } | null {
  switch (status) {
    case "high_confidence":
      return { label: "No action needed", tone: "success" };
    case "task":
    case "low_confidence":
      return { label: "Action required", tone: "warning" };
    default:
      return null;
  }
}

/** The three review buckets an open letter can fall into. */
export type ReviewCategory = "no_action" | "action" | "in_review";

/**
 * Bucket an OPEN letter into one of three review categories (null for
 * queued/processing/approved/rejected). This mirrors the API's bucket routing
 * (api/src/shared/pipeline/routing.ts) 1:1 by status:
 *
 *   no_action (high_confidence) — read fine and a 100% match to Core DNA. Accept.
 *   action    (task)            — read fine and identified, but the account /
 *                                 personal data does not 100% match Core DNA (a
 *                                 discrepancy, up to and including no matching
 *                                 loan). Needs a human decision.
 *   in_review (low_confidence)  — could not be read confidently: the scan failed,
 *                                 a key field is missing, it is not an escrow
 *                                 letter, or the type was not identified.
 */
export function reviewCategory(l: { status: LetterStatus }): ReviewCategory | null {
  switch (l.status) {
    case "high_confidence":
      return "no_action";
    case "task":
      return "action";
    case "low_confidence":
      return "in_review";
    default:
      return null;
  }
}

const REVIEW_META: Record<ReviewCategory, { label: string; tone: FlagTone; badgeClass: string }> = {
  no_action: { label: "No action required", tone: "success", badgeClass: "badge-success" },
  action: { label: "Action required", tone: "warning", badgeClass: "badge-warning" },
  in_review: { label: "In review", tone: "muted", badgeClass: "badge-muted" },
};

/** Label + badge tone/class for a letter's review category (null for non-open). */
export function reviewFlag(
  l: { status: LetterStatus }
): { label: string; tone: FlagTone; badgeClass: string; category: ReviewCategory } | null {
  const cat = reviewCategory(l);
  return cat ? { ...REVIEW_META[cat], category: cat } : null;
}

export function tierLabel(tier: ConfidenceTier | null): string {
  if (tier === "high") return "High";
  if (tier === "low") return "Low";
  return "—";
}

export function letterTypeLabel(t: LetterType | null): string {
  if (t === "modification") return "Policy Modification";
  if (t === "cancellation") return "Cancellation";
  return "Unclassified";
}

export function subtypeLabel(s: CancellationSubtype | null): string {
  switch (s) {
    case "nonpayment":
      return "Nonpayment of premium (lapse risk)";
    case "provider_switch":
      return "Written request — replacement bound (provider switch)";
    case "non_renewal":
      return "Non-renewal at expiration (underwriting)";
    default:
      return "";
  }
}

export function matchStatusLabel(m: string | null): string {
  switch (m) {
    case "matched_by_loan":
      return "Matched by loan #";
    case "matched_by_name_address":
      return "Matched by name + address (fallback)";
    case "no_match":
      return "No matching loan found";
    default:
      return "Not matched";
  }
}

/**
 * Pipeline status — the SAME set of options for both the Inbox Monitor and the
 * Upload page, so a letter reads identically in either place. "In Progress" is
 * an open letter working its way through review.
 */
export type PipelineCategory = "processing" | "stuck" | "failed" | "inReview" | "resolved";

const PIPELINE_STUCK_MS = 10 * 60 * 1000;

export function pipelineCategory(l: {
  status: LetterStatus;
  processing_error: string | null;
  created_at: string;
}): PipelineCategory {
  if (l.processing_error) return "failed";
  if (l.status === "queued" || l.status === "processing") {
    return Date.now() - new Date(l.created_at).getTime() > PIPELINE_STUCK_MS ? "stuck" : "processing";
  }
  if (l.status === "approved" || l.status === "rejected") return "resolved";
  return "inReview";
}

export const PIPELINE_BADGE: Record<PipelineCategory, { label: string; cls: string }> = {
  processing: { label: "Processing", cls: "badge-accent" },
  stuck: { label: "Stuck", cls: "badge-warning" },
  failed: { label: "Failed / Exception", cls: "badge-destructive" },
  inReview: { label: "In Progress", cls: "badge-navy" },
  resolved: { label: "Resolved", cls: "badge-success" },
};
