/**
 * Coverage-gap detection between the PREVIOUS policy's end date and the NEW
 * policy's start date.
 *
 * The largest catch here is a break in coverage: the policy on file ends, and
 * the incoming letter's coverage starts on a different date. A back-to-back
 * renewal (new starts the same day or the day after the old ends) is continuous;
 * anything beyond a single day either side is a real gap or overlap.
 *
 *   delta = newStart - prevEnd, in whole days
 *     delta >  1  -> gap of `delta` days (uncovered window)      → flag red
 *     delta < -1  -> overlap of `-delta` days (double coverage)  → flag red
 *     -1..1       -> continuous (same-day / next-day handoff)
 *
 * Dates are the app's YYYY-MM-DD strings; parsing is UTC-based so there is no
 * timezone drift (matches lib/format.ts `date()`).
 */

export type CoverageGap =
  | { kind: "gap"; days: number }
  | { kind: "overlap"; days: number }
  | { kind: "continuous"; days: number }
  | { kind: "unknown" };

/** YYYY-MM-DD(…) → whole UTC day number, or null if unparseable. */
function toUtcDay(value: string): number | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(value);
  if (!m) return null;
  const [, y, mo, d] = m;
  return Math.floor(Date.UTC(Number(y), Number(mo) - 1, Number(d)) / 86_400_000);
}

export function coverageGap(
  prevEnd: string | null | undefined,
  newStart: string | null | undefined
): CoverageGap {
  if (!prevEnd || !newStart) return { kind: "unknown" };
  const a = toUtcDay(prevEnd);
  const b = toUtcDay(newStart);
  if (a === null || b === null) return { kind: "unknown" };
  const delta = b - a;
  if (delta > 1) return { kind: "gap", days: delta };
  if (delta < -1) return { kind: "overlap", days: -delta };
  return { kind: "continuous", days: delta };
}
