/**
 * Role + capacity display labels.
 *
 * The two role VALUES are unchanged ('admin', 'user'); only their labels
 * changed: admin = "Manager", user = "Escrow Admin".
 */
import type { AppRole, Capacity } from "@/types/letter";

const ROLE_LABELS: Record<string, string> = {
  admin: "Manager",
  user: "Escrow Admin",
};

export function roleLabel(role: AppRole | string | null | undefined): string {
  if (!role) return "";
  return ROLE_LABELS[role] ?? role;
}

const CAPACITY_LABELS: Record<Capacity, string> = {
  light: "Light",
  regular: "Regular",
  heavy: "Heavy",
};

export function capacityLabel(capacity: Capacity | string | null | undefined): string {
  if (!capacity) return "";
  return CAPACITY_LABELS[capacity as Capacity] ?? capacity;
}
