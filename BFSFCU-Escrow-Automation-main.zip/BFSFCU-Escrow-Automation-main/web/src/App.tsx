import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  Outlet,
  useOutletContext,
  useLocation,
} from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import Layout from "@/components/Layout";
import Auth from "@/pages/Auth";
import Dashboard from "@/pages/Dashboard";
import Metrics from "@/pages/Metrics";
import TeamWorkload from "@/pages/TeamWorkload";
import Escalations from "@/pages/Escalations";
import InboxMonitor from "@/pages/InboxMonitor";
import LettersQueue from "@/pages/LettersQueue";
import LetterDetail from "@/pages/LetterDetail";
import Upload from "@/pages/Upload";
import UserManagement from "@/pages/UserManagement";
import Connections from "@/pages/Connections";
import Scheduling from "@/pages/Scheduling";
import AuditConsole from "@/pages/AuditConsole";

function ProtectedLayout() {
  const { loading, isAuthenticated } = useAuth();
  const location = useLocation();
  if (loading) {
    return (
      <div className="center-screen">
        <div className="spinner" />
      </div>
    );
  }
  // Remember where the user was headed (e.g. a deep-linked letter) so we can
  // land them there after they sign in, instead of the default dashboard.
  if (!isAuthenticated) {
    return (
      <Navigate
        to="/login"
        replace
        state={{ from: location.pathname + location.search + location.hash }}
      />
    );
  }
  return <Layout />;
}

/** Manager-only branch (role 'admin'). Escrow Admins are bounced to Dashboard. */
function ManagerRoute() {
  const { isManager } = useAuth();
  // Forward the parent Outlet context (refreshCounts) to nested manager pages.
  const ctx = useOutletContext();
  if (!isManager) return <Navigate to="/tasks" replace />;
  return <Outlet context={ctx} />;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Auth />} />

        <Route element={<ProtectedLayout />}>
          <Route path="/" element={<Navigate to="/tasks" replace />} />
          <Route path="/tasks" element={<Dashboard />} />
          {/* Legacy path — keep old bookmarks working. */}
          <Route path="/dashboard" element={<Navigate to="/tasks" replace />} />

          {/* My Tasks was folded into the Dashboard's "Your queue"; keep the path
              working (bookmarks, legacy links) by redirecting to the Dashboard. */}
          <Route path="/my-tasks" element={<Navigate to="/tasks" replace />} />
          <Route
            path="/accepted"
            element={
              <LettersQueue
                status="approved"
                title="Accepted"
                subtitle="Accepted Tasks"
                icon="approved"
              />
            }
          />
          <Route
            path="/declined"
            element={
              <LettersQueue
                status="rejected"
                title="Declined"
                subtitle="Declined Tasks"
                icon="declined"
              />
            }
          />

          <Route path="/letters/:id" element={<LetterDetail />} />
          <Route path="/upload" element={<Upload />} />

          {/* Management — Manager only. */}
          <Route element={<ManagerRoute />}>
            <Route path="/metrics" element={<Metrics />} />
            <Route path="/team-workload" element={<TeamWorkload />} />
            <Route path="/escalations" element={<Escalations />} />
            <Route path="/inbox" element={<InboxMonitor />} />
            <Route path="/user-management" element={<UserManagement />} />
            <Route path="/connections" element={<Connections />} />
            <Route path="/scheduling" element={<Scheduling />} />
            {/* Old direct links now resolve to Connections. */}
            <Route path="/oracle-connection" element={<Navigate to="/connections" replace />} />
            <Route path="/notifications" element={<Navigate to="/connections" replace />} />
            <Route path="/audit" element={<AuditConsole />} />
          </Route>

          {/* Legacy queue paths → Dashboard (the owner's queue). */}
          <Route path="/high-confidence" element={<Navigate to="/tasks" replace />} />
          <Route path="/task" element={<Navigate to="/tasks" replace />} />
          <Route path="/low-confidence" element={<Navigate to="/tasks" replace />} />
          <Route path="/approved" element={<Navigate to="/accepted" replace />} />

          <Route path="*" element={<Navigate to="/tasks" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
