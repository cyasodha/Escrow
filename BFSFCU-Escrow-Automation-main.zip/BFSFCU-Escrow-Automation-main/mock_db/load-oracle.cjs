/**
 * load-oracle.cjs — reload the POC Oracle (loan + insurance_on_file) with the
 * synthetic sample data, WITHOUT needing sqlplus / an Oracle client.
 *
 * Uses the oracledb driver bundled in ../api/node_modules in Thin mode. It
 * drops + recreates the two tables and loads the INSERTs from 02_sample_data.sql,
 * so it also fixes a fresh/restarted container that has the ESCROW_RO user but
 * no tables.
 *
 * Usage (PowerShell) — replace the two values with your real host + password
 * (host is on the app's Admin -> Oracle Connection page; password is the Function
 * App ORACLE_PASSWORD setting):
 *
 *   node mock_db/load-oracle.cjs "your-oracle-host.centralus.azurecontainer.io" "your-oracle-password"
 *
 * Or point it at a local container:  node mock_db/load-oracle.cjs 127.0.0.1 Escrow_ro_pw_123
 */
const path = require('path');
const fs = require('fs');
const oracledb = require(path.join(__dirname, '..', 'api', 'node_modules', 'oracledb'));

const host = process.argv[2] || process.env.ORA_HOST;
const password = process.argv[3] || process.env.ORA_PASSWORD;
const user = process.argv[4] || process.env.ORA_USER || 'ESCROW_RO';
const service = process.env.ORA_SERVICE || 'XEPDB1';

if (!host || !password) {
  console.error('Usage: node mock_db/load-oracle.cjs <host> <password> [user]');
  process.exit(1);
}

const DDL = [
  `BEGIN EXECUTE IMMEDIATE 'DROP TABLE insurance_on_file'; EXCEPTION WHEN OTHERS THEN IF SQLCODE != -942 THEN RAISE; END IF; END;`,
  `BEGIN EXECUTE IMMEDIATE 'DROP TABLE loan'; EXCEPTION WHEN OTHERS THEN IF SQLCODE != -942 THEN RAISE; END IF; END;`,
  `CREATE TABLE loan (
     loan_number VARCHAR2(20) NOT NULL,
     member_name VARCHAR2(120) NOT NULL,
     property_address VARCHAR2(200) NOT NULL,
     mortgage_status VARCHAR2(20) DEFAULT 'ACTIVE' NOT NULL,
     escrow_balance NUMBER(12,2) DEFAULT 0 NOT NULL,
     CONSTRAINT loan_pk PRIMARY KEY (loan_number),
     CONSTRAINT loan_status_ck CHECK (mortgage_status IN ('ACTIVE','PAID_OFF','DELINQUENT','FORECLOSURE'))
   )`,
  `CREATE INDEX loan_name_idx ON loan (UPPER(member_name))`,
  `CREATE INDEX loan_addr_idx ON loan (UPPER(property_address))`,
  `CREATE TABLE insurance_on_file (
     loan_number VARCHAR2(20) NOT NULL,
     carrier VARCHAR2(80) NOT NULL,
     policy_number VARCHAR2(40) NOT NULL,
     policy_type VARCHAR2(40),
     dwelling_coverage NUMBER(12,2),
     premium NUMBER(12,2),
     period_start DATE,
     period_end DATE,
     CONSTRAINT insurance_on_file_pk PRIMARY KEY (loan_number, policy_number),
     CONSTRAINT insurance_on_file_loan_fk FOREIGN KEY (loan_number) REFERENCES loan (loan_number)
   )`,
  `CREATE INDEX insurance_loan_idx ON insurance_on_file (loan_number)`,
];

// Pull the INSERT statements out of 02_sample_data.sql (skip comments, the
// SET DEFINE / DELETE / COMMIT lines, and blank lines).
function dataInserts() {
  const raw = fs.readFileSync(path.join(__dirname, '02_sample_data.sql'), 'utf8');
  return raw
    .split('\n')
    .filter((l) => !l.trim().startsWith('--'))
    .join('\n')
    .split(';')
    .map((s) => s.trim())
    .filter((s) => /^INSERT\s/i.test(s));
}

(async () => {
  const conn = await oracledb.getConnection({ user, password, connectString: `${host}:1521/${service}` });
  try {
    for (const stmt of DDL) await conn.execute(stmt);
    const inserts = dataInserts();
    for (const stmt of inserts) await conn.execute(stmt);
    await conn.commit();
    const r = await conn.execute('SELECT COUNT(*) FROM loan');
    console.log(`Oracle reloaded OK — ${inserts.length} insurance/loan rows, loan count = ${r.rows[0][0]}`);
  } finally {
    await conn.close();
  }
})().catch((e) => {
  console.error('Load failed:', e && e.message ? e.message : e);
  process.exit(1);
});
