# mock_db — the separate Oracle loan database (POC stand-in)

This folder holds the **schema DDL and synthetic sample data** for the credit
union's **Oracle** loan system — a *separate, deployed database*, not part of the
app. The escrow app never writes here; it only reads through a thin, read-only
connector (`api/src/shared/oracle/`). The connection (host / port / service /
user / enabled) is configured from the app's **admin UI** and stored in
`app_settings`; the password comes from `ORACLE_PASSWORD` (Key Vault).

In production this schema belongs to the credit union. For the POC we stand up an
Oracle instance (e.g. Oracle XE / Autonomous / a container) and load this
synthetic copy that matches the real shape — exactly the model the SOW describes
(§6 and Appendix A: "synthetic data that matches the real schema").

## Files (run in order)

| File | Purpose |
|---|---|
| `01_schema.sql` | Create `loan` and `insurance_on_file` (re-runnable). Run as the schema owner. |
| `02_sample_data.sql` | Load the crafted High/Low sample data. |
| `00_readonly_user.sql` | Create the SELECT-only login the app connects as. Run as a DBA **after** `01_schema.sql`. |

```bash
# with SQLcl (or SQL*Plus)
sql escrow_owner/****@//localhost:1521/XEPDB1 @mock_db/01_schema.sql
sql escrow_owner/****@//localhost:1521/XEPDB1 @mock_db/02_sample_data.sql
sql sys/****@//localhost:1521/XEPDB1 as sysdba @mock_db/00_readonly_user.sql
```

## Schema

```
loan(loan_number PK, member_name, property_address, mortgage_status, escrow_balance)
insurance_on_file(loan_number FK, carrier, policy_number, policy_type,
                  dwelling_coverage, premium, period_start, period_end)  PK(loan_number, policy_number)
```

The connector exposes exactly three read operations against this:
`findLoanByNumber`, `findLoanByNameAddress` (fallback), `getInsuranceOnFile`.

## Crafted outcomes

Tiering rule: **High** = 100% match on PII (insured name + property address)
**and** account (loan # + policy #), after normalization. **Low** = anything
less. The sample data is tuned so these six real letters land deterministically
(letter file *names* don't match their *content* — this is by body):

| Insured (letter body) | Type | Oracle setup | Result | Why |
|---|---|---|---|---|
| Patricia Mouton — Allstate `ALS-7729014` | Modification | loan/policy/name/addr all match; premium 2,040→2,268 | **HIGH** | full match; premium change (+11.2%) shown as a flag, not a router |
| Todd Hebert — USAA `USAA-7723458` | Cancellation (provider switch) | all match | **HIGH** | reviewer manually moves to Task for alignment |
| Brian Fontenette — USAA `USAA-4471209` | Cancellation (nonpayment) | all match; escrow 900 < premium 1,640 | **HIGH** | reviewer escalates to Task (lapse risk) |
| Marcus Delahoussaye — Progressive `PGR-6634210` | Modification (new provider) | on file = old State Farm policy | **LOW** | policy # not on file → account match fails |
| Monique Guillory — Liberty Mutual `LM-6612093` | Cancellation (provider switch) | on file = old Allstate policy | **LOW** | policy # not on file → account match fails |
| David Reyes — Allstate `ALS-4471029` | Modification | loan # absent; name+address present | **LOW** | matched by name+address fallback; loan # differs → not 100% |
| Alicia Broussard — Farmers `FI-5561287` | Modification | on file matches exactly | **HIGH** | clean match, no comparison flags |
| William & Cheryl Domingue — State Farm `SF-HO-334298` | Modification | on file dwelling 265k vs letter 242k | **HIGH** | full match; coverage-change flag |
| Robert Castille — USAA `USAA-2209841` | Modification | on file premium 1,890 vs letter 1,675 | **HIGH** | full match; premium-change flag (decrease) |

Every other sample letter (loan # / name+address not loaded here) extracts
normally and lands **Low — no matching record**, which is the expected POC
behaviour for an unrecognised account.
