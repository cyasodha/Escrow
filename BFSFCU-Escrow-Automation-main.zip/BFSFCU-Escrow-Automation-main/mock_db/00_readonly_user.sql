-- 00_readonly_user.sql — create the read-only account the app connects as.
--
-- The escrow app's Oracle connector is READ-ONLY by contract (SOW §6): it writes
-- nothing back to Oracle. Enforce that at the database, not just in code, by
-- giving the app a login with SELECT-only on the two tables.
--
-- Run as a DBA / privileged user AFTER 01_schema.sql has created the tables in
-- the owning schema. Adjust identifiers to your instance.
--   sql sys/****@//host:1521/XEPDB1 as sysdba @mock_db/00_readonly_user.sql
--
-- The password below is a placeholder — set a real one and put it in Key Vault
-- as ORACLE_PASSWORD (never in app_settings, never in the repo).

-- Substitution vars so this file carries no literal secret.
DEFINE app_user     = ESCROW_RO
DEFINE app_password = "CHANGE_ME_IN_KEY_VAULT"
DEFINE schema_owner = ESCROW_OWNER

CREATE USER &app_user IDENTIFIED BY &app_password;

GRANT CREATE SESSION TO &app_user;

-- SELECT-only on exactly the two tables the connector reads.
GRANT SELECT ON &schema_owner..loan               TO &app_user;
GRANT SELECT ON &schema_owner..insurance_on_file  TO &app_user;

-- Convenience synonyms so the connector's SQL can use unqualified names.
CREATE OR REPLACE SYNONYM &app_user..loan              FOR &schema_owner..loan;
CREATE OR REPLACE SYNONYM &app_user..insurance_on_file FOR &schema_owner..insurance_on_file;

-- NOTE: no INSERT / UPDATE / DELETE / DDL is granted. The app cannot modify the
-- source of record even if a bug tried to.
