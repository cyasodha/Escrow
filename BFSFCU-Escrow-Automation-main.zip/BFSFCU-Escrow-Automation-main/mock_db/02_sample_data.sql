-- 02_sample_data.sql — synthetic loan + insurance-on-file data for the POC.
--
-- Calibrated to the 18 sample letters (mock_db letters set) so the pipeline's
-- bucket routing (api/src/shared/pipeline/routing.ts) lands them in an even
-- 9 / 9 split of the two buckets this data can control:
--
--   Action Required (9) — read fine, but a discrepancy vs the record on file:
--     Patricia Mouton            -> coverage GAP  (on-file ends 2026-09-01, letter starts 2026-10-01)
--     William & Cheryl Domingue  -> COVERAGE diff (on-file 265k vs letter 242k)
--     Robert Castille            -> PREMIUM diff  (on-file 1,890 vs letter 1,675)
--     David Reyes                -> ADDRESS mismatch (loan address differs from the letter)
--     Michael & Sarah Chen       -> NEW CARRIER   (on-file = old Farmers policy; letter = State Farm)
--     Todd Hebert                -> POLICY not on file (on-file = a prior USAA policy #)
--     Brian Fontenette           -> POLICY not on file (on-file = a prior USAA policy #)
--     Angela Breaux              -> POLICY not on file (on-file = a prior State Farm policy #)
--     Nicole Aucoin              -> POLICY not on file (on-file = a prior State Farm policy #)
--   No Action Required (9) — on-file matches the letter, continuous coverage, no change.
--
--   In Review is NOT set by this data — it is extraction-driven (routing step 1:
--   a missing key field, low scan quality, or a non-escrow document). To populate
--   the In Review bucket, upload the extraction-failing "review-*" sample letters;
--   the Oracle data here cannot force a letter into In Review.
--
-- Named insured = the letter body (filenames are deliberately mismatched).

SET DEFINE OFF;

DELETE FROM insurance_on_file;
DELETE FROM loan;

-- ============================ MODIFICATIONS ============================
-- Marcus Delahoussaye — NO ACTION (matches; continuous handoff 2026-08-12).
INSERT INTO loan VALUES ('00499128756', 'Marcus Delahoussaye', '330 Teal Ct, Gonzales, LA 70737', 'ACTIVE', 2400.00);
INSERT INTO insurance_on_file VALUES ('00499128756', 'Progressive', 'PGR-6634210', 'HO-3', 274000.00, 1760.00, DATE '2025-08-12', DATE '2026-08-12');

-- Patricia Mouton — ACTION REQUIRED: coverage GAP. On-file ends 2026-09-01, the
-- renewal letter starts 2026-10-01 -> 30-day gap. Everything else matches.
INSERT INTO loan VALUES ('00421763598', 'Patricia Mouton', '615 Live Oak Pkwy, New Iberia, LA 70560', 'ACTIVE', 3200.00);
INSERT INTO insurance_on_file VALUES ('00421763598', 'Allstate', 'ALS-7729014', 'HO-3', 301000.00, 2268.00, DATE '2025-09-01', DATE '2026-09-01');

-- David Reyes — ACTION REQUIRED: ADDRESS mismatch. Loan # matches but the
-- property address on file differs from the letter (1560 Perkins Rd). Else matches.
INSERT INTO loan VALUES ('00398214477', 'David Reyes', '412 Cypress Bend Dr, Youngsville, LA 70592', 'ACTIVE', 3100.00);
INSERT INTO insurance_on_file VALUES ('00398214477', 'Allstate', 'ALS-4471029', 'HO-3', 315000.00, 2412.00, DATE '2025-08-20', DATE '2026-08-20');

-- Alicia Broussard — NO ACTION.
INSERT INTO loan VALUES ('00487213904', 'Alicia Broussard', '1902 Ridgewood Ave, Alexandria, LA 71301', 'ACTIVE', 2800.00);
INSERT INTO insurance_on_file VALUES ('00487213904', 'Farmers Insurance', 'FI-5561287', 'HO-3', 256000.00, 1842.00, DATE '2025-06-15', DATE '2026-06-15');

-- William & Cheryl Domingue — ACTION REQUIRED: COVERAGE difference (on-file
-- dwelling 265k vs letter 242k). Else matches, continuous.
INSERT INTO loan VALUES ('00456839217', 'William & Cheryl Domingue', '77 Sugar Mill Rd, Thibodaux, LA 70301', 'ACTIVE', 2100.00);
INSERT INTO insurance_on_file VALUES ('00456839217', 'State Farm', 'SF-HO-334298', 'HO-3', 265000.00, 1512.00, DATE '2025-07-22', DATE '2026-07-22');

-- Robert Castille — ACTION REQUIRED: PREMIUM difference (on-file 1,890 vs letter
-- 1,675, about -11%). Else matches, continuous.
INSERT INTO loan VALUES ('00445781023', 'Robert Castille', '410 Magnolia Trace, Lake Charles, LA 70605', 'ACTIVE', 3400.00);
INSERT INTO insurance_on_file VALUES ('00445781023', 'USAA', 'USAA-2209841', 'HO-3', 298000.00, 1890.00, DATE '2025-09-05', DATE '2026-09-05');

-- Anthony & Renee Fields — NO ACTION.
INSERT INTO loan VALUES ('00463920185', 'Anthony & Renee Fields', '88 Bayou Vista Dr, Houma, LA 70360', 'ACTIVE', 2600.00);
INSERT INTO insurance_on_file VALUES ('00463920185', 'Liberty Mutual', 'LM-BINDER-77291', 'HO-3', 289000.00, 1988.00, DATE '2025-08-25', DATE '2026-08-25');

-- Michael & Sarah Chen — ACTION REQUIRED: NEW CARRIER. On-file is the old Farmers
-- policy; the letter is a new State Farm policy (SF-HO-991042) not on file.
INSERT INTO loan VALUES ('00512837461', 'Michael & Sarah Chen', '712 Live Oak Blvd, Lafayette, LA 70501', 'ACTIVE', 2900.00);
INSERT INTO insurance_on_file VALUES ('00512837461', 'Farmers Insurance', 'FI-3320115', 'HO-3', 268000.00, 1540.00, DATE '2025-09-10', DATE '2026-09-10');

-- Jennifer Ouellette — NO ACTION.
INSERT INTO loan VALUES ('00477562190', 'Jennifer Ouellette', '225 Camellia St, Broussard, LA 70518', 'ACTIVE', 3300.00);
INSERT INTO insurance_on_file VALUES ('00477562190', 'Travelers', 'TRV-8823410', 'HO-3', 342000.00, 2105.00, DATE '2025-07-01', DATE '2026-07-01');

-- Jonathan Prejean — NO ACTION.
INSERT INTO loan VALUES ('00408217653', 'Jonathan Prejean', '150 Riverbend Dr, Covington, LA 70433', 'ACTIVE', 3000.00);
INSERT INTO insurance_on_file VALUES ('00408217653', 'USAA', 'USAA-9981204', 'HO-3', 328000.00, 2215.00, DATE '2025-08-30', DATE '2026-08-30');

-- ============================ CANCELLATIONS ============================
-- (Cancellations have no incoming coverage start, so no gap is evaluated.)

-- NO ACTION — on-file = the policy being cancelled (matches the letter).
INSERT INTO loan VALUES ('00485213967', 'Monique Guillory', '1120 Highland Rd, Baton Rouge, LA 70802', 'ACTIVE', 2600.00);
INSERT INTO insurance_on_file VALUES ('00485213967', 'Liberty Mutual', 'LM-6612093', 'HO-3', 312000.00, 2140.00, DATE '2025-03-01', DATE '2026-03-01');

-- ACTION REQUIRED — the letter's policy # is NOT on file (on-file = a prior
-- policy number), so the account can't be confirmed against Core DNA.
INSERT INTO loan VALUES ('00438720914', 'Todd Hebert', '620 Cane River Rd, Natchitoches, LA 71457', 'ACTIVE', 2750.00);
INSERT INTO insurance_on_file VALUES ('00438720914', 'USAA', 'USAA-7723458-PRIOR', 'HO-3', 296000.00, 1975.00, DATE '2025-10-10', DATE '2026-10-10');

INSERT INTO loan VALUES ('00417298653', 'Brian Fontenette', '44 Live Oak Cir, Opelousas, LA 70570', 'ACTIVE', 900.00);
INSERT INTO insurance_on_file VALUES ('00417298653', 'USAA', 'USAA-4471209-PRIOR', 'HO-3', 251000.00, 1640.00, DATE '2025-04-20', DATE '2026-04-20');

INSERT INTO loan VALUES ('00439871205', 'Nicole Aucoin', '902 Egret Ln, Morgan City, LA 70380', 'ACTIVE', 2300.00);
INSERT INTO insurance_on_file VALUES ('00439871205', 'State Farm', 'SF-HO-887340-PRIOR', 'HO-3', 275000.00, 1705.00, DATE '2025-06-01', DATE '2026-06-01');

INSERT INTO loan VALUES ('00452198734', 'Angela Breaux', '310 Plantation Dr, Zachary, LA 70791', 'ACTIVE', 2500.00);
INSERT INTO insurance_on_file VALUES ('00452198734', 'State Farm', 'SF-HO-116629-PRIOR', 'HO-3', 258000.00, 1588.00, DATE '2025-12-01', DATE '2026-12-01');

-- NO ACTION — the remaining cancellations match on file.

INSERT INTO loan VALUES ('00429871056', 'Tara Melancon', '95 Bayou Black Dr, Houma, LA 70360', 'ACTIVE', 2200.00);
INSERT INTO insurance_on_file VALUES ('00429871056', 'Progressive', 'PGR-3398201', 'HO-3', 243000.00, 1690.00, DATE '2025-11-05', DATE '2026-11-05');

INSERT INTO loan VALUES ('00472098341', 'Derek Simoneaux', '540 Chenier Rd, Abbeville, LA 70510', 'ACTIVE', 2000.00);
INSERT INTO insurance_on_file VALUES ('00472098341', 'Allstate', 'ALS-3312087', 'HO-3', 260000.00, 1890.00, DATE '2025-05-10', DATE '2026-05-10');

INSERT INTO loan VALUES ('00467312985', 'Christopher Savoie', '18 Egret Point Rd, Mandeville, LA 70448', 'ACTIVE', 3500.00);
INSERT INTO insurance_on_file VALUES ('00467312985', 'Allstate', 'ALS-9987321', 'HO-3', 335000.00, 2310.00, DATE '2026-01-15', DATE '2027-01-15');

COMMIT;
