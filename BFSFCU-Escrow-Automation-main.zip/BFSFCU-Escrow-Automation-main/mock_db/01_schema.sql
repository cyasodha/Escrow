-- 01_schema.sql — Oracle schema for the credit union's loan system (POC stand-in).
--
-- This is the SEPARATE, deployed Oracle database the escrow app reads from
-- through its read-only connector (api/src/shared/oracle/). It is NOT the app's
-- own Postgres database. In production this schema belongs to the credit union;
-- for the POC we stand up an Oracle instance and load a synthetic copy that
-- matches the real shape (SOW §6, Appendix A: "synthetic data that matches the
-- real schema").
--
-- The app only ever runs SELECTs here — three operations:
--   findLoanByNumber(loan_number)              -> loan + active-mortgage check
--   findLoanByNameAddress(name, address)       -> fallback when loan # is absent
--   getInsuranceOnFile(loan_number)            -> the policy currently on file
--
-- Run with SQL*Plus or SQLcl as a schema owner:
--   sql escrow_owner/****@//host:1521/XEPDB1 @mock_db/01_schema.sql
--
-- Re-runnable: each object is dropped first (errors on "does not exist" ignored).

SET DEFINE OFF;

-- ---------------------------------------------------------------------------
-- Drop existing objects (ignore "does not exist")
-- ---------------------------------------------------------------------------
BEGIN EXECUTE IMMEDIATE 'DROP TABLE insurance_on_file'; EXCEPTION WHEN OTHERS THEN IF SQLCODE != -942 THEN RAISE; END IF; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE loan'; EXCEPTION WHEN OTHERS THEN IF SQLCODE != -942 THEN RAISE; END IF; END;
/

-- ---------------------------------------------------------------------------
-- loan — one row per mortgage loan / member escrow account
-- ---------------------------------------------------------------------------
CREATE TABLE loan (
  loan_number       VARCHAR2(20)  NOT NULL,
  member_name       VARCHAR2(120) NOT NULL,
  property_address  VARCHAR2(200) NOT NULL,
  -- ACTIVE mortgages are the ones the app services; anything else is a mismatch.
  mortgage_status   VARCHAR2(20)  DEFAULT 'ACTIVE' NOT NULL,
  escrow_balance    NUMBER(12,2)  DEFAULT 0 NOT NULL,
  CONSTRAINT loan_pk PRIMARY KEY (loan_number),
  CONSTRAINT loan_status_ck CHECK (mortgage_status IN ('ACTIVE','PAID_OFF','DELINQUENT','FORECLOSURE'))
);

COMMENT ON TABLE  loan                  IS 'Mortgage loans / member escrow accounts. Read-only source for loan lookup and property-address validation.';
COMMENT ON COLUMN loan.mortgage_status  IS 'Only ACTIVE mortgages are serviced; a non-active status is treated as a match failure.';
COMMENT ON COLUMN loan.escrow_balance   IS 'Current escrow balance; used to warn when a premium may exceed available funds.';

-- Fallback match is by member name + property address, so index both.
CREATE INDEX loan_name_idx ON loan (UPPER(member_name));
CREATE INDEX loan_addr_idx ON loan (UPPER(property_address));

-- ---------------------------------------------------------------------------
-- insurance_on_file — the policy currently recorded against a loan's escrow
-- ---------------------------------------------------------------------------
CREATE TABLE insurance_on_file (
  loan_number       VARCHAR2(20)  NOT NULL,
  carrier           VARCHAR2(80)  NOT NULL,
  policy_number     VARCHAR2(40)  NOT NULL,
  policy_type       VARCHAR2(40),
  dwelling_coverage NUMBER(12,2),
  premium           NUMBER(12,2),
  period_start      DATE,
  period_end        DATE,
  CONSTRAINT insurance_on_file_pk PRIMARY KEY (loan_number, policy_number),
  CONSTRAINT insurance_on_file_loan_fk FOREIGN KEY (loan_number) REFERENCES loan (loan_number)
);

COMMENT ON TABLE  insurance_on_file IS 'The hazard-insurance policy currently on file for a loan. Compared against an incoming letter to detect changes.';

CREATE INDEX insurance_loan_idx ON insurance_on_file (loan_number);
