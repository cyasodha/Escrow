# Escalation email notifications — Logic App (HTTP)

The escrow app **does not send email**. When a letter is escalated to a manager,
the API composes the email and **POSTs it as JSON** to a **Logic App** HTTP
trigger. The Logic App — owned by the client's IT — sends the mail through a
connection they govern (Office 365 Outlook connector, SMTP relay, …). HTTP is
used (rather than a queue) so the email goes out **immediately**.

The app holds **no mailbox permission** — only the signed trigger URL.

```
Escrow Functions API ──HTTPS POST (JSON)──▶ Logic App "When a HTTP request is received"
                                                   │
                                     Office 365 Outlook connector / SMTP relay
                                                   ▼
                                              recipient
```

## App-side configuration

| Setting | Default | Meaning |
|---|---|---|
| `NOTIFICATIONS_ENABLED` | `false` | Master switch. Off ⇒ escalations still work, nothing is sent. |
| `LOGIC_APP_URL` | _(empty)_ | The Logic App HTTP trigger URL **including its `sig` signature**. Secret — keep in Key Vault. |
| `APP_BASE_URL` | first `ALLOWED_ORIGINS` | Optional. Base URL for the "Open the letter" deep link. Defaults to the web app's CORS origin; set only to override. |

The app retries the POST once on a transient failure. It is best-effort and never
fails the escalation — if delivery fails after the retry, it logs a warning.

## Request body (what the trigger receives)

The POST body **is** the trigger input — fields are available directly as
`triggerBody()?['to']`, etc. No queue, no decode step.

```jsonc
{
  "type": "escalation",              // or "test"
  "to": "manager@bfsfcu.com",
  "subject": "Escalation: Jane Doe (loan 0012345)",
  "html": "<div>…fully composed HTML body…</div>",
  "meta": { "letterId": "…", "escalatedById": "…", "escalatedByName": "…", "managerId": "…" }
}
```

## Build the Logic App (portal)

1. **Trigger:** add **When a HTTP request is received**. Paste this as the
   **Request Body JSON Schema** so the fields become tokens:
   ```json
   {
     "type": "object",
     "properties": {
       "type": { "type": "string" },
       "to": { "type": "string" },
       "subject": { "type": "string" },
       "html": { "type": "string" },
       "meta": { "type": "object" }
     }
   }
   ```
   Save — the trigger URL (with `?...&sig=…`) is generated. That URL is `LOGIC_APP_URL`.
2. **Send:** *Office 365 Outlook – Send an email (V2)* (or the SMTP connector to an
   internal relay):
   - To = `to`
   - Subject = `subject`
   - Body = `html` (Advanced options → **Is HTML = Yes**)
3. (Optional) add a **Response** action returning 200; otherwise the trigger
   returns 202 Accepted, which the app treats as success.

## Wire it up

1. On the escrow **Function App → Environment variables**: set `NOTIFICATIONS_ENABLED=true`,
   `LOGIC_APP_URL=<the trigger URL>`, `APP_BASE_URL=<web URL>`. Save.
2. Test: escalate a letter to a manager who has a real inbox → the email arrives,
   and the run shows in the Logic App's **Run history**.

## Securing the trigger (for the review)

- The `sig` in the URL authorizes the call (SAS). Keep `LOGIC_APP_URL` in **Key Vault**.
- Harden further as needed: restrict the trigger by **caller IP range**, put the
  Logic App behind a **private endpoint** and VNet-integrate the Function App so
  the call never traverses the public internet, or switch the trigger to **Entra
  (Easy Auth)** and have the app call it with its Managed Identity (no SAS secret).
- Outbound send: the Office 365 connector egresses to Exchange Online (cloud-to-cloud);
  use the **SMTP connector to an internal relay** if the send path must stay private.

## Local testing (no Logic App)

Point `LOGIC_APP_URL` at any local HTTP listener (e.g. a small node server, or a
webhook tester) and set `NOTIFICATIONS_ENABLED=true`. Escalating a letter POSTs
the JSON body above to it, proving the app leg without a Logic App.
