# Client Deployment Runbook (from scratch)

Stand up the BFSFCU Escrow Automation app in a **client-owned Azure subscription**,
starting from **nothing but the code in GitHub**. Every resource is created here
with exact `az` commands. Copy the variables block, then run each section in order.

> This is the from-scratch procedure for a client's own Azure subscription.
> **Keep it updated** when the topology, settings, or migrations change (see the
> change log at the bottom).

---

## 0. What you're building

```
Browser ─▶ Static Web App (SPA)  ──/api/* linked backend──▶  Function App (API, Flex Consumption)
                                                                 │
        PostgreSQL Flexible Server  ◀────────────────────────────┤ workflow DB (bfsfcu_escrow)
        Storage: blob `letters` + queues `letter-jobs`,`classify-jobs` ◀──┤ documents + async jobs
        Document Intelligence       ◀────────────────────────────┤ OCR (prebuilt-layout)
        Azure OpenAI                ◀────────────────────────────┤ field extraction/normalise
        Oracle (read-only, optional)◀────────────────────────────┘ loan lookup
```

The SPA calls the API **same-origin at `/api`** via a Static Web App *linked
backend*, so the session cookie stays first-party. Uploads return immediately;
OCR/LLM/Oracle run in a **queue worker**. The app sends **no email** itself.

### Prerequisites (on your machine)

- **Azure CLI** (`az`, logged in with rights to create resources) — `az login`
- **Azure Functions Core Tools v4** (`func`) — for a manual API deploy
- **Node 20** and **npm**
- **PostgreSQL client** (`psql`) + **PowerShell** (`pwsh`) — to run `db/apply.ps1`
- This repo cloned locally, on the `dev` branch

---

## 1. Variables (edit these, then paste into your shell)

```bash
# --- identity / location ---
export SUB="<your-subscription-id>"
export LOC="eastus2"                 # a region with OpenAI + Flex Consumption + SWA
export RG="rg-bfsfcu-escrow"

# --- resource names (must be globally unique where noted) ---
export STORAGE="bfsfcuescrowsa$RANDOM"   # 3-24 lowercase alphanumerics, GLOBALLY UNIQUE
export PG_SERVER="bfsfcu-escrow-pg-$RANDOM"   # GLOBALLY UNIQUE
export PG_ADMIN="pgadmin"
export PG_ADMIN_PW="$(openssl rand -base64 24)"   # save this
export DOCINTEL="bfsfcu-escrow-di"       # GLOBALLY UNIQUE (custom subdomain)
export AOAI="bfsfcu-escrow-oai"          # GLOBALLY UNIQUE (custom subdomain)
export FUNCAPP="bfsfcu-escrow-api"       # GLOBALLY UNIQUE
export SWA="bfsfcu-escrow-web"           # unique within the subscription
export SWA_LOC="eastus2"                 # SWA supports: eastus2, centralus, westus2, westeurope, eastasia

# --- app secret ---
export SESSION_SECRET="$(openssl rand -base64 48)"   # save this

az login
az account set --subscription "$SUB"
az group create -n "$RG" -l "$LOC"
```

> Save `PG_ADMIN_PW` and `SESSION_SECRET` somewhere safe (ideally Key Vault). You
> will not be able to read `SESSION_SECRET` back out of the Function App later.

---

## 2. Storage (documents + job queues)

```bash
az storage account create -n "$STORAGE" -g "$RG" -l "$LOC" \
  --sku Standard_LRS --kind StorageV2 --min-tls-version TLS1_2 \
  --allow-blob-public-access false

# Connection string — used for AzureWebJobsStorage and to create the container/queues.
export STORAGE_CONN="$(az storage account show-connection-string -n "$STORAGE" -g "$RG" -o tsv)"

# One private container + two queues (names the app expects).
az storage container create --name letters       --connection-string "$STORAGE_CONN"
az storage queue    create --name letter-jobs     --connection-string "$STORAGE_CONN"
az storage queue    create --name classify-jobs   --connection-string "$STORAGE_CONN"
```

---

## 3. PostgreSQL Flexible Server

```bash
az postgres flexible-server create \
  -g "$RG" -n "$PG_SERVER" -l "$LOC" \
  --tier Burstable --sku-name Standard_B1ms --version 16 --storage-size 32 \
  --admin-user "$PG_ADMIN" --admin-password "$PG_ADMIN_PW" \
  --public-access 0.0.0.0            # enable public networking + "allow Azure services"

# The application database.
az postgres flexible-server db create -g "$RG" -s "$PG_SERVER" -d bfsfcu_escrow

# REQUIRED: allowlist the extensions the schema uses (pgcrypto = gen_random_uuid,
# pg_trgm = fuzzy matching). Without this, migration 0001 fails on CREATE EXTENSION.
az postgres flexible-server parameter set -g "$RG" -s "$PG_SERVER" \
  --name azure.extensions --value PGCRYPTO,PG_TRGM

# Let YOUR machine reach the server to run migrations (step 8).
MY_IP="$(curl -s https://api.ipify.org)"
az postgres flexible-server firewall-rule create -g "$RG" -n "$PG_SERVER" \
  --rule-name allow-admin-ip --start-ip-address "$MY_IP" --end-ip-address "$MY_IP"

export PG_HOST="$PG_SERVER.postgres.database.azure.com"
```

> `--public-access 0.0.0.0` creates the "Allow public access from Azure services"
> rule the Function App needs. The per-IP rule above is for running migrations from
> your laptop. Harden later with a private endpoint if the client requires it.

---

## 4. Document Intelligence (OCR)

```bash
az cognitiveservices account create -n "$DOCINTEL" -g "$RG" -l "$LOC" \
  --kind FormRecognizer --sku S0 --custom-domain "$DOCINTEL" --yes

export DOCINTEL_ENDPOINT="$(az cognitiveservices account show -n "$DOCINTEL" -g "$RG" --query properties.endpoint -o tsv)"
export DOCINTEL_KEY="$(az cognitiveservices account keys list -n "$DOCINTEL" -g "$RG" --query key1 -o tsv)"
```

---

## 5. Azure OpenAI

Requires that your subscription has Azure OpenAI access in `$LOC`. Pick a chat
model your region offers (`az cognitiveservices account list-models` after create).

```bash
az cognitiveservices account create -n "$AOAI" -g "$RG" -l "$LOC" \
  --kind OpenAI --sku S0 --custom-domain "$AOAI" --yes

# Deploy a chat model (adjust model-name/version to what your region supports).
az cognitiveservices account deployment create -n "$AOAI" -g "$RG" \
  --deployment-name gpt-4o --model-format OpenAI \
  --model-name gpt-4o --model-version 2024-08-06 \
  --sku-name Standard --sku-capacity 20

export AOAI_ENDPOINT="$(az cognitiveservices account show -n "$AOAI" -g "$RG" --query properties.endpoint -o tsv)"
export AOAI_KEY="$(az cognitiveservices account keys list -n "$AOAI" -g "$RG" --query key1 -o tsv)"
```

---

## 6. Function App (API — Flex Consumption, Node 20)

```bash
az functionapp create \
  -g "$RG" -n "$FUNCAPP" \
  --storage-account "$STORAGE" \
  --flexconsumption-location "$LOC" \
  --runtime node --runtime-version 20 --functions-version 4

# System-assigned identity (used for storage RBAC below; also for MI hardening).
az functionapp identity assign -g "$RG" -n "$FUNCAPP"
FUNC_MI="$(az functionapp identity show -g "$RG" -n "$FUNCAPP" --query principalId -o tsv)"
STORAGE_ID="$(az storage account show -n "$STORAGE" -g "$RG" --query id -o tsv)"
az role assignment create --assignee "$FUNC_MI" --role "Storage Blob Data Contributor"  --scope "$STORAGE_ID"
az role assignment create --assignee "$FUNC_MI" --role "Storage Queue Data Contributor" --scope "$STORAGE_ID"
```

`create` already sets `AzureWebJobsStorage` to the storage connection string, which
the app and the queue trigger use. (App settings are set in step 7, after the Static
Web App exists so we know its hostname for CORS.)

---

## 7. Static Web App + wire it to the API

```bash
az staticwebapp create -g "$RG" -n "$SWA" -l "$SWA_LOC" --sku Standard
export SWA_HOST="$(az staticwebapp show -g "$RG" -n "$SWA" --query defaultHostname -o tsv)"

# Link the Function App as the SWA's backend, so /api/* is proxied same-origin.
FUNC_ID="$(az functionapp show -g "$RG" -n "$FUNCAPP" --query id -o tsv)"
az staticwebapp backends link -g "$RG" -n "$SWA" --backend-resource-id "$FUNC_ID" --backend-region "$LOC"
```

Now set **all** Function App application settings (secrets included — move them to
Key Vault references afterward for production):

```bash
az functionapp config appsettings set -g "$RG" -n "$FUNCAPP" --settings \
  FUNCTIONS_WORKER_RUNTIME=node \
  SESSION_SECRET="$SESSION_SECRET" \
  SESSION_TTL=12h \
  PG_HOST="$PG_HOST" PG_PORT=5432 PG_DATABASE=bfsfcu_escrow \
  PG_USER="$PG_ADMIN" PG_PASSWORD="$PG_ADMIN_PW" PG_SSL=true PG_USE_MANAGED_IDENTITY=false \
  BLOB_CONTAINER=letters QUEUE_NAME=letter-jobs CLASSIFY_QUEUE_NAME=classify-jobs \
  DOCINTEL_ENDPOINT="$DOCINTEL_ENDPOINT" DOCINTEL_KEY="$DOCINTEL_KEY" \
  DOCINTEL_API_VERSION=2024-11-30 DOCINTEL_MODEL=prebuilt-layout DOCINTEL_CLASSIFY_ENABLED=false \
  AOAI_ENDPOINT="$AOAI_ENDPOINT" AOAI_KEY="$AOAI_KEY" AOAI_DEPLOYMENT=gpt-4o \
  AOAI_API_VERSION=2024-08-01-preview AOAI_REASONING_MODEL=false \
  ORACLE_THIN_MODE=true \
  NOTIFICATIONS_ENABLED=false GRAPH_ENABLED=false DEMO_MODE=false \
  ALLOWED_ORIGINS="https://$SWA_HOST" LOG_LEVEL=info
```

> **Do NOT set** `AUTH_COOKIE_INSECURE` (that's local-HTTP only — production needs a
> Secure cookie). Leave `DEMO_MODE=false`. `ORACLE_PASSWORD`, notifications and Graph
> settings are added later only if you enable those features (§10).

---

## 8. Apply the database migrations

From the repo root, with the server + admin IP rule from step 3:

```bash
PGHOST="$PG_HOST" PGUSER="$PG_ADMIN" PGPASSWORD="$PG_ADMIN_PW" \
PGDATABASE=bfsfcu_escrow PGSSLMODE=require pwsh ./db/apply.ps1
```

This applies `0001`–`0015` in order (idempotent — safe to re-run). Re-run it after
every future change that adds a migration, **before** the API that needs it is live
(e.g. `0015` adds the `system` role the deployed API compares against).

**Seeded data to clean up for a real client:**
- `0001` seeds admin **`admin@bfsfcu.test` / `Escrow@review`** — sign in once, create
  the client's real manager account, then change this password or deactivate it.
- `0006` seeds **demo Escrow Admin users** — deactivate them in User Management and
  add the client's real users (keep at least one active Manager).

---

## 9. Deploy the code

### Option A — one-off manual deploy (fastest first bring-up)

```bash
# API
cd api && npm ci && npm run build && func azure functionapp publish "$FUNCAPP" && cd ..

# Web (built against the same-origin /api)
cd web && npm ci && npm run build && cd ..
SWA_TOKEN="$(az staticwebapp secrets list -g "$RG" -n "$SWA" --query properties.apiKey -o tsv)"
npx @azure/static-web-apps-cli deploy web/dist --deployment-token "$SWA_TOKEN" --env production
```

### Option B — GitHub Actions (ongoing, push-to-`dev`)

The repo ships two workflows ([`deploy-web.yml`](../.github/workflows/deploy-web.yml),
[`dev_bfsfcuescrow-api.yml`](../.github/workflows/dev_bfsfcuescrow-api.yml)). They
reference the **demo** app/SWA names, so for a client either name your resources the
same, or edit the `app-name:` (API) and `app_location`/SWA target (web) in the two
files. Then add repo secrets under **GitHub → Settings → Secrets and variables →
Actions**:

- `SWA_DEPLOYMENT_TOKEN` = `az staticwebapp secrets list -g "$RG" -n "$SWA" --query properties.apiKey -o tsv`
- `AZUREAPPSERVICE_PUBLISHPROFILE_…` = the Function App publish profile
  (`az functionapp deployment list-publishing-profiles -g "$RG" -n "$FUNCAPP" --xml`),
  matching the secret name used in `dev_bfsfcuescrow-api.yml`.

Push to `dev` (or run each workflow from the Actions tab) and both deploy.

---

## 10. Optional features

Enable only what the client needs; each is off by default.

- **Machine ingestion (Power Automate / inbox):** in the app, **User Management →
  Power Automate API Key → Generate**. The client's flow uploads the file into the
  `letters` container, then `POST`s `{ "blobPath": "<path>", "filename": "<name>" }`
  to `/api/letters` with header `X-Api-Key: <key>`. That caller is the hidden
  `system` principal (ingest route only). Email is *not* required — any trigger works.
- **Escalation email:** stand up a Logic App HTTP trigger per
  [`docs/notifications-logic-app.md`](notifications-logic-app.md); then set
  `NOTIFICATIONS_ENABLED=true` and `LOGIC_APP_URL=<trigger-url-with-sig>` (Key Vault).
- **Oracle loan lookup:** set `ORACLE_PASSWORD` in app settings; configure
  host/port/service/user in **Admin → Oracle Connection**. For a pilot without the
  real Oracle, load `mock_db/*.sql` (see `mock_db/README.md`).
- **Nightly OOO sync:** set `GRAPH_ENABLED=true` + `GRAPH_TENANT_ID/CLIENT_ID` and
  grant Graph `MailboxSettings.Read` (prefer the Function App Managed Identity over a
  client secret). Configure the business calendar in **Admin → Schedule**.
- **Entra SSO:** register an API app + SPA client; set `GRAPH_*` and, in the web
  build, `VITE_ENTRA_TENANT_ID`, `VITE_ENTRA_CLIENT_ID`, `VITE_API_SCOPE`. SSO is
  match-existing-only (an admin must create the account first).
- **Multi-letter classify + per-policy split:** two independent, config-gated stages
  that turn a multi-document / multi-policy PDF into one task per policy. Both are
  **off by default**.
  - **Classifier (separate documents).** Train a Document Intelligence **custom
    classification** model, then set **both** `DOCINTEL_CLASSIFY_ENABLED=true` **and**
    `DOCINTEL_CLASSIFIER_ID=<classifierId>` — the enable flag alone does nothing, the
    app requires a non-empty id too (note the spelling: `CLASSIFIER`, not `CLASSIFY`).
    Optionally `DOCINTEL_LETTER_DOCTYPES=<class>` (e.g. `policy`) to keep only that
    class's segments and drop the rest; leave empty to accept every segment.
    - **The classifier MUST live in the same Document Intelligence resource that
      `DOCINTEL_ENDPOINT` points at.** The app uses one endpoint/key for both OCR
      (`prebuilt-layout`) and the classifier. If you trained it in a *different*
      resource (e.g. a standalone Studio resource), the classify call fails with
      **"model not found"** even though OCR works. Fix by pointing
      `DOCINTEL_ENDPOINT`/`DOCINTEL_KEY` at that resource (every DI resource serves
      `prebuilt-layout` OCR too), or copy the model in with DI's copy-classifier API
      (`authorizeCopy` + `copyTo`). Verify with:
      `curl "$DOCINTEL_ENDPOINT/documentintelligence/documentClassifiers?api-version=2024-11-30" -H "Ocp-Apim-Subscription-Key: $DOCINTEL_KEY"` — the id must appear.
    - Classification runs **only on new PDF uploads** — not images, and **not
      retroactively** on already-ingested letters (re-upload to test). It needs the
      `classify-jobs` queue + `CLASSIFY_QUEUE_NAME=classify-jobs` from §2/§7; if you
      enable classify on an older deployment that predates those, add them first or
      jobs sit unprocessed in a queue with no consumer.
  - **Per-policy split (fan-out).** A single classified document can still list
    several policies. Set `DOCINTEL_POLICY_SPLIT_ENABLED=true` so the extractor splits
    it into **one task per distinct policy number**, all sharing the same document
    blob; tune the floor with `DOCINTEL_POLICY_SPLIT_MIN_CONFIDENCE` (default `0.7`).
    Independent of the classifier and needs no migration (it reuses the split-
    provenance columns). A `policy`/`non-policy` classifier separates policy pages
    from junk but does **not** split two *adjacent* policy letters, so enable this too
    for true one-task-per-policy.

---

## 11. Smoke test

1. Open `https://$SWA_HOST`; sign in as the seed admin, then create/switch to a real account.
2. **Upload** a sample letter → it appears and leaves "queued" (worker + storage + DB OK).
3. Open the document → the short-lived view URL works (blob SAS OK).
4. Oracle on: a letter with a known loan number matches.
5. Ingestion on: run the inbox flow → a letter appears with audit actor **"System"**.
6. Notifications on: escalate a letter → the recipient gets the email.
7. Watch Function App logs (`az functionapp log tail -g "$RG" -n "$FUNCAPP"`) for errors.

---

## 12. Secrets & hardening

- Secrets live only in **Function App settings / Key Vault / GitHub secrets** — never
  in git. `api/local.settings.json` is gitignored.
- After bring-up, move `SESSION_SECRET`, `PG_PASSWORD`, `DOCINTEL_KEY`, `AOAI_KEY`,
  `LOGIC_APP_URL` to **Key Vault** and use `@Microsoft.KeyVault(...)` references.
- Prefer **Managed Identity** over keys: the Function App MI already has storage
  data roles (step 6); switch `PG_USE_MANAGED_IDENTITY=true` with an MI DB role, and
  drop `AzureWebJobsStorage` to identity-based (`AzureWebJobsStorage__accountName`) +
  `BLOB_ACCOUNT_URL`/`QUEUE_ACCOUNT_URL` if you want no storage key at all.
- Create a **least-privilege Postgres app user** instead of using the admin login.
- Keep `DEMO_MODE=false`; deactivate demo users; rotate the seed admin.
- Consider **private endpoints** (Postgres, Storage) per the client's baseline.

---

## Change log

- **2026-09-28** — §10: expanded classify into **classify + per-policy split**.
  Documented the two required classifier settings (and the `CLASSIFIER` spelling),
  `DOCINTEL_LETTER_DOCTYPES`, and the **classifier-must-be-in-the-same-DI-resource-as-
  OCR** gotcha ("model not found"). Added the per-policy fan-out
  (`DOCINTEL_POLICY_SPLIT_ENABLED` / `DOCINTEL_POLICY_SPLIT_MIN_CONFIDENCE`, no
  migration). No schema change since `0015`.
- **2026-09-22** — Rewritten as a full from-scratch `az` provisioning guide (storage,
  Postgres + `azure.extensions`, Document Intelligence, OpenAI, Flex Consumption
  Function App, Static Web App + linked backend). Migrations `0001`–`0015`; the
  `system` service principal + blob-reference ingest.
