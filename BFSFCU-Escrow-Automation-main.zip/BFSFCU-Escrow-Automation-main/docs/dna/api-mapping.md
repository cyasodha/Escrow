# Fiserv DNA REST API mapping

The "Oracle" the escrow app reads (`mock_db/`, `api/src/shared/oracle/`) is the
credit union's Fiserv DNA core. This maps each connector operation to DNA REST
resources from the DNA REST API Explorer
(`https://dnacreator.fiservapps.com/ApiDocs/ApiPortal/dna-restexplorer`).

Captured Postman exports live in `docs/dna/postman/`.

## Transport conventions (confirmed)

- Base path: `/DnaBusinessServices`
- Auth: API key in an `authorization` request header
- Response envelope: `{ messageHeader: { MessageId, UpdateKey }, messageBody }`
  where `messageBody` is an object or an array
- Common query params: `Include` (`Graph` | `Standard`), `PageNumber`,
  `PageSize`, `Sort`, `ShowNulls`
- Errors: 422 validation with `brokenRules[]`, 500 with `message` / `exceptionId`
- `UpdateKey` in `messageHeader` is the optimistic-concurrency token; any future
  write will almost certainly need to echo it back.

## Resource group shortlist

| Connector op (`connector.ts`) | DNA resource | Status |
|---|---|---|
| `findLoanByNumber` | `Accounts` (Account-General) | not yet captured |
| " | `Accounts/MortgageLoansSummary` (Account-Loan) | not yet captured |
| escrow balance | `Accounts/BalanceDefinitions` (Account-Balances) | not yet captured |
| property address | `Accounts/Properties` (Account-Property) | not yet captured |
| `getInsuranceOnFile` | `Accounts/{AccountId}/Properties/{PropertyId}/Insurances` | CAPTURED — see below |
| `findLoanByNameAddress` | `SearchForParty` -> `Persons` -> `AccountPartyRoles` | not yet captured |
| `findInsuranceByPolicyNumber` | no reverse lookup exists | see "Gaps" |

## Accounts/Properties/Insurances (captured 2026-09-22)

DNA description: "The Account Property Insurance table identifies the insurance
policies for property associated with an account." Auth code `1840-AcctPropInss`.

Three operations, ALL READ:

| Verb | Path |
|---|---|
| GET | `/Accounts/{AccountId}/Properties/{PropertyId}/Insurances` |
| GET | `/Accounts/{AccountId}/Properties/{PropertyId}/Insurances/{InsuranceId}` |
| POST | `/Accounts/{AccountId}/Properties/{PropertyId}/Insurances/Query/SearchByAcctNbrAndPropNbr` body `{ AcctNbr, PropNbr }` — a query, not a write |

Response item shape:

```
accountNumber                          long
effectiveDate                          date
escrowDisbursementChangeEffectiveDate  date
id                                     string
inactiveDate                           date
internalPolicyNumber                   long
isEscrow                               boolean
isLenderFunded                         boolean
lastMaintained                         dateTime
propertyNumber                         long
uid                                    string
url                                    string
```

### What this means

This is a LINK record (account + property -> policy), not the policy itself. It
carries none of the fields the comparison screen needs:

| `InsuranceOnFile` field | Present here? |
|---|---|
| `loanNumber` | yes, `accountNumber` |
| `carrier` | NO |
| `policyNumber` | NO (only `internalPolicyNumber`, a DNA surrogate key) |
| `policyType` | NO |
| `dwellingCoverage` | NO |
| `premium` | NO |
| `periodStart` | partially — `effectiveDate` is the escrow link effective date, not necessarily the policy term start |
| `periodEnd` | NO (`inactiveDate` is when the link ends, not policy expiry) |

Useful extras not in our model: `isEscrow` (premium paid from escrow),
`isLenderFunded` (force-placed), `escrowDisbursementChangeEffectiveDate`.

## Gaps to close

1. **Policy detail is somewhere else.** `internalPolicyNumber` must dereference
   to a record holding carrier, external policy number, coverage and premium.
   Try `Include=Graph` on the GET first — the default for the list operation is
   `Graph`, so the expanded response may already carry the policy sub-object and
   the sample body may only be showing the `Standard` shape. If not, the policy
   entity is a separate resource to locate in the explorer.
2. **No write operations on this resource.** There is no POST create, PUT or
   PATCH. Recording an approved letter's policy back into DNA cannot be done
   through `Accounts/Properties/Insurances` as exposed. Options: find the
   resource that owns policy detail and check its verbs; or accept that DNA
   stays read-only and the app's write-back is a work queue / note only.
3. **`findInsuranceByPolicyNumber` has no DNA equivalent.** Every insurance path
   is scoped by account and property, so the policy number cannot be the entry
   point. The pipeline's PRIMARY match must be reworked: resolve the account
   first (loan number, or name + address), then compare the letter's policy
   number against that account's on-file policy.
4. **PropertyId is required everywhere.** We must fetch `Accounts/Properties`
   for the account before we can read insurance. That is an extra hop the
   current connector does not have.

## Next exports needed

In the explorer, export the Postman collection for each and drop it in
`docs/dna/postman/`:

1. `Accounts/Properties` (Account-Property) — property id + address, and check for write verbs
2. `Accounts` (Account-General) — account by number, status, product type
3. `Accounts/MortgageLoansSummary` (Account-Loan)
4. `Accounts/BalanceDefinitions` (Account-Balances) — escrow balance
5. `SearchForParty` (Search)
6. `AccountPartyRoles` or `Accounts/PersonRoles` (Account-General)
7. `Note` — if we want an audit stamp on approve
8. Anything in the explorer whose name contains "Insurance" outside Account-Property
