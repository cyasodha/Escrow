# Developer guide (Windows) — local setup & contributing

How to run the whole escrow app on a Windows laptop and contribute changes. New
here? Read [CONTEXT.md](CONTEXT.md) first for what the app is and its conventions.

The app is two processes — **API** (Azure Functions) and **web** (Vite) — plus
four dependencies: **PostgreSQL**, **Azurite** (Blob/Queue emulator), **Oracle**,
and **Azure AI** (Document Intelligence + OpenAI).

---

## 1. Prerequisites

Install (winget shown; any installer works):

```powershell
winget install OpenJS.NodeJS.LTS          # Node 20+
winget install Docker.DockerDesktop        # Postgres + Oracle containers
winget install Microsoft.AzureFunctionsCoreTools   # func (v4)
winget install PostgreSQL.PostgreSQL       # gives you psql (client)
npm install -g azurite                     # local Blob/Queue
```

- Use **Git Bash** for the bash snippets below, or translate to PowerShell.
- `psql` is usually at `C:\Program Files\PostgreSQL\17\bin` and not on `PATH`.
- You need **Azure AI keys** (Document Intelligence + OpenAI). For this project we
  reuse the `peapod-test-resource` in `rg-peapod-test`; ask a maintainer, or use
  your own Azure AI resource.

---

## 2. Clone and branch

```bash
git clone https://github.com/Tanvi-IT/BFSFCU-Escrow-Automation.git
cd BFSFCU-Escrow-Automation
git checkout dev            # always start from dev
git checkout -b feature/my-change
```

> **Push to `dev` only.** `main` is protected — you cannot push to it directly.
> See **Contributing** below.

---

## 3. Local dependencies

### PostgreSQL (Docker)

```bash
docker run -d --name bfsfcu-escrow-pg -e POSTGRES_PASSWORD=postgres -p 5432:5432 postgres:16
export PGHOST=127.0.0.1 PGUSER=postgres PGPASSWORD=postgres PGDATABASE=bfsfcu_escrow
createdb bfsfcu_escrow 2>/dev/null || true
for f in db/migrations/*.sql; do psql -v ON_ERROR_STOP=1 -f "$f"; done   # or: ./db/apply.ps1
```

Seeded admin: **`admin@bfsfcu.test` / `Escrow@review`**.

### Azurite (Blob/Queue)

```bash
azurite --silent --skipApiVersionCheck --location ./.azurite
```

### Oracle (Docker) + sample data

```bash
docker run -d --name bfsfcu-oracle -p 1521:1521 \
  -e ORACLE_PASSWORD=OraSys_123 -e APP_USER=ESCROW_RO -e APP_USER_PASSWORD=Escrow_ro_pw_123 \
  gvenzl/oracle-xe:21-slim
# wait for "DATABASE IS READY TO USE", then load schema + data as ESCROW_RO:
docker cp mock_db/01_schema.sql bfsfcu-oracle:/tmp/ && docker cp mock_db/02_sample_data.sql bfsfcu-oracle:/tmp/
docker exec -i bfsfcu-oracle sqlplus -S ESCROW_RO/Escrow_ro_pw_123@localhost:1521/XEPDB1 @/tmp/01_schema.sql
docker exec -i bfsfcu-oracle sqlplus -S ESCROW_RO/Escrow_ro_pw_123@localhost:1521/XEPDB1 @/tmp/02_sample_data.sql
```

> Oracle is optional: with it off, letters still process and land **Low** (the
> connector degrades gracefully). Turn it on to see High-confidence matches.

---

## 4. Configure and run the API

```bash
cd api
cp local.settings.json.example local.settings.json
#  → fill in DOCINTEL_* and AOAI_* keys; keep PG_DATABASE=bfsfcu_escrow.
#  → ORACLE_PASSWORD=Escrow_ro_pw_123 (matches the Oracle container above).
#  → DEMO_MODE=true enables the "Reset Demo Data" control.
npm install
func start --port 7072    # http://localhost:7072
```

Notes: the **Escrow API runs on 7072** (7071 is the AP app in local dev) — the web
dev server proxies `/api` → `127.0.0.1:7072` (see `web/vite.config.ts`). Use
`127.0.0.1` (not `localhost`) for `PG_HOST` — the Functions host and
Postgres bind IPv4 only. Set `AOAI_REASONING_MODEL=true` for gpt-5.x/o-series.

---

## 5. Run the web

```bash
cd web
npm install
npm run dev        # http://localhost:8081 — proxies /api → 127.0.0.1:7072
```

Sign in as the seeded **Manager** `admin@bfsfcu.test` / `Escrow@review`. Then open
**Management → Oracle Connection**, enter host `127.0.0.1`, port `1521`, service
`XEPDB1`, user `ESCROW_RO`, enter the password, **Save**, and **Test connection**
(expects 9 loan records). Migration `0006` also seeds demo **Escrow Admins**
(`dfontenot@`, `karceneaux@`, `mprejean@`, `jhebert@` — all `Escrow@review`) so you
can see auto-distribution and Team Workload with real people.

---

## 6. Try it

Upload the sample letters (the "Mortgage Escrow" set) — on upload, choose **Auto**
to distribute them across the Escrow Admins by capacity. The file *names* don't
match their *content* — go by the body. Expected outcomes are in
[mock_db/README.md](mock_db/README.md): e.g. Patricia Mouton → **High** (*No action
needed*), Marcus Delahoussaye → **Low** (*Action required*, "No matching insurance
found"). Then sign in as an Escrow Admin to work **My Tasks** (accept/decline,
reschedule the task date); as the Manager, watch **Team Workload** (escalate /
reassign) and the **Inbox Monitor**, and check the Audit Log.

---

## 7. Contributing

- **Branch from `dev`**, do your work, open a **pull request into `main`**. `main`
  is protected — only PRs merge into it.
- **Push only to `dev`** (or your feature branches). Never force-push shared
  branches.
- **CI/CD**: merging/pushing to `dev` triggers a deploy of the affected part
  (API and/or web) to the demo environment — see
  [docs/CLIENT-DEPLOYMENT.md](docs/CLIENT-DEPLOYMENT.md).
- **Schema changes** → a new numbered migration in `db/migrations/` (never edit an
  applied one; make it idempotent).
- **Never commit secrets.** `api/local.settings.json` and `web/.env*` (except
  `.env.example` / `.env.production`) are gitignored.
- **Typecheck before pushing**:
  ```bash
  cd api && npx tsc --noEmit
  cd web && npm run typecheck
  ```

---

## Working commands

```powershell
docker start bfsfcu-escrow-pg bfsfcu-oracle
azurite --silent --skipApiVersionCheck --location .\.azurite
cd api; func start --port 7072    # :7072  (7071 is the AP app)
cd web; npm run dev               # :8081

# inspect the DB
$env:PGHOST='127.0.0.1'; $env:PGUSER='postgres'; $env:PGPASSWORD='postgres'; $env:PGDATABASE='bfsfcu_escrow'
psql -c "SELECT insured_name, status, confidence_tier FROM letters ORDER BY created_at DESC;"
```

## On hold (not built)

Email intake (Graph mailbox poll), payment / check-run export, and the OnBase /
OSI pushes are deferred. The connector and worker leave clean seams for them.
