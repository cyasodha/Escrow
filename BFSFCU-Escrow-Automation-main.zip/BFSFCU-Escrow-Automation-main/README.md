# BFSFCU Escrow Insurance Automation

Standalone application for the intake and review of escrow insurance letters —
**policy modifications** and **cancellations** — for Bank Fund Credit Union
(the mortgagee / loss-payee on every letter). Forked from the AP invoice
automation platform (same stack and flow), retargeted to the escrow domain.


## The flow

```
upload letter → extract 11 fields + type/subtype (Doc Intelligence → Azure OpenAI)
   → match to Oracle (policy # primary; loan # / insured name + property address for PII)
   → compare vs insurance-on-file  → AUTO-TIER: High or Low
   → AUTO-ASSIGN to an Escrow Admin (by capacity weight)
   → Escrow Admin "My Tasks" (only their assigned letters, flagged action / no-action)
       → accept / decline
   → Manager oversees: Team Workload (escalate / reassign) + Inbox Monitor
```

**The 11 fields:** carrier, policy #, property address, insured name, loan #,
dwelling coverage, total premium, policy period start, policy period end, policy
type (e.g. HO-3), reason. The due date is derived from the policy period start.

**Cancellations** carry a 3-way subtype (nonpayment / provider-switch /
non-renewal) as metadata — a reviewer uses it to decide whether to move the letter
to the Task queue. They are compared and tiered like modifications.

## Roles & confidence tiering (locked)

Two roles, labelled in the UI: **Manager** (DB role `admin`) oversees — Team
Workload, Inbox Monitor, capacity/assignment — and **cannot accept/decline**.
**Escrow Admin** (DB role `user`) works only the letters **assigned to them** in a
single **My Tasks** list. Letters auto-distribute to Escrow Admins by a capacity
**weight** (Light 8 : Regular 15 : Heavy 25), weighted least-loaded.

Auto-tier is **only High or Low** — there is **no automatic Exception and no
separate Review queue**. The tier sets the flag on each assigned letter: **High** →
*No action needed*, **Low** → *Action required* (as is a `task` or an unreadable /
not-matched letter).

- **High** — 100% match on **PII** (insured name + property address) **and
  account** (loan # + policy #) with the Oracle record, with an active mortgage.
- **Low** — anything less.

The **policy number is the primary insurance match**: if it isn't on file (a new /
replacement policy) the letter is tagged **"No matching insurance found"** and the
review screen hides the comparison. The premium delta (>5%) is shown as a flag but
does not auto-route.

## Architecture

Azure Functions (TypeScript) · React/Vite SPA · PostgreSQL · Azure Blob + Queue ·
Azure Document Intelligence + Azure OpenAI (gpt-5.1) · a read-only **Oracle**
connector (Thin mode) whose connection is set from the admin UI · local + Microsoft
Entra SSO auth · a Power Automate `X-Api-Key` machine-ingestion path. Downstream
(payment / OnBase / OSI) is on hold with clean seams.

```
api/        Azure Functions backend (shared platform + oracle/ + pipeline/ + repository/)
db/         app Postgres migrations
mock_db/    the SEPARATE Oracle DB: schema + read-only user + synthetic sample data
web/        React SPA
.github/    CI/CD workflows (deploy on push to dev)
```

## Documentation

| Doc | For |
|---|---|
| [CONTEXT.md](CONTEXT.md) | Read first — what the app is, locked decisions, traps (AI/dev onboarding). |
| [ARCHITECTURE.md](ARCHITECTURE.md) | Detailed technical architecture, the pipeline, data, CORS/auth. |
| [DEVELOPER.md](DEVELOPER.md) | Windows local setup + how to contribute. |
| [docs/CLIENT-DEPLOYMENT.md](docs/CLIENT-DEPLOYMENT.md) | From-scratch Azure deployment + CI/CD setup. |
| [db/README.md](db/README.md) · [mock_db/README.md](mock_db/README.md) | App DB migrations · Oracle schema + High/Low sample outcomes. |

## Deployment (demo)

Deployed entirely in Azure resource group `rg-peapod-test`: Static Web App
(`bfsfcuescrow-web`) + Flex Consumption Function App (`bfsfcuescrow-api`) + a
`bfsfcu_escrow` database on the shared Postgres server + an Oracle Container
Instance, reusing the AP app's Storage and Azure AI. **Push to `dev` → GitHub
Actions redeploy** the API and/or web. Full from-scratch steps in
[docs/CLIENT-DEPLOYMENT.md](docs/CLIENT-DEPLOYMENT.md).

## Contributing

Branch from **`dev`**, open a **PR into `main`** (protected). **Push to `dev`
only.** See [DEVELOPER.md](DEVELOPER.md).

Reference: `Escrow_Insurance_Payment_App_SOWPRD_v0.3` (PES-4044).
